plugins {
    id("com.android.application")
}

android {
    namespace = "ro.tachistoscop.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "ro.tachistoscop.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 30
        versionName = "2.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
