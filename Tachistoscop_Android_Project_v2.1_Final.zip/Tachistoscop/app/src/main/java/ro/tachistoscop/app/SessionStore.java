package ro.tachistoscop.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class SessionStore {
    private static final String PREFS = "tachistoscop_history";
    private static final String KEY_HISTORY = "sessions_json";
    private static final int MAX_SESSIONS = 180;

    public static final class SessionRecord {
        public long timestamp;
        public int trials;
        public int exactCorrect;
        public float averageAccuracy;
        public long averageResponseMs;
        public int startExposureMs;
        public int endExposureMs;
        public int startChunkWords;
        public int endChunkWords;
        public int trainingMode;
        public boolean adaptive;
        public float refreshRateHz;
        public boolean programMode;
        public int programDay;
        public String exerciseTitle = "";
        public boolean masteryPassed;
        public int plannedMinutes;
        public float performanceIndex;
        public int semanticTrials;
        public int semanticCorrect;
        public int programLevel;
        public float maxStimulusWidthPercent;

        JSONObject toJson() throws JSONException {
            JSONObject object = new JSONObject();
            object.put("timestamp", timestamp);
            object.put("trials", trials);
            object.put("exactCorrect", exactCorrect);
            object.put("averageAccuracy", averageAccuracy);
            object.put("averageResponseMs", averageResponseMs);
            object.put("startExposureMs", startExposureMs);
            object.put("endExposureMs", endExposureMs);
            object.put("startChunkWords", startChunkWords);
            object.put("endChunkWords", endChunkWords);
            object.put("trainingMode", trainingMode);
            object.put("adaptive", adaptive);
            object.put("refreshRateHz", refreshRateHz);
            object.put("programMode", programMode);
            object.put("programDay", programDay);
            object.put("exerciseTitle", exerciseTitle == null ? "" : exerciseTitle);
            object.put("masteryPassed", masteryPassed);
            object.put("plannedMinutes", plannedMinutes);
            object.put("performanceIndex", performanceIndex);
            object.put("semanticTrials", semanticTrials);
            object.put("semanticCorrect", semanticCorrect);
            object.put("programLevel", programLevel);
            object.put("maxStimulusWidthPercent", maxStimulusWidthPercent);
            return object;
        }

        static SessionRecord fromJson(JSONObject object) {
            SessionRecord record = new SessionRecord();
            record.timestamp = object.optLong("timestamp", 0L);
            record.trials = object.optInt("trials", 0);
            record.exactCorrect = object.optInt("exactCorrect", 0);
            record.averageAccuracy = (float) object.optDouble("averageAccuracy", 0d);
            record.averageResponseMs = object.optLong("averageResponseMs", 0L);
            record.startExposureMs = object.optInt("startExposureMs", 100);
            record.endExposureMs = object.optInt("endExposureMs", record.startExposureMs);
            record.startChunkWords = object.optInt("startChunkWords", 1);
            record.endChunkWords = object.optInt("endChunkWords", record.startChunkWords);
            record.trainingMode = object.optInt("trainingMode", AppPrefs.TRAINING_PRO);
            record.adaptive = object.optBoolean("adaptive", false);
            record.refreshRateHz = (float) object.optDouble("refreshRateHz", 0d);
            record.programMode = object.optBoolean("programMode", false);
            record.programDay = object.optInt("programDay", 0);
            record.exerciseTitle = object.optString("exerciseTitle", "");
            record.masteryPassed = object.optBoolean("masteryPassed", false);
            record.plannedMinutes = object.optInt("plannedMinutes", 0);
            record.performanceIndex = (float) object.optDouble("performanceIndex", 0d);
            record.semanticTrials = object.optInt("semanticTrials", 0);
            record.semanticCorrect = object.optInt("semanticCorrect", 0);
            record.programLevel = object.optInt("programLevel", record.programDay);
            record.maxStimulusWidthPercent = (float) object.optDouble("maxStimulusWidthPercent", 0d);
            return record;
        }
    }

    private SessionStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void add(Context context, SessionRecord record) {
        List<SessionRecord> records = load(context);
        records.add(0, record);
        if (records.size() > MAX_SESSIONS) {
            records = new ArrayList<>(records.subList(0, MAX_SESSIONS));
        }
        save(context, records);
    }

    public static List<SessionRecord> load(Context context) {
        String raw = prefs(context).getString(KEY_HISTORY, "[]");
        List<SessionRecord> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);
                if (object != null) result.add(SessionRecord.fromJson(object));
            }
        } catch (JSONException ignored) {
            return new ArrayList<>();
        }
        return result;
    }

    public static void clear(Context context) {
        prefs(context).edit().putString(KEY_HISTORY, "[]").apply();
    }

    private static void save(Context context, List<SessionRecord> records) {
        JSONArray array = new JSONArray();
        for (SessionRecord record : records) {
            try {
                array.put(record.toJson());
            } catch (JSONException ignored) { }
        }
        prefs(context).edit().putString(KEY_HISTORY, array.toString()).apply();
    }
}
