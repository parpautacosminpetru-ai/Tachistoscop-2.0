package ro.tachistoscop.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Bibliotecă semantică offline, cu răspuns unic și verificabil. */
public final class SemanticItemRepository {
    public static final class Item {
        public final String text;
        public final String question;
        public final String[] options;
        public final int correctIndex;
        public final int words;
        public final int characters;

        Item(String text, String question, int correctIndex, String... options) {
            this.text = BookTextLayoutEngine.normalize(text);
            this.question = question;
            this.correctIndex = Math.max(0, Math.min(options.length - 1, correctIndex));
            this.options = options;
            this.words = BookTextLayoutEngine.wordCount(this.text);
            this.characters = BookTextLayoutEngine.characterCount(this.text);
        }
    }

    private static final List<Item> ITEMS = new ArrayList<>();

    static {
        add("Mara deschide cartea albastră.", "Ce deschide Mara?", 1,
                "fereastra", "cartea albastră", "ușa", "cutia");
        add("Trenul pleacă înainte de prânz.", "Când pleacă trenul?", 0,
                "înainte de prânz", "după cină", "la miezul nopții", "seara târziu");
        add("Copilul pune creionul pe masă.", "Unde pune copilul creionul?", 2,
                "în ghiozdan", "sub scaun", "pe masă", "în sertar");
        add("Vântul mișcă frunzele din parc.", "Ce mișcă vântul?", 3,
                "norii", "băncile", "aleea", "frunzele");
        add("Ana cumpără mere pentru desert.", "De ce cumpără Ana mere?", 1,
                "pentru micul dejun", "pentru desert", "pentru decor", "pentru drum");
        add("Lumina dimineții intră prin fereastră.", "Pe unde intră lumina?", 0,
                "prin fereastră", "prin podea", "prin dulap", "prin carte");

        add("Profesorul închide cartea înaintea discuției.", "Ce face profesorul înaintea discuției?", 2,
                "scrie pe tablă", "pleacă din sală", "închide cartea", "deschide fereastra");
        add("Ploaia se oprește înainte să sosească trenul.", "Cum este vremea când sosește trenul?", 1,
                "plouă puternic", "ploaia s-a oprit", "ninge", "bate furtuna");
        add("Maria alege drumul scurt spre bibliotecă.", "Ce drum alege Maria?", 3,
                "drumul lung", "drumul spre parc", "drumul închis", "drumul scurt");
        add("Câinele așteaptă liniștit lângă poarta verde.", "Unde așteaptă câinele?", 0,
                "lângă poarta verde", "sub masă", "în mașină", "pe acoperiș");
        add("Radu notează ideea principală într-un caiet.", "Ce notează Radu?", 2,
                "numărul paginii", "ora exactă", "ideea principală", "numele străzii");
        add("Fata își ia umbrela fiindcă începe ploaia.", "De ce ia fata umbrela?", 1,
                "fiindcă e soare", "fiindcă începe ploaia", "fiindcă e frig", "fiindcă aleargă");

        add("Autobuzul oprește două minute lângă piața centrală.", "Cât timp oprește autobuzul?", 0,
                "două minute", "zece minute", "o oră", "treizeci de secunde");
        add("Andrei termină raportul după ce verifică toate cifrele.", "Ce face Andrei înainte să termine raportul?", 2,
                "trimite raportul", "închide calculatorul", "verifică toate cifrele", "pleacă acasă");
        add("Pisica se ascunde sub fotoliu când aude zgomotul.", "Când se ascunde pisica?", 3,
                "când vede mâncarea", "când se deschide ușa", "când adoarme", "când aude zgomotul");
        add("Bibliotecara pune volumele noi pe raftul de sus.", "Unde pune bibliotecara volumele noi?", 1,
                "pe masă", "pe raftul de sus", "în cutie", "la intrare");
        add("Soarele apare dintre nori după ploaia de dimineață.", "Ce se întâmplă după ploaie?", 0,
                "apare soarele", "începe ninsoarea", "se întunecă", "vine furtuna");
        add("Elevul recitește întrebarea înainte să aleagă răspunsul.", "Ce face elevul înainte de răspuns?", 2,
                "închide testul", "cere ajutor", "recitește întrebarea", "schimbă locul");

        add("Mecanicul verifică frânele înainte ca mașina să plece.", "Ce verifică mecanicul?", 1,
                "farurile", "frânele", "radioul", "portbagajul");
        add("Ioana păstrează biletul deoarece îl va folosi seara.", "De ce păstrează Ioana biletul?", 3,
                "pentru colecție", "pentru prietenă", "pentru dimineață", "îl va folosi seara");
        add("Un nor gros acoperă pentru scurt timp luna.", "Ce acoperă luna?", 0,
                "un nor gros", "un copac", "un avion", "ceața de pe drum");
        add("Tatăl stinge lumina după ce copiii adorm complet.", "Când stinge tatăl lumina?", 2,
                "înainte de cină", "când intră în cameră", "după ce copiii adorm", "înainte să citească");
        add("Curierul lasă coletul la recepție fiindcă biroul este închis.", "De ce lasă curierul coletul la recepție?", 1,
                "coletul este greu", "biroul este închis", "plouă afară", "nu găsește strada");
        add("Medicul citește rezultatul înainte să explice concluzia pacientului.", "Ce face medicul mai întâi?", 3,
                "sună recepția", "scrie rețeta", "închide dosarul", "citește rezultatul");

        add("După ce termină capitolul, Elena notează trei idei importante.", "Ce notează Elena după capitol?", 0,
                "trei idei importante", "toate cuvintele", "numărul ferestrelor", "ora plecării");
        add("Biciclistul încetinește fiindcă drumul devine îngust și alunecos.", "De ce încetinește biciclistul?", 2,
                "vede un magazin", "își caută telefonul", "drumul devine îngust și alunecos", "se oprește ploaia");
        add("Înaintea ședinței, echipa compară datele din cele două rapoarte.", "Ce compară echipa?", 1,
                "două fotografii", "datele din două rapoarte", "programul trenurilor", "prețurile magazinelor");
        add("Mihai mută ghiveciul aproape de geam pentru mai multă lumină.", "De ce mută Mihai ghiveciul?", 3,
                "pentru mai mult spațiu", "pentru că e greu", "pentru a-l ascunde", "pentru mai multă lumină");
        add("Când alarma pornește, paznicul verifică imediat intrarea principală.", "Ce verifică paznicul?", 0,
                "intrarea principală", "acoperișul", "parcarea din spate", "ceasul");
        add("Oana închide telefonul ca să poată urmări atent explicația.", "De ce închide Oana telefonul?", 2,
                "nu mai are baterie", "primește un mesaj", "ca să urmărească explicația", "pentru a ieși");

        add("Deși era obosit, Vlad a terminat exercițiul înainte de pauză.", "Când termină Vlad exercițiul?", 1,
                "după pauză", "înainte de pauză", "a doua zi", "în timpul cinei");
        add("Cartea veche rămâne pe masă, iar caietul intră în sertar.", "Ce intră în sertar?", 3,
                "cartea veche", "masa", "creionul", "caietul");
        add("După ploaie, aerul devine mai rece, dar cerul se luminează.", "Cum se schimbă cerul după ploaie?", 0,
                "se luminează", "devine mai întunecat", "rămâne neschimbat", "se acoperă complet");
        add("Șoferul alege ruta ocolitoare deoarece podul principal este închis.", "De ce alege șoferul ruta ocolitoare?", 2,
                "vrea să vadă parcul", "este mai scurtă", "podul principal este închis", "nu are combustibil");
        add("În timp ce cafeaua se răcește, Irina răspunde la două mesaje.", "Ce face Irina cât se răcește cafeaua?", 1,
                "citește ziarul", "răspunde la două mesaje", "pleacă la magazin", "spală cana");
        add("Cercetătorul repetă măsurarea pentru că prima valoare pare neobișnuită.", "De ce repetă cercetătorul măsurarea?", 3,
                "a uitat rezultatul", "s-a terminat timpul", "instrumentul este nou", "prima valoare pare neobișnuită");

        add("Înainte să pornească spre munte, grupul verifică harta și prognoza meteo.", "Ce verifică grupul înainte de plecare?", 0,
                "harta și prognoza", "doar biletele", "meniul restaurantului", "numărul camerelor");
        add("Deși fereastra era deschisă, camera a rămas caldă până seara.", "Cum a rămas camera?", 2,
                "foarte rece", "întunecată", "caldă până seara", "goală");
        add("După ce compară variantele, clientul alege modelul mai simplu și mai ușor.", "Ce model alege clientul?", 1,
                "cel mai scump", "modelul mai simplu și mai ușor", "modelul cel mai mare", "primul model văzut");
        add("Când lumina verde se aprinde, pietonii încep să traverseze strada aglomerată.", "Când încep pietonii să traverseze?", 3,
                "când se aude claxonul", "când plouă", "când strada este goală", "când se aprinde lumina verde");
        add("Pentru că biblioteca se închide devreme, studenta împrumută cartea înainte de curs.", "De ce împrumută studenta cartea înainte de curs?", 0,
                "biblioteca se închide devreme", "cartea este nouă", "cursul s-a anulat", "nu are caiet");
        add("Directorul aprobă proiectul numai după ce echipa clarifică ultimele două costuri.", "Ce trebuie clarificat înainte de aprobare?", 2,
                "data vacanței", "numele proiectului", "ultimele două costuri", "culoarea raportului");

        addGeneratedItems();
        addExactSpanBank();
    }

    /**
     * Bancă extinsă generată determinist. Scopul este să evităm memorarea itemilor
     * în programul intensiv; fiecare item are un singur răspuns semantic verificabil.
     */
    private static void addGeneratedItems() {
        String[] names = {"Mara", "Radu", "Ioana", "Vlad", "Elena", "Andrei", "Oana", "Mihai"};
        String[] objects = {"dosarul", "cartea", "cheile", "caietul", "biletul", "pachetul", "telefonul", "harta"};
        String[] places = {"pe raft", "în sertar", "sub masă", "lângă ușă"};

        // 64 itemi scurți (aprox. 5–7 cuvinte): localizare.
        for (int n = 0; n < names.length; n++) {
            for (int o = 0; o < objects.length; o++) {
                int correct = (n + o) % places.length;
                String text = names[n] + " pune " + objects[o] + " " + places[correct] + ".";
                add(text, "Unde pune " + names[n] + " obiectul?", correct,
                        places[0], places[1], places[2], places[3]);
            }
        }

        String[] action = {
                "ia umbrela", "aprinde lampa", "închide fereastra", "alege autobuzul",
                "păstrează biletul", "mută ghiveciul", "salvează documentul", "verifică frânele"
        };
        String[] reason = {
                "afară începe ploaia", "camera devine întunecată", "vântul devine puternic", "trenul are întârziere",
                "controlul începe curând", "planta are nevoie de lumină", "calculatorul va fi repornit", "mașina pleacă imediat"
        };
        String[] reasonOptions = {
                "începe ploaia", "camera este întunecată", "vântul este puternic", "trenul are întârziere",
                "începe controlul", "planta are nevoie de lumină", "calculatorul va fi repornit", "mașina pleacă imediat"
        };

        // 64 itemi medii (aprox. 7–10 cuvinte): cauză.
        for (int n = 0; n < names.length; n++) {
            for (int a = 0; a < action.length; a++) {
                int correct = (n + a) % 4;
                int source = (a / 2) * 2 + (correct % 2);
                source = Math.min(reason.length - 1, source);
                String chosenAction = action[source];
                String chosenReason = reason[source];
                String correctAnswer = reasonOptions[source];
                String[] options = distinctOptions(correctAnswer, reasonOptions[(source + 1) % reasonOptions.length],
                        reasonOptions[(source + 3) % reasonOptions.length], reasonOptions[(source + 5) % reasonOptions.length], correct);
                add(names[n] + " " + chosenAction + " deoarece " + chosenReason + ".",
                        "De ce " + chosenAction + " " + names[n] + "?", correct, options);
            }
        }

        String[] firstActions = {
                "verifică harta", "închide cartea", "citește mesajul", "compară datele",
                "termină raportul", "oprește alarma", "deschide agenda", "numără biletele"
        };
        String[] secondActions = {
                "pornește spre gară", "începe discuția", "răspunde colegului", "notează concluzia",
                "trimite documentul", "verifică intrarea", "alege ora întâlnirii", "intră în sală"
        };

        // 64 itemi medii-lungi (aprox. 9–12 cuvinte): ordine temporală.
        for (int n = 0; n < names.length; n++) {
            for (int a = 0; a < firstActions.length; a++) {
                int source = (n + a) % firstActions.length;
                int correct = (n * 3 + a) % 4;
                String correctAnswer = secondActions[source];
                String[] options = distinctOptions(correctAnswer,
                        secondActions[(source + 1) % secondActions.length],
                        secondActions[(source + 3) % secondActions.length],
                        secondActions[(source + 5) % secondActions.length], correct);
                add("După ce " + firstActions[source] + ", " + names[n] + " " + secondActions[source] + ".",
                        "Ce face " + names[n] + " după prima acțiune?", correct, options);
            }
        }

        String[] topics = {"raportul", "capitolul", "proiectul", "articolul", "planul", "rezumatul", "contractul", "mesajul"};
        String[] details = {"ideea principală", "două cifre importante", "ordinea etapelor", "motivul schimbării",
                "concluzia finală", "data întâlnirii", "numele autorului", "următorul pas"};

        // 64 itemi lungi (aprox. 10–13 cuvinte): selecția informației relevante.
        for (int n = 0; n < names.length; n++) {
            for (int t = 0; t < topics.length; t++) {
                int source = (n + t) % topics.length;
                int correct = (n + 2 * t) % 4;
                String correctAnswer = details[source];
                String[] options = distinctOptions(correctAnswer,
                        details[(source + 2) % details.length],
                        details[(source + 4) % details.length],
                        details[(source + 6) % details.length], correct);
                add("Înainte de întâlnire, " + names[n] + " recitește " + topics[source] + " și notează " + details[source] + ".",
                        "Ce notează " + names[n] + "?", correct, options);
            }
        }
    }

    /**
     * Bancă standardizată 4–12 cuvinte. Fiecare lungime are cel puțin 32 de itemi,
     * ceea ce permite ca nivelul declarat să corespundă lungimii reale a stimulului.
     */
    private static void addExactSpanBank() {
        String[] names = {"Mara", "Radu", "Ioana", "Vlad", "Elena", "Andrei", "Oana", "Mihai"};
        String[] objects = {"cartea nouă", "raportul scurt", "mesajul primit", "articolul recent"};

        for (int words = 2; words <= 12; words++) {
            for (int n = 0; n < names.length; n++) {
                for (int o = 0; o < objects.length; o++) {
                    if (words <= 3 && o > 0) continue;
                    int source = (n + o) % objects.length;
                    int correct = (n * 2 + o) % 4;
                    String object = objects[source];
                    String text;
                    switch (words) {
                        case 2:
                            text = names[n] + " citește.";
                            break;
                        case 3:
                            text = names[n] + " citește atent.";
                            break;
                        case 4:
                            text = names[n] + " citește " + object + ".";
                            break;
                        case 5:
                            text = names[n] + " citește atent " + object + ".";
                            break;
                        case 6:
                            text = names[n] + " citește atent " + object + " astăzi.";
                            break;
                        case 7:
                            text = names[n] + " citește atent " + object + " în bibliotecă.";
                            break;
                        case 8:
                            text = names[n] + " citește atent " + object + " în biblioteca centrală.";
                            break;
                        case 9:
                            text = names[n] + " citește atent " + object + " astăzi în biblioteca centrală.";
                            break;
                        case 10:
                            text = names[n] + " citește atent " + object + " astăzi în biblioteca centrală liniștită.";
                            break;
                        case 11:
                            text = names[n] + " citește atent " + object + " astăzi în biblioteca centrală din oraș.";
                            break;
                        case 12:
                        default:
                            text = names[n] + " citește atent " + object + " astăzi în biblioteca centrală din orașul vechi.";
                            break;
                    }
                    if (words <= 3) {
                        String[] actionOptions = distinctOptions("citește", "scrie", "aleargă", "doarme", correct);
                        add(text, "Ce face " + names[n] + "?", correct, actionOptions);
                    } else {
                        String[] options = distinctOptions(object,
                                objects[(source + 1) % objects.length],
                                objects[(source + 2) % objects.length],
                                objects[(source + 3) % objects.length], correct);
                        add(text, "Ce citește " + names[n] + "?", correct, options);
                    }
                }
            }
        }
    }

    public static List<Item> exactItems(int wordCount, int maxResults) {
        List<Item> result = new ArrayList<>();
        for (Item item : ITEMS) {
            if (item.words == wordCount) result.add(item);
        }
        int limit = Math.max(1, Math.min(maxResults, result.size()));
        if (result.isEmpty()) return closestItems(wordCount, maxResults);
        return new ArrayList<>(result.subList(0, limit));
    }

    /** Pune răspunsul corect pe poziția cerută și păstrează trei distractori diferiți. */
    private static String[] distinctOptions(String correctAnswer, String d1, String d2, String d3, int correctIndex) {
        String[] distractors = {d1, d2, d3};
        String[] result = new String[4];
        int d = 0;
        for (int i = 0; i < result.length; i++) {
            if (i == correctIndex) result[i] = correctAnswer;
            else result[i] = distractors[d++];
        }
        return result;
    }

    private SemanticItemRepository() { }

    private static void add(String text, String question, int correctIndex, String... options) {
        ITEMS.add(new Item(text, question, correctIndex, options));
    }

    public static List<Item> all() {
        return Collections.unmodifiableList(ITEMS);
    }

    public static Item findByText(String text) {
        String normalized = BookTextLayoutEngine.normalize(text);
        for (Item item : ITEMS) {
            if (item.text.equalsIgnoreCase(normalized)) return item;
        }
        return null;
    }

    public static List<Item> closestItems(int targetWords, int maxResults) {
        List<Item> copy = new ArrayList<>(ITEMS);
        copy.sort(Comparator.comparingInt(item -> Math.abs(item.words - targetWords)));
        int limit = Math.max(1, Math.min(maxResults, copy.size()));
        return new ArrayList<>(copy.subList(0, limit));
    }

    public static List<String> textsClosest(int targetWords) {
        List<Item> candidates = exactItems(targetWords, 120);
        List<String> result = new ArrayList<>();
        for (Item item : candidates) result.add(item.text);
        return result;
    }
}
