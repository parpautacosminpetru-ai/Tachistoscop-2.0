package ro.tachistoscop.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

public final class PlacementProfileStore {
    private static final String PREFS = "tachistoscop_placement_profile";
    private static final String COMPLETED = "completed";
    private static final String TEST_COUNT = "test_count";
    private static final String BASE_PREFIX = "base_";
    private static final String LAST_PREFIX = "last_";

    public static final class Profile {
        public long timestamp;
        public int visualSpanWords;
        public int semanticSpanWords;
        public int stableExposureMs;
        public float recallAccuracy;
        public float semanticAccuracy;
        public float widthPercent;
        public long averageResponseMs;
        public int recommendedStartLevel;
    }

    private PlacementProfileStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isCompleted(Context context) {
        return prefs(context).getBoolean(COMPLETED, false);
    }

    public static int getTestCount(Context context) {
        return Math.max(0, prefs(context).getInt(TEST_COUNT, 0));
    }

    public static Profile getBaseline(Context context) {
        return read(context, BASE_PREFIX);
    }

    public static Profile getLatest(Context context) {
        return read(context, LAST_PREFIX);
    }

    public static void save(Context context, Profile profile) {
        SharedPreferences sp = prefs(context);
        int count = Math.max(0, sp.getInt(TEST_COUNT, 0));
        SharedPreferences.Editor editor = sp.edit();
        if (count == 0) write(editor, BASE_PREFIX, profile);
        write(editor, LAST_PREFIX, profile);
        editor.putBoolean(COMPLETED, true);
        editor.putInt(TEST_COUNT, count + 1);
        editor.apply();
    }

    public static String compactSummary(Context context) {
        if (!isCompleted(context)) return "Testul inițial nu a fost efectuat.";
        Profile p = getLatest(context);
        return String.format(Locale.getDefault(),
                "Span vizual %d cuv. • span semantic %d cuv. • %d ms • recall %.0f%% • semantic %.0f%% • lățime %.0f%% • nivel recomandat %d/30",
                p.visualSpanWords,
                p.semanticSpanWords,
                p.stableExposureMs,
                p.recallAccuracy * 100f,
                p.semanticAccuracy * 100f,
                p.widthPercent,
                p.recommendedStartLevel);
    }

    public static void clear(Context context) {
        prefs(context).edit().clear().apply();
    }

    private static Profile read(Context context, String prefix) {
        SharedPreferences sp = prefs(context);
        Profile p = new Profile();
        p.timestamp = sp.getLong(prefix + "timestamp", 0L);
        p.visualSpanWords = sp.getInt(prefix + "visual_span", 1);
        p.semanticSpanWords = sp.getInt(prefix + "semantic_span", 1);
        p.stableExposureMs = sp.getInt(prefix + "exposure", 250);
        p.recallAccuracy = sp.getFloat(prefix + "recall", 0f);
        p.semanticAccuracy = sp.getFloat(prefix + "semantic", 0f);
        p.widthPercent = sp.getFloat(prefix + "width", 0f);
        p.averageResponseMs = sp.getLong(prefix + "response", 0L);
        p.recommendedStartLevel = sp.getInt(prefix + "start_level", 1);
        return p;
    }

    private static void write(SharedPreferences.Editor editor, String prefix, Profile p) {
        editor.putLong(prefix + "timestamp", p.timestamp);
        editor.putInt(prefix + "visual_span", p.visualSpanWords);
        editor.putInt(prefix + "semantic_span", p.semanticSpanWords);
        editor.putInt(prefix + "exposure", p.stableExposureMs);
        editor.putFloat(prefix + "recall", p.recallAccuracy);
        editor.putFloat(prefix + "semantic", p.semanticAccuracy);
        editor.putFloat(prefix + "width", p.widthPercent);
        editor.putLong(prefix + "response", p.averageResponseMs);
        editor.putInt(prefix + "start_level", p.recommendedStartLevel);
    }
}
