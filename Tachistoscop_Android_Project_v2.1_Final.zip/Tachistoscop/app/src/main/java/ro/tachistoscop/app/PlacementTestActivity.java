package ro.tachistoscop.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class PlacementTestActivity extends Activity {
    private TachistoscopeView tachistoscopeView;
    private TextView stageText;
    private TextView metricsText;
    private TextView instructionText;
    private Button startButton;
    private Button exposeButton;
    private LinearLayout recallPanel;
    private EditText recallInput;
    private Button recallVerifyButton;
    private LinearLayout semanticPanel;
    private TextView semanticQuestion;
    private final Button[] semanticButtons = new Button[4];

    private PlacementEngine engine = new PlacementEngine();
    private final Set<String> usedTexts = new HashSet<>();
    private SemanticItemRepository.Item currentItem;
    private ResponseScorer.Score pendingRecall;
    private long responseStartedMs;
    private long pendingResponseMs;
    private boolean testStarted;
    private boolean awaitingRecall;
    private boolean awaitingSemantic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(45, 31, 24));
        getWindow().setNavigationBarColor(Color.rgb(31, 24, 20));
        buildUi();
        renderIdle();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(237, 226, 205));
        SystemBarInsets.apply(root);

        TextView title = new TextView(this);
        title.setText("TEST DE PLASARE • VIZUAL + SEMANTIC");
        title.setTextColor(Color.rgb(246, 232, 206));
        title.setBackgroundColor(Color.rgb(45, 31, 24));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(16), dp(11), dp(16), dp(11));
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        stageText = text(13, true);
        stageText.setGravity(Gravity.CENTER);
        stageText.setPadding(dp(10), dp(8), dp(10), dp(2));
        root.addView(stageText);

        metricsText = text(12, false);
        metricsText.setGravity(Gravity.CENTER);
        metricsText.setPadding(dp(10), 0, dp(10), dp(5));
        root.addView(metricsText);

        tachistoscopeView = new TachistoscopeView(this);
        tachistoscopeView.setBookTextMode(true);
        tachistoscopeView.setStimulusStyle(Typeface.SERIF, AppPrefs.getBookFontBaseSp(this));
        tachistoscopeView.setAdaptiveDisplay(true, true);
        tachistoscopeView.setFixationDelayMs(550);
        tachistoscopeView.setInteractionEnabled(false);
        tachistoscopeView.setExposureListener(new TachistoscopeView.ExposureListener() {
            @Override
            public void onFixationStarted(int fixationMs) {
                instructionText.setText("FIXAȚIE • privește punctul central; nu urmări marginile.");
                exposeButton.setEnabled(false);
            }

            @Override
            public void onExposureStarted(int requestedMs, float nominalMs, int frameCount, float refreshRateHz) {
                instructionText.setText(String.format(Locale.getDefault(),
                        "EXPUNERE • %d ms • %.1f Hz • %d cadre", requestedMs, refreshRateHz, frameCount));
            }

            @Override
            public void onExposureFinished(int requestedMs, float measuredMs, int frameCount, float refreshRateHz) {
                awaitingRecall = true;
                responseStartedMs = SystemClock.elapsedRealtime();
                recallPanel.setVisibility(View.VISIBLE);
                recallInput.setText("");
                recallInput.requestFocus();
                recallVerifyButton.setEnabled(true);
                instructionText.setText("REPRODUCERE • scrie cât mai exact rândul perceput.");
                showKeyboard(recallInput);
            }
        });
        root.addView(tachistoscopeView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(12), dp(8), dp(12), dp(12));
        controls.setBackgroundColor(Color.rgb(225, 210, 180));

        instructionText = text(12, false);
        instructionText.setGravity(Gravity.CENTER);
        instructionText.setMinLines(2);
        controls.addView(instructionText);

        recallPanel = new LinearLayout(this);
        recallPanel.setOrientation(LinearLayout.VERTICAL);
        recallInput = new EditText(this);
        recallInput.setSingleLine(false);
        recallInput.setMaxLines(2);
        recallInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        recallInput.setTextColor(Color.rgb(35, 31, 27));
        recallInput.setHint("Scrie ce ai perceput");
        recallInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        recallInput.setBackgroundColor(Color.rgb(250, 246, 235));
        recallInput.setPadding(dp(10), dp(6), dp(10), dp(6));
        recallPanel.addView(recallInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        recallVerifyButton = action("VERIFICĂ REPRODUCEREA", Color.rgb(105, 68, 43));
        recallVerifyButton.setOnClickListener(v -> submitRecall());
        LinearLayout.LayoutParams recallButtonLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        recallButtonLp.topMargin = dp(5);
        recallPanel.addView(recallVerifyButton, recallButtonLp);
        controls.addView(recallPanel);

        semanticPanel = new LinearLayout(this);
        semanticPanel.setOrientation(LinearLayout.VERTICAL);
        semanticQuestion = text(14, true);
        semanticQuestion.setPadding(dp(4), dp(4), dp(4), dp(5));
        semanticPanel.addView(semanticQuestion);
        for (int i = 0; i < semanticButtons.length; i++) {
            final int index = i;
            semanticButtons[i] = action("", Color.rgb(119, 82, 54));
            semanticButtons[i].setOnClickListener(v -> submitSemantic(index));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
            lp.topMargin = dp(4);
            semanticPanel.addView(semanticButtons[i], lp);
        }
        controls.addView(semanticPanel);

        startButton = action("ÎNCEPE TESTUL", Color.rgb(78, 54, 40));
        startButton.setOnClickListener(v -> startTest());
        controls.addView(startButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        exposeButton = action("EXPUNE PROBA", Color.rgb(126, 79, 45));
        exposeButton.setOnClickListener(v -> {
            if (testStarted && !awaitingRecall && !awaitingSemantic) {
                if (!tachistoscopeView.triggerExposureProgrammatically()) {
                    if (!tachistoscopeView.canDisplayStimulusOnOneLine()) {
                        Toast.makeText(this, "Rândul nu încape integral. Rotește telefonul pe orizontală; testul nu expune text tăiat.", Toast.LENGTH_LONG).show();
                        instructionText.setText("ROTIRE NECESARĂ • păstrăm fontul de carte și rândul complet, fără clipping.");
                    }
                }
            }
        });
        LinearLayout.LayoutParams exposeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        exposeLp.topMargin = dp(6);
        controls.addView(exposeButton, exposeLp);

        Button back = action("ÎNAPOI", Color.rgb(150, 120, 86));
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        backLp.topMargin = dp(6);
        controls.addView(back, backLp);

        root.addView(controls, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private void renderIdle() {
        stageText.setText("TEST OBLIGATORIU ÎNAINTE DE PROGRAM");
        metricsText.setText(PlacementProfileStore.isCompleted(this)
                ? "Există deja un rezultat. Repetarea testului actualizează progresul, fără a muta un program început."
                : "Două etape: span semantic la 220 ms, apoi viteză stabilă la spanul găsit.");
        instructionText.setText("Testul folosește același font serif de carte, fixație centrală și verificare dublă: reproducere + sens. Nu ghici; răspunde doar ce ai perceput.");
        recallPanel.setVisibility(View.GONE);
        semanticPanel.setVisibility(View.GONE);
        exposeButton.setVisibility(View.GONE);
        startButton.setVisibility(View.VISIBLE);
        tachistoscopeView.setStimulus("");
    }

    private void startTest() {
        engine = new PlacementEngine();
        testStarted = true;
        startButton.setVisibility(View.GONE);
        exposeButton.setVisibility(View.VISIBLE);
        usedTexts.clear();
        prepareTrial();
    }

    private void prepareTrial() {
        if (engine.isFinished()) {
            finishTest();
            return;
        }
        awaitingRecall = false;
        awaitingSemantic = false;
        pendingRecall = null;
        recallPanel.setVisibility(View.GONE);
        semanticPanel.setVisibility(View.GONE);
        hideKeyboard();

        currentItem = pickItem(engine.getTargetWords());
        tachistoscopeView.setStimulus(currentItem.text);
        tachistoscopeView.setExposureDurationMs(engine.getExposureMs());
        tachistoscopeView.setInteractionEnabled(true);
        exposeButton.setEnabled(true);
        stageText.setText(engine.getStageLabel());
        metricsText.setText(String.format(Locale.getDefault(),
                "Proba %d • țintă %d cuvinte • %d ms\n%s",
                engine.getTrialNumber(), engine.getTargetWords(), engine.getExposureMs(), engine.liveSummary()));
        instructionText.setText("GATA • fixează centrul, apoi apasă EXPUNE PROBA.");
    }

    private SemanticItemRepository.Item pickItem(int targetWords) {
        List<SemanticItemRepository.Item> candidates = SemanticItemRepository.exactItems(targetWords, 120);
        Collections.shuffle(candidates);
        for (SemanticItemRepository.Item item : candidates) {
            if (!usedTexts.contains(item.text)) {
                usedTexts.add(item.text);
                return item;
            }
        }
        SemanticItemRepository.Item item = candidates.get(0);
        usedTexts.add(item.text);
        return item;
    }

    private void submitRecall() {
        if (!testStarted || !awaitingRecall || currentItem == null) return;
        awaitingRecall = false;
        pendingResponseMs = Math.max(0L, SystemClock.elapsedRealtime() - responseStartedMs);
        pendingRecall = ResponseScorer.score(currentItem.text, recallInput.getText().toString());
        recallVerifyButton.setEnabled(false);
        recallPanel.setVisibility(View.GONE);
        hideKeyboard();

        awaitingSemantic = true;
        semanticQuestion.setText("SENS • " + currentItem.question);
        for (int i = 0; i < semanticButtons.length; i++) {
            semanticButtons[i].setText((char) ('A' + i) + ". " + currentItem.options[i]);
            semanticButtons[i].setEnabled(true);
        }
        semanticPanel.setVisibility(View.VISIBLE);
        instructionText.setText(String.format(Locale.getDefault(),
                "Reproducere: %.0f%%. Acum verificăm dacă ai procesat sensul, nu doar forma vizuală.",
                pendingRecall.wordAccuracy * 100f));
    }

    private void submitSemantic(int selectedIndex) {
        if (!testStarted || !awaitingSemantic || currentItem == null || pendingRecall == null) return;
        awaitingSemantic = false;
        for (Button button : semanticButtons) button.setEnabled(false);
        boolean semanticCorrect = selectedIndex == currentItem.correctIndex;
        float widthPercent = tachistoscopeView.getLastStimulusWidthPercent();
        engine.addResult(pendingRecall.wordAccuracy, semanticCorrect, pendingResponseMs, widthPercent);

        instructionText.setText(String.format(Locale.getDefault(),
                "%s • reproducere %.0f%% • rând %.0f%% din zona utilă. Pregătim următoarea probă.",
                semanticCorrect ? "SENS CORECT" : "SENS INCORECT",
                pendingRecall.wordAccuracy * 100f,
                widthPercent));
        semanticPanel.postDelayed(this::prepareTrial, 550L);
    }

    private void finishTest() {
        testStarted = false;
        exposeButton.setEnabled(false);
        tachistoscopeView.setInteractionEnabled(false);
        tachistoscopeView.setStimulus("");
        PlacementProfileStore.Profile profile = engine.buildProfile();
        PlacementProfileStore.save(this, profile);

        boolean repositioned = false;
        if (TrainingPlanStore.getCompletedSessions(this) == 0) {
            // Până la prima sesiune promovată, ultimul test valid poate rafina nivelul de start.
            TrainingPlanStore.applyPlacementStart(this, profile.recommendedStartLevel);
            repositioned = true;
        }

        stageText.setText("TEST FINALIZAT");
        metricsText.setText(String.format(Locale.getDefault(),
                "Span vizual: %d cuv. • span semantic: %d cuv. • %d ms • lățime %.0f%%",
                profile.visualSpanWords, profile.semanticSpanWords, profile.stableExposureMs, profile.widthPercent));
        instructionText.setText("Rezultatul a fost salvat în Progres. Programul folosește acest profil ca punct de pornire.");
        recallPanel.setVisibility(View.GONE);
        semanticPanel.setVisibility(View.GONE);
        exposeButton.setVisibility(View.GONE);
        startButton.setVisibility(View.VISIBLE);
        startButton.setText("REPETĂ TESTUL");

        String message = String.format(Locale.getDefault(),
                "Span vizual stabil: %d cuvinte\nSpan semantic stabil: %d cuvinte\nExpunere stabilă: %d ms\nRecall global: %.0f%%\nSemantic global: %.0f%%\nLățime maximă funcțională: %.0f%%\nRăspuns mediu: %d ms\n\nNivel recomandat: %d/30%s",
                profile.visualSpanWords,
                profile.semanticSpanWords,
                profile.stableExposureMs,
                profile.recallAccuracy * 100f,
                profile.semanticAccuracy * 100f,
                profile.widthPercent,
                profile.averageResponseMs,
                profile.recommendedStartLevel,
                repositioned ? "\nProgramul a fost poziționat automat la acest nivel." : "\nUn program deja început nu a fost repoziționat.");

        new AlertDialog.Builder(this)
                .setTitle("Profil inițial calculat")
                .setMessage(message)
                .setPositiveButton("PLAN 30 SESIUNI", (dialog, which) -> startActivity(new Intent(this, PlannerActivity.class)))
                .setNegativeButton("ÎNCHIDE", null)
                .show();
    }

    private TextView text(int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setTextColor(Color.rgb(68, 49, 36));
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setLineSpacing(0f, 1.12f);
        return view;
    }

    private Button action(String label, int color) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        button.setBackgroundTintList(ColorStateList.valueOf(color));
        return button;
    }

    private void showKeyboard(View view) {
        view.postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
        }, 120L);
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus == null) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        focus.clearFocus();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
