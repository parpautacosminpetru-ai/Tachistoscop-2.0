package ro.tachistoscop.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class PlannerActivity extends Activity {
    private CheckBox enabledCheck;
    private Button startDateButton;
    private SeekBar minutesSeek;
    private TextView minutesLabel;
    private final CheckBox[] weekdayChecks = new CheckBox[7];
    private TextView placementCard;
    private Button placementButton;
    private TextView calculationCard;
    private LinearLayout libraryRoot;
    private long selectedStartDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(45, 31, 24));
        getWindow().setNavigationBarColor(Color.rgb(31, 24, 20));
        selectedStartDate = TrainingPlanStore.getStartDate(this);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadValues();
        refreshCalculation();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(240, 230, 210));
        SystemBarInsets.apply(scroll);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = body("PLAN PROFESIONAL • 30 SESIUNI");
        title.setTextColor(Color.rgb(56, 39, 29));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 23);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        root.addView(title);

        TextView intro = body("Testul de plasare stabilește nivelul de start, dar luna rămâne formată din 30 de sesiuni promovate. Nivelul următor se deblochează numai prin Mastery Gate.");
        intro.setPadding(0, dp(5), 0, dp(10));
        root.addView(intro);

        section(root, "Test de plasare obligatoriu");
        placementCard = body("");
        placementCard.setTextColor(Color.rgb(47, 38, 31));
        placementCard.setBackgroundColor(Color.rgb(250, 246, 235));
        placementCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        root.addView(placementCard);

        placementButton = button("PORNEȘTE TESTUL INIȚIAL", Color.rgb(104, 66, 41));
        placementButton.setOnClickListener(v -> startActivity(new Intent(this, PlacementTestActivity.class)));
        LinearLayout.LayoutParams testLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        testLp.topMargin = dp(6);
        root.addView(placementButton, testLp);

        enabledCheck = check("Activează programul intensiv de 30 sesiuni");
        enabledCheck.setOnCheckedChangeListener((buttonView, isChecked) -> refreshCalculation());
        LinearLayout.LayoutParams enabledLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        enabledLp.topMargin = dp(12);
        root.addView(enabledCheck, enabledLp);

        section(root, "Data de start");
        startDateButton = button("", Color.rgb(230, 215, 187));
        startDateButton.setTextColor(Color.rgb(65, 45, 32));
        startDateButton.setOnClickListener(v -> chooseDate());
        root.addView(startDateButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        section(root, "Timp de antrenament pe sesiune");
        minutesLabel = body("20 minute / sesiune");
        minutesLabel.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(minutesLabel);
        minutesSeek = new SeekBar(this);
        minutesSeek.setMax(11); // 5..60 min, pas 5
        minutesSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                minutesLabel.setText(((progress + 1) * 5) + " minute / sesiune");
                refreshCalculation();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        root.addView(minutesSeek);
        root.addView(body("Volumul este estimat la aproximativ 3 expuneri verificate/minut și rotunjit la ferestre complete de 10 probe pentru Mastery Gate."));

        section(root, "Zile de antrenament");
        LinearLayout daysRow = new LinearLayout(this);
        daysRow.setOrientation(LinearLayout.HORIZONTAL);
        daysRow.setGravity(Gravity.CENTER);
        String[] labels = {"L", "Ma", "Mi", "J", "V", "S", "D"};
        for (int i = 0; i < weekdayChecks.length; i++) {
            CheckBox box = new CheckBox(this);
            box.setText(labels[i]);
            box.setGravity(Gravity.CENTER);
            box.setButtonTintList(ColorStateList.valueOf(Color.rgb(99, 64, 42)));
            box.setOnCheckedChangeListener((buttonView, isChecked) -> refreshCalculation());
            weekdayChecks[i] = box;
            daysRow.addView(box, new LinearLayout.LayoutParams(0, dp(50), 1f));
        }
        root.addView(daysRow);

        section(root, "Calculul calendarului");
        calculationCard = body("");
        calculationCard.setTextColor(Color.rgb(47, 38, 31));
        calculationCard.setBackgroundColor(Color.rgb(250, 246, 235));
        calculationCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        root.addView(calculationCard);

        section(root, "Mastery Gate — nu avansează dacă nu este ușor și precis");
        TextView gate = body("Pentru nivelurile vizuale: sesiune completă ≥93% recall, ≥80% răspunsuri exacte și două ferestre consecutive de 10 probe cu ≥95% recall și ≥85% exact. Din nivelul semantic în sus se cere suplimentar ≥90% sens. Dacă pragul nu este atins, aceeași sesiune și același nivel se repetă.");
        gate.setBackgroundColor(Color.rgb(244, 235, 215));
        gate.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(gate);

        section(root, "Niveluri de dificultate");
        libraryRoot = new LinearLayout(this);
        libraryRoot.setOrientation(LinearLayout.VERTICAL);
        root.addView(libraryRoot);

        Button save = button("SALVEAZĂ PLANUL", Color.rgb(91, 57, 36));
        save.setOnClickListener(v -> savePlan());
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        saveLp.topMargin = dp(18);
        root.addView(save, saveLp);

        Button reset = button("RESETEAZĂ CELE 30 DE SESIUNI", Color.rgb(122, 73, 52));
        reset.setOnClickListener(v -> confirmReset());
        LinearLayout.LayoutParams resetLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        resetLp.topMargin = dp(8);
        root.addView(reset, resetLp);

        Button back = button("ÎNAPOI", Color.rgb(224, 210, 183));
        back.setTextColor(Color.rgb(72, 47, 31));
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        backLp.topMargin = dp(8);
        root.addView(back, backLp);

        setContentView(scroll);
    }

    private void loadValues() {
        enabledCheck.setChecked(TrainingPlanStore.isEnabled(this));
        selectedStartDate = TrainingPlanStore.getStartDate(this);
        startDateButton.setText("START: " + formatDate(selectedStartDate));
        int minutes = TrainingPlanStore.getMinutesPerDay(this);
        minutesSeek.setProgress(Math.max(0, Math.min(11, minutes / 5 - 1)));
        minutesLabel.setText(minutes + " minute / sesiune");
        int mask = TrainingPlanStore.getWeekMask(this);
        for (int i = 0; i < weekdayChecks.length; i++) weekdayChecks[i].setChecked((mask & (1 << i)) != 0);

        boolean hasProgress = TrainingPlanStore.getCompletedSessions(this) > 0;
        startDateButton.setEnabled(!hasProgress);
        if (hasProgress) startDateButton.setText(startDateButton.getText() + " • blocată după începere");

        if (PlacementProfileStore.isCompleted(this)) {
            placementCard.setText("TEST EFECTUAT\n" + PlacementProfileStore.compactSummary(this)
                    + "\nTestele repetate sunt păstrate pentru comparație; un program deja început nu este repoziționat.");
            placementButton.setText("REPETĂ TESTUL DE VERIFICARE");
        } else {
            placementCard.setText("NEEFECTUAT\nProgramul este blocat până când aplicația măsoară spanul vizual, spanul semantic și expunerea stabilă.");
            placementButton.setText("PORNEȘTE TESTUL INIȚIAL");
        }
    }

    private void chooseDate() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(selectedStartDate);
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(year, month, dayOfMonth, 0, 0, 0);
            picked.set(Calendar.MILLISECOND, 0);
            selectedStartDate = picked.getTimeInMillis();
            startDateButton.setText("START: " + formatDate(selectedStartDate));
            refreshCalculation();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void refreshCalculation() {
        if (calculationCard == null || minutesSeek == null) return;
        int minutes = (minutesSeek.getProgress() + 1) * 5;
        int mask = selectedMask();
        int completed = TrainingPlanStore.getCompletedSessions(this);
        int sessionDay = TrainingPlanStore.getCurrentDay(this);
        int level = TrainingPlanStore.getCurrentLevel(this);
        ExerciseLibrary.DayPlan plan = ExerciseLibrary.getDayPlan(level);
        int trials = recommendedTrials(minutes);
        long next = previewNextDate(selectedStartDate, mask, completed);
        long end = previewFinalDate(next, mask, ExerciseLibrary.PROGRAM_DAYS - completed);
        int activeDays = Integer.bitCount(mask == 0 ? TrainingPlanStore.ALL_DAYS_MASK : mask);
        int weeklyMinutes = activeDays * minutes;

        String status = completed >= ExerciseLibrary.PROGRAM_DAYS
                ? "PROGRAM FINALIZAT • 30/30 sesiuni"
                : "Sesiune curentă: " + sessionDay + "/30 • nivel " + level + "/30 — " + plan.title;
        calculationCard.setText(String.format(Locale.getDefault(),
                "%s\nNivel de start din test: %d/30\nMinute/sesiune: %d • ~%d expuneri verificate\nRitm: %d zile/săptămână • ~%d min/săptămână\nVolum lunar: %d minute • ~%d expuneri\nUrmătoarea dată eligibilă: %s\nFinal minim proiectat: %s\nÎncercări la nivelul curent: %d\n\nFinalul se prelungește automat dacă Mastery Gate cere repetarea unui nivel.",
                status,
                TrainingPlanStore.getPlacementStartLevel(this),
                minutes,
                trials,
                activeDays,
                weeklyMinutes,
                minutes * ExerciseLibrary.PROGRAM_DAYS,
                trials * ExerciseLibrary.PROGRAM_DAYS,
                formatDate(next),
                formatDate(end),
                TrainingPlanStore.getCurrentAttempts(this)));
        renderLibrary(level);
    }

    private void renderLibrary(int currentLevel) {
        if (libraryRoot == null) return;
        libraryRoot.removeAllViews();
        int startLevel = TrainingPlanStore.getPlacementStartLevel(this);
        for (int level = 1; level <= ExerciseLibrary.PROGRAM_DAYS; level++) {
            ExerciseLibrary.DayPlan plan = ExerciseLibrary.getDayPlan(level);
            String status;
            if (level < startLevel) status = "[VALIDAT TEST]";
            else if (level < currentLevel) status = "[TRECUT]";
            else if (level == currentLevel) status = "[ACUM]";
            else status = "[BLOCAT]";
            String line = String.format(Locale.getDefault(),
                    "%s Nivel %02d • %s\n%s • %d ms • %d cuv.%s",
                    status, level, plan.title, plan.phase, plan.exposureMs, plan.chunkWords,
                    ExerciseLibrary.requiresSemanticCheck(level) ? " • SEMANTIC" : "");
            TextView card = body(line);
            card.setTextColor(level <= currentLevel ? Color.rgb(52, 42, 34) : Color.rgb(125, 112, 98));
            card.setBackgroundColor(level == currentLevel ? Color.rgb(246, 235, 207) : Color.rgb(250, 247, 239));
            card.setPadding(dp(11), dp(9), dp(11), dp(9));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(5);
            libraryRoot.addView(card, lp);
        }
    }

    private void savePlan() {
        int mask = selectedMask();
        if (mask == 0) {
            Toast.makeText(this, "Selectează cel puțin o zi de antrenament.", Toast.LENGTH_LONG).show();
            return;
        }
        TrainingPlanStore.setEnabled(this, enabledCheck.isChecked());
        if (TrainingPlanStore.getCompletedSessions(this) == 0) TrainingPlanStore.setStartDate(this, selectedStartDate);
        TrainingPlanStore.setMinutesPerDay(this, (minutesSeek.getProgress() + 1) * 5);
        TrainingPlanStore.setWeekMask(this, mask);
        if (enabledCheck.isChecked() && !PlacementProfileStore.isCompleted(this)) {
            Toast.makeText(this, "Plan salvat. Efectuează testul inițial înainte de prima sesiune.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Planul profesional a fost salvat.", Toast.LENGTH_SHORT).show();
        }
        refreshCalculation();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
                .setTitle("Resetezi cele 30 de sesiuni?")
                .setMessage("Se resetează sesiunile promovate și încercările Mastery Gate. Profilul testului de plasare și istoricul rămân; programul va porni din nou de la nivelul recomandat de ultimul test.")
                .setNegativeButton("ANULEAZĂ", null)
                .setPositiveButton("RESETEAZĂ", (dialog, which) -> {
                    TrainingPlanStore.resetProgress(this);
                    startDateButton.setEnabled(true);
                    refreshCalculation();
                })
                .show();
    }

    private int selectedMask() {
        int mask = 0;
        for (int i = 0; i < weekdayChecks.length; i++) if (weekdayChecks[i] != null && weekdayChecks[i].isChecked()) mask |= 1 << i;
        return mask;
    }

    private int recommendedTrials(int minutes) {
        int base = Math.max(20, Math.min(100, minutes * 3));
        return Math.min(100, ((base + 9) / 10) * 10);
    }

    private long previewNextDate(long start, int mask, int completed) {
        long today = startOfDay(System.currentTimeMillis());
        long cursor = Math.max(startOfDay(start), today);
        long lastMastered = TrainingPlanStore.getLastMasteredDate(this);
        if (completed > 0 && lastMastered > 0L && lastMastered >= cursor) cursor = addDays(lastMastered, 1);
        return nextAllowed(cursor, mask);
    }

    private long previewFinalDate(long next, int mask, int remaining) {
        if (remaining <= 1) return next;
        long cursor = next;
        for (int i = 1; i < remaining; i++) cursor = nextAllowed(addDays(cursor, 1), mask);
        return cursor;
    }

    private long nextAllowed(long start, int mask) {
        long cursor = startOfDay(start);
        int safeMask = mask == 0 ? TrainingPlanStore.ALL_DAYS_MASK : mask;
        for (int i = 0; i < 370; i++) {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(cursor);
            if ((safeMask & TrainingPlanStore.dayBitForCalendar(c.get(Calendar.DAY_OF_WEEK))) != 0) return cursor;
            cursor = addDays(cursor, 1);
        }
        return cursor;
    }

    private long startOfDay(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private long addDays(long millis, int days) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        c.add(Calendar.DAY_OF_MONTH, days);
        return startOfDay(c.getTimeInMillis());
    }

    private String formatDate(long millis) {
        return new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date(millis));
    }

    private void section(LinearLayout root, String text) {
        TextView label = body(text);
        label.setTextColor(Color.rgb(72, 47, 31));
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setPadding(0, dp(16), 0, dp(6));
        root.addView(label);
    }

    private TextView body(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(88, 70, 54));
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        view.setLineSpacing(0f, 1.14f);
        return view;
    }

    private CheckBox check(String text) {
        CheckBox checkBox = new CheckBox(this);
        checkBox.setText(text);
        checkBox.setTextColor(Color.rgb(65, 49, 37));
        checkBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        return checkBox;
    }

    private Button button(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(ColorStateList.valueOf(color));
        return button;
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
