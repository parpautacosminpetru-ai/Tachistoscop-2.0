package ro.tachistoscop.app;

import java.util.Locale;

/**
 * Test adaptiv în două etape:
 * 1) găsește spanul semantic stabil la timp fix;
 * 2) verifică timpul minim stabil la spanul găsit.
 */
public final class PlacementEngine {
    public enum Stage { SPAN, SPEED, FINISHED }

    private static final int BLOCK = 4;
    private static final int SPAN_EXPOSURE_MS = 220;
    private static final int[] SPEEDS = {250, 220, 200, 180, 160, 150};

    private Stage stage = Stage.SPAN;
    private int targetWords = 4;
    private int bestVisualSpan = 2;
    private int bestSemanticSpan = 2;
    private int stableExposureMs = 250;
    private int speedIndex = 1;
    private boolean semanticSpanDemonstrated = false;

    private int blockCount;
    private float blockRecallSum;
    private int blockSemanticCorrect;

    private int totalCount;
    private float totalRecallSum;
    private int totalSemanticCorrect;
    private long totalResponseMs;
    private float maxWidthPercent;

    public Stage getStage() { return stage; }
    public boolean isFinished() { return stage == Stage.FINISHED; }
    public int getTargetWords() { return targetWords; }
    public int getExposureMs() { return stage == Stage.SPAN ? SPAN_EXPOSURE_MS : SPEEDS[speedIndex]; }
    public int getTrialNumber() { return totalCount + 1; }

    public String getStageLabel() {
        if (stage == Stage.SPAN) return "ETAPA 1/2 • SPAN VIZUAL + SEMANTIC";
        if (stage == Stage.SPEED) return "ETAPA 2/2 • VITEZĂ STABILĂ";
        return "TEST FINALIZAT";
    }

    public void addResult(float recallAccuracy, boolean semanticCorrect, long responseMs, float widthPercent) {
        if (isFinished()) return;
        float recall = clamp(recallAccuracy);
        blockCount++;
        blockRecallSum += recall;
        if (semanticCorrect) blockSemanticCorrect++;
        totalCount++;
        totalRecallSum += recall;
        if (semanticCorrect) totalSemanticCorrect++;
        totalResponseMs += Math.max(0L, responseMs);
        maxWidthPercent = Math.max(maxWidthPercent, Math.max(0f, widthPercent));

        if (blockCount < BLOCK) return;

        float recallAvg = blockRecallSum / BLOCK;
        float semanticRate = blockSemanticCorrect / (float) BLOCK;
        boolean visualComfort = recallAvg >= 0.90f;
        boolean semanticComfort = visualComfort && semanticRate >= 0.75f;

        if (stage == Stage.SPAN) {
            if (visualComfort) bestVisualSpan = Math.max(bestVisualSpan, targetWords);
            if (semanticComfort) {
                bestSemanticSpan = Math.max(bestSemanticSpan, targetWords);
                semanticSpanDemonstrated = true;
            }

            if (semanticComfort && targetWords < 12) {
                targetWords = Math.min(12, targetWords + 2);
            } else {
                targetWords = Math.max(2, bestSemanticSpan);
                stage = Stage.SPEED;
                if (semanticSpanDemonstrated) {
                    // 220 ms a fost deja demonstrat la spanul ales; nu repetăm inutil blocul.
                    stableExposureMs = 220;
                    speedIndex = 2; // începem direct cu 200 ms
                } else {
                    // Dacă nici 4 cuvinte nu au fost confortabile, măsurăm separat spanul de 2 cuvinte.
                    stableExposureMs = 250;
                    speedIndex = 0;
                }
            }
        } else if (stage == Stage.SPEED) {
            if (semanticComfort) {
                stableExposureMs = SPEEDS[speedIndex];
                if (speedIndex < SPEEDS.length - 1) speedIndex++;
                else stage = Stage.FINISHED;
            } else {
                stage = Stage.FINISHED;
            }
        }

        blockCount = 0;
        blockRecallSum = 0f;
        blockSemanticCorrect = 0;
    }

    public PlacementProfileStore.Profile buildProfile() {
        PlacementProfileStore.Profile profile = new PlacementProfileStore.Profile();
        profile.timestamp = System.currentTimeMillis();
        profile.visualSpanWords = Math.max(1, bestVisualSpan);
        profile.semanticSpanWords = Math.max(1, bestSemanticSpan);
        profile.stableExposureMs = stableExposureMs;
        profile.recallAccuracy = totalCount == 0 ? 0f : totalRecallSum / totalCount;
        profile.semanticAccuracy = totalCount == 0 ? 0f : totalSemanticCorrect / (float) totalCount;
        profile.averageResponseMs = totalCount == 0 ? 0L : totalResponseMs / totalCount;
        profile.widthPercent = maxWidthPercent;
        profile.recommendedStartLevel = recommendedLevel(profile.semanticSpanWords, profile.stableExposureMs);
        return profile;
    }

    public String liveSummary() {
        float recall = totalCount == 0 ? 0f : totalRecallSum / totalCount;
        float semantic = totalCount == 0 ? 0f : totalSemanticCorrect / (float) totalCount;
        return String.format(Locale.getDefault(),
                "Probe %d • recall %.0f%% • semantic %.0f%% • span stabil %d cuv.",
                totalCount, recall * 100f, semantic * 100f, bestSemanticSpan);
    }

    private int recommendedLevel(int span, int exposureMs) {
        int level;
        if (span <= 2) level = 5;
        else if (span == 3) level = 9;
        else if (span == 4) level = 12;
        else if (span == 5) level = 15;
        else if (span == 6) level = 18;
        else if (span == 7) level = 21;
        else if (span == 8) level = 23;
        else if (span == 9) level = 25;
        else if (span == 10) level = 27;
        else if (span == 11) level = 28;
        else level = 29;

        if (exposureMs <= 180) level++;
        if (exposureMs <= 160) level++;
        return Math.max(1, Math.min(30, level));
    }

    private float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
