package ro.tachistoscop.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Bibliotecă offline pentru 30 de niveluri de dificultate. */
public final class ExerciseLibrary {
    public static final int PROGRAM_DAYS = 30;

    public static final int KIND_SYLLABLES = 0;
    public static final int KIND_WORDS = 1;
    public static final int KIND_DIGITS = 2;
    public static final int KIND_PHRASES = 3;
    public static final int KIND_PERIPHERAL = 4;

    public static final class DayPlan {
        public final int day; // nivel de dificultate 1..30
        public final String phase;
        public final String title;
        public final String description;
        public final int kind;
        public final int chunkWords;
        public final int exposureMs;
        public final int fixationMs;
        public final boolean evaluation;

        DayPlan(int day, String phase, String title, String description, int kind,
                int chunkWords, int exposureMs, int fixationMs, boolean evaluation) {
            this.day = day;
            this.phase = phase;
            this.title = title;
            this.description = description;
            this.kind = kind;
            this.chunkWords = chunkWords;
            this.exposureMs = exposureMs;
            this.fixationMs = fixationMs;
            this.evaluation = evaluation;
        }

        public String shortLabel() {
            return "Nivel " + day + " • " + title;
        }
    }

    private static final String[] SYLLABLES = {
            "MA", "ME", "MI", "MO", "MU", "RA", "RE", "RI", "RO", "RU",
            "PA", "PE", "PI", "PO", "PU", "TA", "TE", "TI", "TO", "TU",
            "LA", "LE", "LI", "LO", "LU", "CA", "CE", "CI", "CO", "CU",
            "BRA", "BRE", "BRI", "BRO", "BRU", "CRA", "CRE", "CRI", "CRO", "CRU",
            "DRA", "DRE", "DRI", "DRO", "DRU", "FRA", "FRE", "FRI", "FRO", "FRU",
            "GRA", "GRE", "GRI", "GRO", "GRU", "PLA", "PLE", "PLI", "PLO", "PLU",
            "TRA", "TRE", "TRI", "TRO", "TRU", "STA", "STE", "STI", "STO", "STU"
    };

    private static final String[] WORDS = {
            "casă", "carte", "drum", "masă", "parc", "munte", "râu", "soare", "lună", "cer",
            "timp", "ritm", "sens", "text", "pagină", "linie", "semn", "punct", "cadru", "fereastră",
            "atenție", "memorie", "privire", "lectură", "viteză", "precizie", "focalizare", "percepție", "înțelegere", "concentrare",
            "rapid", "clar", "stabil", "simplu", "direct", "scurt", "larg", "central", "vizual", "corect",
            "citesc", "observ", "recunosc", "fixez", "compar", "rețin", "aleg", "urmez", "verific", "continui",
            "dimineață", "seară", "lumină", "umbră", "culoare", "formă", "spațiu", "mișcare", "direcție", "distanță",
            "idee", "frază", "mesaj", "cuvânt", "silabă", "propoziție", "capitol", "autor", "subiect", "detaliu",
            "energie", "efort", "calm", "pauză", "progres", "nivel", "exercițiu", "răspuns", "rezultat", "antrenament"
    };

    private static final String[] SENTENCES = {
            "citirea rapidă cere atenție stabilă și percepție vizuală clară",
            "privirea rămâne calmă în centrul zonei de expunere",
            "grupurile de cuvinte sunt recunoscute fără reveniri inutile",
            "ritmul crește numai după ce răspunsul devine sigur",
            "precizia are prioritate înaintea unei viteze mai mari",
            "memoria vizuală păstrează pentru scurt timp forma expresiei",
            "ochii urmăresc sensul fără să se oprească la fiecare literă",
            "un cititor atent observă simultan mai multe elemente apropiate",
            "antrenamentul consecvent face percepția mai stabilă și mai rapidă",
            "pauzele scurte mențin concentrarea bună în timpul sesiunii",
            "textul este perceput ca structură și nu ca litere izolate",
            "răspunsul corect confirmă că stimulul a fost recunoscut precis",
            "dificultatea crește treptat când nivelul actual este confortabil",
            "focalizarea centrală ajută la controlul mișcărilor inutile ale privirii",
            "câmpul vizual poate cuprinde elemente aflate în stânga și dreapta",
            "viteza utilă păstrează în același timp sensul și acuratețea",
            "fiecare sesiune oferă date pentru compararea progresului personal",
            "expunerea scurtă solicită recunoaștere imediată și atenție concentrată",
            "frazele familiare devin mai ușor de procesat în grupuri",
            "citirea eficientă combină percepția rapidă cu înțelegerea textului"
    };

    private static final String[] DIGIT_GROUPS = {
            "381", "742", "596", "214", "865", "437", "920", "653", "178", "504",
            "3817", "7429", "5962", "2148", "8653", "4371", "9206", "6534", "1785", "5042",
            "38174", "74295", "59621", "21486", "86537", "43710", "92064", "65348", "17852", "50429"
    };

    private ExerciseLibrary() { }

    public static DayPlan getDayPlan(int requestedLevel) {
        int level = Math.max(1, Math.min(PROGRAM_DAYS, requestedLevel));
        switch (level) {
            case 1:  return p(level, "FUNDAMENT", "Silabe", "Fixează centrul și recunoaște silabe fără anticipare.", KIND_SYLLABLES, 1, 300, 550, false);
            case 2:  return p(level, "FUNDAMENT", "Un cuvânt", "Cuvinte tipărite ca text de carte, cu precizie completă.", KIND_WORDS, 1, 300, 500, false);
            case 3:  return p(level, "FUNDAMENT", "Un cuvânt 250", "Aceeași lățime, timp mai scurt.", KIND_WORDS, 1, 250, 500, false);
            case 4:  return p(level, "FUNDAMENT", "Un cuvânt 200", "Consolidează recunoașterea rapidă a cuvintelor.", KIND_WORDS, 1, 200, 500, false);
            case 5:  return p(level, "GRUPARE", "Două cuvinte", "Extinde spanul la două cuvinte înainte de accelerare.", KIND_PHRASES, 2, 300, 520, false);
            case 6:  return p(level, "GRUPARE", "Două cuvinte 250", "Păstrează aceeași lățime și scurtează expunerea.", KIND_PHRASES, 2, 250, 500, false);
            case 7:  return p(level, "GRUPARE", "Două cuvinte 200", "Două cuvinte trebuie percepute complet și în ordine.", KIND_PHRASES, 2, 200, 500, true);
            case 8:  return p(level, "GRUPARE", "Trei cuvinte", "Crește spanul la trei cuvinte fără reducerea simultană a timpului.", KIND_PHRASES, 3, 300, 520, false);
            case 9:  return p(level, "GRUPARE", "Trei cuvinte 250", "Stabilizează trei cuvinte la expunere moderată.", KIND_PHRASES, 3, 250, 500, false);
            case 10: return p(level, "GRUPARE", "Trei cuvinte 220", "Recunoaștere exactă și răspuns stabil.", KIND_PHRASES, 3, 220, 500, false);
            case 11: return p(level, "CÂMP VIZUAL", "Trei cuvinte periferice", "Păstrează fixația centrală și percepe lateral.", KIND_PERIPHERAL, 3, 250, 650, false);
            case 12: return p(level, "RÂND", "Patru cuvinte", "Caseta se lărgește înainte ca fontul să fie redus.", KIND_PHRASES, 4, 280, 520, false);
            case 13: return p(level, "RÂND", "Patru cuvinte 240", "Aceeași lățime, expunere mai scurtă.", KIND_PHRASES, 4, 240, 500, false);
            case 14: return p(level, "SEMANTIC", "Patru cuvinte + sens", "Reproducerea și sensul trebuie confirmate separat.", KIND_PHRASES, 4, 220, 520, true);
            case 15: return p(level, "SEMANTIC", "Cinci cuvinte", "Extinde spanul semantic la cinci cuvinte.", KIND_PHRASES, 5, 260, 520, false);
            case 16: return p(level, "SEMANTIC", "Cinci cuvinte 220", "Consolidează sensul fără pierderea ordinii.", KIND_PHRASES, 5, 220, 500, false);
            case 17: return p(level, "SEMANTIC", "Șase cuvinte", "Rând mai larg, font de carte constant cât permite ecranul.", KIND_PHRASES, 6, 260, 520, false);
            case 18: return p(level, "SEMANTIC", "Șase cuvinte 220", "Accelerează numai după stabilizarea lățimii.", KIND_PHRASES, 6, 220, 500, false);
            case 19: return p(level, "SEMANTIC", "Șapte cuvinte", "Span semantic extins la șapte cuvinte.", KIND_PHRASES, 7, 260, 520, false);
            case 20: return p(level, "SEMANTIC", "Șapte cuvinte 220", "Păstrează recall și sens la timp mai scurt.", KIND_PHRASES, 7, 220, 500, false);
            case 21: return p(level, "EVALUARE", "Opt cuvinte", "Prag intermediar spre perceperea unui rând complet.", KIND_PHRASES, 8, 260, 550, true);
            case 22: return p(level, "RÂND", "Opt cuvinte 220", "Folosește aproape toată lățimea utilă înainte de micșorarea fontului.", KIND_PHRASES, 8, 220, 520, false);
            case 23: return p(level, "RÂND", "Nouă cuvinte", "Extinde lățimea funcțională la nouă cuvinte.", KIND_PHRASES, 9, 250, 520, false);
            case 24: return p(level, "RÂND", "Nouă cuvinte 210", "Stabilizează nouă cuvinte cu sens.", KIND_PHRASES, 9, 210, 500, false);
            case 25: return p(level, "RÂND", "Zece cuvinte", "Rând de carte scurt, perceput într-o singură expunere.", KIND_PHRASES, 10, 250, 540, false);
            case 26: return p(level, "RÂND", "Zece cuvinte 210", "Accelerează fără a reduce pragul semantic.", KIND_PHRASES, 10, 210, 520, false);
            case 27: return p(level, "RÂND", "Unsprezece cuvinte", "Rând aproape complet, cu margini largi ale câmpului vizual.", KIND_PHRASES, 11, 240, 550, false);
            case 28: return p(level, "RÂND", "Unsprezece cuvinte 200", "Consolidează lățimea la timp redus.", KIND_PHRASES, 11, 200, 530, false);
            case 29: return p(level, "RÂND COMPLET", "Douăsprezece cuvinte", "Obiectiv: un rând de carte scurt perceput și înțeles stabil.", KIND_PHRASES, 12, 240, 560, false);
            case 30:
            default: return p(level, "EVALUARE FINALĂ", "Rând complet 200", "Nivel final: 12 cuvinte, reproducere precisă și sens confirmat.", KIND_PHRASES, 12, 200, 580, true);
        }
    }

    private static DayPlan p(int level, String phase, String title, String description, int kind,
                             int chunkWords, int exposureMs, int fixationMs, boolean evaluation) {
        return new DayPlan(level, phase, title, description, kind, chunkWords, exposureMs, fixationMs, evaluation);
    }

    public static boolean requiresSemanticCheck(int level) {
        return Math.max(1, level) >= 14;
    }

    public static boolean isMonthlyCheckpoint(int sessionDay) {
        return sessionDay == 1 || sessionDay == 7 || sessionDay == 14 || sessionDay == 21 || sessionDay == 30;
    }

    public static List<String> getStimuliForDay(int level) {
        DayPlan plan = getDayPlan(level);
        if (requiresSemanticCheck(level) && plan.kind == KIND_PHRASES) {
            return SemanticItemRepository.textsClosest(plan.chunkWords);
        }
        switch (plan.kind) {
            case KIND_SYLLABLES:
                return rotated(Arrays.asList(SYLLABLES), level * 5);
            case KIND_DIGITS:
                return buildDigitStimuli(plan.chunkWords, level);
            case KIND_PERIPHERAL:
                return buildPeripheralStimuli(plan.chunkWords, level);
            case KIND_PHRASES:
                return buildPhraseChunks(plan.chunkWords, level);
            case KIND_WORDS:
            default:
                return rotated(Arrays.asList(WORDS), level * 7);
        }
    }

    private static List<String> buildPhraseChunks(int chunkWords, int level) {
        List<String> words = new ArrayList<>();
        for (String sentence : SENTENCES) words.addAll(Arrays.asList(sentence.split("\\s+")));
        if (words.isEmpty()) return Collections.emptyList();
        int shift = (level * 11) % words.size();
        List<String> shifted = new ArrayList<>(words.size());
        for (int i = 0; i < words.size(); i++) shifted.add(words.get((i + shift) % words.size()));

        int chunk = Math.max(1, Math.min(12, chunkWords));
        List<String> result = new ArrayList<>();
        for (int i = 0; i + chunk <= shifted.size(); i += chunk) {
            StringBuilder builder = new StringBuilder();
            for (int j = 0; j < chunk; j++) {
                if (builder.length() > 0) builder.append(' ');
                builder.append(shifted.get(i + j));
            }
            result.add(builder.toString());
        }
        return result;
    }

    private static List<String> buildPeripheralStimuli(int totalWords, int level) {
        List<String> words = rotated(Arrays.asList(WORDS), level * 13);
        int total = Math.max(2, Math.min(8, totalWords));
        int leftCount = total / 2;
        int rightCount = total - leftCount;
        List<String> result = new ArrayList<>();
        int cursor = 0;
        while (cursor + total <= words.size()) {
            StringBuilder left = new StringBuilder();
            StringBuilder right = new StringBuilder();
            for (int i = 0; i < leftCount; i++) {
                if (left.length() > 0) left.append(' ');
                left.append(words.get(cursor++));
            }
            for (int i = 0; i < rightCount; i++) {
                if (right.length() > 0) right.append(' ');
                right.append(words.get(cursor++));
            }
            result.add(left + " ¦ " + right);
        }
        return result;
    }

    private static List<String> buildDigitStimuli(int groups, int level) {
        List<String> source = rotated(Arrays.asList(DIGIT_GROUPS), level * 3);
        int count = Math.max(1, Math.min(3, groups));
        List<String> result = new ArrayList<>();
        for (int i = 0; i + count <= source.size(); i += count) {
            StringBuilder builder = new StringBuilder();
            for (int j = 0; j < count; j++) {
                if (builder.length() > 0) builder.append(' ');
                builder.append(source.get(i + j));
            }
            result.add(builder.toString());
        }
        return result;
    }

    private static List<String> rotated(List<String> source, int shift) {
        if (source.isEmpty()) return Collections.emptyList();
        int normalized = ((shift % source.size()) + source.size()) % source.size();
        List<String> result = new ArrayList<>(source.size());
        for (int i = 0; i < source.size(); i++) result.add(source.get((i + normalized) % source.size()));
        return result;
    }
}
