package ro.tachistoscop.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Calendarul lunar are 30 de sesiuni promovate. Nivelul de dificultate este separat
 * de numărul sesiunii, astfel încât testul de plasare poate porni direct de la un
 * nivel avansat fără a scurta luna de antrenament.
 */
public final class TrainingPlanStore {
    private static final String PREFS = "tachistoscop_intensive_plan";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_START_DATE = "start_date";
    private static final String KEY_MINUTES = "minutes_per_day";
    private static final String KEY_WEEK_MASK = "week_mask";
    // Păstrăm cheia veche pentru compatibilitate; acum reprezintă sesiuni promovate.
    private static final String KEY_MASTERED_DAYS = "mastered_days";
    private static final String KEY_CURRENT_LEVEL = "current_level";
    private static final String KEY_PLACEMENT_START_LEVEL = "placement_start_level";
    private static final String KEY_CURRENT_ATTEMPTS = "current_attempts";
    private static final String KEY_LAST_MASTERED_DATE = "last_mastered_date";
    private static final String KEY_LAST_ATTEMPT_DATE = "last_attempt_date";
    private static final String KEY_LAST_ATTEMPT_MASTERED = "last_attempt_mastered";

    public static final int ALL_DAYS_MASK = 0x7F;

    private TrainingPlanStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    public static long getStartDate(Context context) {
        long saved = prefs(context).getLong(KEY_START_DATE, 0L);
        return saved > 0L ? startOfDay(saved) : startOfDay(System.currentTimeMillis());
    }

    public static void setStartDate(Context context, long millis) {
        prefs(context).edit().putLong(KEY_START_DATE, startOfDay(millis)).apply();
    }

    public static int getMinutesPerDay(Context context) {
        return clamp(prefs(context).getInt(KEY_MINUTES, 20), 5, 60);
    }

    public static void setMinutesPerDay(Context context, int minutes) {
        int rounded = Math.round(clamp(minutes, 5, 60) / 5f) * 5;
        prefs(context).edit().putInt(KEY_MINUTES, clamp(rounded, 5, 60)).apply();
    }

    public static int getWeekMask(Context context) {
        int mask = prefs(context).getInt(KEY_WEEK_MASK, ALL_DAYS_MASK) & ALL_DAYS_MASK;
        return mask == 0 ? ALL_DAYS_MASK : mask;
    }

    public static void setWeekMask(Context context, int mask) {
        int safe = mask & ALL_DAYS_MASK;
        if (safe == 0) safe = ALL_DAYS_MASK;
        prefs(context).edit().putInt(KEY_WEEK_MASK, safe).apply();
    }

    public static int getCompletedSessions(Context context) {
        return clamp(prefs(context).getInt(KEY_MASTERED_DAYS, 0), 0, ExerciseLibrary.PROGRAM_DAYS);
    }

    /** Alias pentru codul/istoricul versiunilor anterioare. */
    public static int getMasteredDays(Context context) {
        return getCompletedSessions(context);
    }

    public static int getCurrentDay(Context context) {
        int completed = getCompletedSessions(context);
        return completed >= ExerciseLibrary.PROGRAM_DAYS ? ExerciseLibrary.PROGRAM_DAYS : completed + 1;
    }

    public static int getPlacementStartLevel(Context context) {
        int fallback = PlacementProfileStore.isCompleted(context)
                ? PlacementProfileStore.getLatest(context).recommendedStartLevel : 1;
        return clamp(prefs(context).getInt(KEY_PLACEMENT_START_LEVEL, fallback), 1, ExerciseLibrary.PROGRAM_DAYS);
    }

    public static int getCurrentLevel(Context context) {
        SharedPreferences sp = prefs(context);
        if (sp.contains(KEY_CURRENT_LEVEL)) {
            return clamp(sp.getInt(KEY_CURRENT_LEVEL, 1), 1, ExerciseLibrary.PROGRAM_DAYS);
        }
        int migrated = Math.max(getPlacementStartLevel(context), Math.min(ExerciseLibrary.PROGRAM_DAYS, getCompletedSessions(context) + 1));
        sp.edit().putInt(KEY_CURRENT_LEVEL, migrated).apply();
        return migrated;
    }

    public static void applyPlacementStart(Context context, int recommendedLevel) {
        int level = clamp(recommendedLevel, 1, ExerciseLibrary.PROGRAM_DAYS);
        // Repoziționarea este sigură numai înainte de prima sesiune promovată.
        if (getCompletedSessions(context) > 0) return;
        prefs(context).edit()
                .putInt(KEY_PLACEMENT_START_LEVEL, level)
                .putInt(KEY_CURRENT_LEVEL, level)
                .putInt(KEY_CURRENT_ATTEMPTS, 0)
                .apply();
    }

    public static boolean isFinished(Context context) {
        return getCompletedSessions(context) >= ExerciseLibrary.PROGRAM_DAYS;
    }

    public static int getCurrentAttempts(Context context) {
        return Math.max(0, prefs(context).getInt(KEY_CURRENT_ATTEMPTS, 0));
    }

    public static long getLastMasteredDate(Context context) {
        long saved = prefs(context).getLong(KEY_LAST_MASTERED_DATE, 0L);
        return saved > 0L ? startOfDay(saved) : 0L;
    }

    public static int getRecommendedTrials(Context context, int sessionDay) {
        int base = clamp(getMinutesPerDay(context) * 3, 20, 100);
        return Math.min(100, ((base + 9) / 10) * 10);
    }

    public static int getEstimatedTotalTrials(Context context) {
        int sum = 0;
        for (int day = 1; day <= ExerciseLibrary.PROGRAM_DAYS; day++) sum += getRecommendedTrials(context, day);
        return sum;
    }

    public static int getPlannedTotalMinutes(Context context) {
        return ExerciseLibrary.PROGRAM_DAYS * getMinutesPerDay(context);
    }

    public static long getNextTrainingDate(Context context) {
        if (isFinished(context)) {
            long last = prefs(context).getLong(KEY_LAST_MASTERED_DATE, 0L);
            return last > 0L ? startOfDay(last) : startOfDay(System.currentTimeMillis());
        }

        long start = getStartDate(context);
        long today = startOfDay(System.currentTimeMillis());
        long cursor = Math.max(start, today);
        long lastMastered = prefs(context).getLong(KEY_LAST_MASTERED_DATE, 0L);
        if (lastMastered > 0L && startOfDay(lastMastered) >= cursor) cursor = addDays(startOfDay(lastMastered), 1);
        return nextAllowedOnOrAfter(cursor, getWeekMask(context));
    }

    public static long getProjectedFinalDate(Context context) {
        int remaining = ExerciseLibrary.PROGRAM_DAYS - getCompletedSessions(context);
        if (remaining <= 0) return getNextTrainingDate(context);
        long date = getNextTrainingDate(context);
        int mask = getWeekMask(context);
        int counted = 1;
        while (counted < remaining) {
            date = nextAllowedOnOrAfter(addDays(date, 1), mask);
            counted++;
        }
        return date;
    }

    public static boolean isTrainingAllowedToday(Context context) {
        if (!isEnabled(context) || isFinished(context)) return false;
        long today = startOfDay(System.currentTimeMillis());
        return today >= getNextTrainingDate(context);
    }

    public static void recordAttempt(Context context, int sessionDay, boolean mastered) {
        if (!isEnabled(context) || isFinished(context)) return;
        int currentDay = getCurrentDay(context);
        if (sessionDay != currentDay) return;

        SharedPreferences.Editor editor = prefs(context).edit();
        editor.putLong(KEY_LAST_ATTEMPT_DATE, System.currentTimeMillis());
        editor.putBoolean(KEY_LAST_ATTEMPT_MASTERED, mastered);
        if (mastered) {
            int completed = Math.min(ExerciseLibrary.PROGRAM_DAYS, getCompletedSessions(context) + 1);
            int currentLevel = getCurrentLevel(context);
            int nextLevel = Math.min(ExerciseLibrary.PROGRAM_DAYS, currentLevel + 1);
            editor.putInt(KEY_MASTERED_DAYS, completed);
            editor.putInt(KEY_CURRENT_LEVEL, nextLevel);
            editor.putInt(KEY_CURRENT_ATTEMPTS, 0);
            editor.putLong(KEY_LAST_MASTERED_DATE, startOfDay(System.currentTimeMillis()));
        } else {
            editor.putInt(KEY_CURRENT_ATTEMPTS, getCurrentAttempts(context) + 1);
        }
        editor.apply();
    }

    public static void resetProgress(Context context) {
        int startLevel = PlacementProfileStore.isCompleted(context)
                ? PlacementProfileStore.getLatest(context).recommendedStartLevel : 1;
        prefs(context).edit()
                .putInt(KEY_MASTERED_DAYS, 0)
                .putInt(KEY_CURRENT_LEVEL, startLevel)
                .putInt(KEY_PLACEMENT_START_LEVEL, startLevel)
                .putInt(KEY_CURRENT_ATTEMPTS, 0)
                .remove(KEY_LAST_MASTERED_DATE)
                .remove(KEY_LAST_ATTEMPT_DATE)
                .remove(KEY_LAST_ATTEMPT_MASTERED)
                .apply();
    }

    public static void resetAll(Context context) {
        prefs(context).edit().clear().apply();
    }

    public static String formatDate(long millis) {
        return new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date(millis));
    }

    public static int dayBitForCalendar(int calendarDayOfWeek) {
        switch (calendarDayOfWeek) {
            case Calendar.MONDAY: return 1 << 0;
            case Calendar.TUESDAY: return 1 << 1;
            case Calendar.WEDNESDAY: return 1 << 2;
            case Calendar.THURSDAY: return 1 << 3;
            case Calendar.FRIDAY: return 1 << 4;
            case Calendar.SATURDAY: return 1 << 5;
            case Calendar.SUNDAY:
            default: return 1 << 6;
        }
    }

    private static long nextAllowedOnOrAfter(long startMillis, int mask) {
        long cursor = startOfDay(startMillis);
        for (int i = 0; i < 370; i++) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(cursor);
            if ((mask & dayBitForCalendar(calendar.get(Calendar.DAY_OF_WEEK))) != 0) return cursor;
            cursor = addDays(cursor, 1);
        }
        return cursor;
    }

    private static long startOfDay(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTimeInMillis();
    }

    private static long addDays(long millis, int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        calendar.add(Calendar.DAY_OF_MONTH, days);
        return startOfDay(calendar.getTimeInMillis());
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
