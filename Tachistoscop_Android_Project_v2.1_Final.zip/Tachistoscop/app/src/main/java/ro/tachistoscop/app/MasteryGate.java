package ro.tachistoscop.app;

import java.util.Locale;

/**
 * Poartă de promovare: cere performanță globală și două ferestre consecutive stabile.
 * Când nivelul are probe semantice, sensul devine criteriu obligatoriu separat.
 */
public final class MasteryGate {
    public static final int WINDOW_SIZE = 10;
    public static final int REQUIRED_CONSECUTIVE_WINDOWS = 2;
    public static final float ACCURACY_THRESHOLD = 0.95f;
    public static final float EXACT_THRESHOLD = 0.85f;
    public static final float SEMANTIC_WINDOW_THRESHOLD = 0.90f;
    public static final float SESSION_ACCURACY_THRESHOLD = 0.93f;
    public static final float SESSION_EXACT_THRESHOLD = 0.80f;
    public static final float SESSION_SEMANTIC_THRESHOLD = 0.90f;

    public static final class Result {
        public final boolean mastered;
        public final int consecutiveComfortWindows;
        public final float lastWindowAccuracy;
        public final float lastWindowExactRate;
        public final float semanticRate;
        public final String message;

        Result(boolean mastered, int consecutiveComfortWindows,
               float lastWindowAccuracy, float lastWindowExactRate, float semanticRate, String message) {
            this.mastered = mastered;
            this.consecutiveComfortWindows = consecutiveComfortWindows;
            this.lastWindowAccuracy = lastWindowAccuracy;
            this.lastWindowExactRate = lastWindowExactRate;
            this.semanticRate = semanticRate;
            this.message = message;
        }
    }

    private int windowCount;
    private float windowAccuracySum;
    private int windowExact;
    private int windowSemanticCount;
    private int windowSemanticCorrect;
    private int consecutiveComfortWindows;
    private float lastWindowAccuracy;
    private float lastWindowExactRate;
    private int sessionCount;
    private float sessionAccuracySum;
    private int sessionExact;
    private int sessionSemanticCount;
    private int sessionSemanticCorrect;

    public void reset() {
        windowCount = 0;
        windowAccuracySum = 0f;
        windowExact = 0;
        windowSemanticCount = 0;
        windowSemanticCorrect = 0;
        consecutiveComfortWindows = 0;
        lastWindowAccuracy = 0f;
        lastWindowExactRate = 0f;
        sessionCount = 0;
        sessionAccuracySum = 0f;
        sessionExact = 0;
        sessionSemanticCount = 0;
        sessionSemanticCorrect = 0;
    }

    public void add(float accuracy, boolean exact) {
        add(accuracy, exact, false, false);
    }

    public void add(float accuracy, boolean exact, boolean semanticScored, boolean semanticCorrect) {
        float safeAccuracy = clamp(accuracy);
        sessionCount++;
        sessionAccuracySum += safeAccuracy;
        if (exact) sessionExact++;
        if (semanticScored) {
            sessionSemanticCount++;
            if (semanticCorrect) sessionSemanticCorrect++;
        }

        windowCount++;
        windowAccuracySum += safeAccuracy;
        if (exact) windowExact++;
        if (semanticScored) {
            windowSemanticCount++;
            if (semanticCorrect) windowSemanticCorrect++;
        }

        if (windowCount >= WINDOW_SIZE) {
            lastWindowAccuracy = windowAccuracySum / WINDOW_SIZE;
            lastWindowExactRate = windowExact / (float) WINDOW_SIZE;
            float semanticRate = windowSemanticCount == 0 ? 1f : windowSemanticCorrect / (float) windowSemanticCount;
            boolean comfortable = lastWindowAccuracy >= ACCURACY_THRESHOLD
                    && lastWindowExactRate >= EXACT_THRESHOLD
                    && semanticRate >= SEMANTIC_WINDOW_THRESHOLD;
            consecutiveComfortWindows = comfortable ? consecutiveComfortWindows + 1 : 0;
            windowCount = 0;
            windowAccuracySum = 0f;
            windowExact = 0;
            windowSemanticCount = 0;
            windowSemanticCorrect = 0;
        }
    }

    public int getConsecutiveComfortWindows() {
        return consecutiveComfortWindows;
    }

    public float getSemanticRate() {
        return sessionSemanticCount == 0 ? 0f : sessionSemanticCorrect / (float) sessionSemanticCount;
    }

    public int getSemanticCount() {
        return sessionSemanticCount;
    }

    public String liveStatus() {
        String semantic = sessionSemanticCount > 0
                ? String.format(Locale.getDefault(), " • sens %.0f%% (prag %.0f%%)", getSemanticRate() * 100f, SESSION_SEMANTIC_THRESHOLD * 100f)
                : "";
        return String.format(Locale.getDefault(),
                "Mastery %d/%d ferestre • prag %.0f%% acuratețe + %.0f%% exact%s",
                Math.min(consecutiveComfortWindows, REQUIRED_CONSECUTIVE_WINDOWS),
                REQUIRED_CONSECUTIVE_WINDOWS,
                ACCURACY_THRESHOLD * 100f,
                EXACT_THRESHOLD * 100f,
                semantic);
    }

    public Result evaluate(int completedTrials, int targetTrials, boolean manualStop) {
        boolean fullSession = !manualStop && completedTrials >= targetTrials;
        float sessionAccuracy = sessionCount == 0 ? 0f : sessionAccuracySum / sessionCount;
        float sessionExactRate = sessionCount == 0 ? 0f : sessionExact / (float) sessionCount;
        float semanticRate = sessionSemanticCount == 0 ? 1f : sessionSemanticCorrect / (float) sessionSemanticCount;
        boolean overallComfort = sessionAccuracy >= SESSION_ACCURACY_THRESHOLD
                && sessionExactRate >= SESSION_EXACT_THRESHOLD
                && semanticRate >= SESSION_SEMANTIC_THRESHOLD;
        boolean mastered = fullSession && overallComfort
                && consecutiveComfortWindows >= REQUIRED_CONSECUTIVE_WINDOWS;

        String semanticPart = sessionSemanticCount == 0
                ? ""
                : String.format(Locale.getDefault(), ", sens %.0f%%", semanticRate * 100f);
        String message;
        if (mastered) {
            message = String.format(Locale.getDefault(),
                    "PROMOVAT: %.0f%% acuratețe, %.0f%% exact%s și două ferestre finale stabile.",
                    sessionAccuracy * 100f, sessionExactRate * 100f, semanticPart);
        } else if (!fullSession) {
            message = "NEPROMOVAT: sesiunea trebuie finalizată integral pentru deblocarea nivelului următor.";
        } else {
            message = String.format(Locale.getDefault(),
                    "REPETĂ NIVELUL: global %.0f%% acuratețe / %.0f%% exact%s; ferestre stabile %d/%d. Praguri: global ≥%.0f%%/%.0f%%%s și două ferestre ≥%.0f%%/%.0f%%.",
                    sessionAccuracy * 100f,
                    sessionExactRate * 100f,
                    semanticPart,
                    Math.min(consecutiveComfortWindows, REQUIRED_CONSECUTIVE_WINDOWS),
                    REQUIRED_CONSECUTIVE_WINDOWS,
                    SESSION_ACCURACY_THRESHOLD * 100f,
                    SESSION_EXACT_THRESHOLD * 100f,
                    sessionSemanticCount == 0 ? "" : String.format(Locale.getDefault(), "/%.0f%% sens", SESSION_SEMANTIC_THRESHOLD * 100f),
                    ACCURACY_THRESHOLD * 100f,
                    EXACT_THRESHOLD * 100f);
        }
        return new Result(mastered, consecutiveComfortWindows,
                lastWindowAccuracy, lastWindowExactRate,
                sessionSemanticCount == 0 ? 0f : semanticRate, message);
    }

    private float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
