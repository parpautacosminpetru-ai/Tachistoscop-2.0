package ro.tachistoscop.app;

/**
 * Reguli deterministe pentru afișarea tip „text de carte”.
 * Motorul de randare folosește aceste valori, apoi măsoară textul real cu TextPaint.
 */
public final class BookTextLayoutEngine {
    public static final int PRESET_SMALL = 0;
    public static final int PRESET_NORMAL = 1;
    public static final int PRESET_LARGE = 2;

    public static final float MIN_BOOK_FONT_SP = 18f;
    public static final float MAX_BOOK_FONT_SP = 34f;

    private BookTextLayoutEngine() { }

    public static float baseFontSp(int preset) {
        switch (preset) {
            case PRESET_SMALL: return 22f;
            case PRESET_LARGE: return 30f;
            case PRESET_NORMAL:
            default: return 26f;
        }
    }

    public static String presetLabel(int preset) {
        switch (preset) {
            case PRESET_SMALL: return "Carte mică";
            case PRESET_LARGE: return "Carte mare";
            case PRESET_NORMAL:
            default: return "Carte normală";
        }
    }

    public static int wordCount(String text) {
        String value = normalize(text).replace("¦", " ").trim();
        if (value.isEmpty()) return 0;
        return value.split("\\s+").length;
    }

    public static int characterCount(String text) {
        return normalize(text).replace("¦", "").length();
    }

    /**
     * Cât din lățimea disponibilă vrem să folosească mai întâi caseta.
     * Caseta crește înainte de reducerea fontului.
     */
    public static float targetWidthFraction(String text) {
        String value = normalize(text);
        if (value.contains("¦")) return 0.90f;
        int words = wordCount(value);
        int chars = characterCount(value);
        float byWords;
        if (words <= 1) byWords = 0.30f;
        else if (words == 2) byWords = 0.40f;
        else if (words == 3) byWords = 0.50f;
        else if (words == 4) byWords = 0.58f;
        else if (words == 5) byWords = 0.66f;
        else if (words == 6) byWords = 0.72f;
        else if (words == 7) byWords = 0.78f;
        else if (words == 8) byWords = 0.83f;
        else if (words == 9) byWords = 0.87f;
        else if (words == 10) byWords = 0.90f;
        else byWords = 0.94f;

        float byChars = Math.min(0.94f, Math.max(0.30f, 0.26f + chars * 0.0105f));
        return Math.max(byWords, byChars);
    }

    public static float clampBookFontSp(float requested) {
        return Math.max(MIN_BOOK_FONT_SP, Math.min(MAX_BOOK_FONT_SP, requested));
    }

    public static String normalize(String text) {
        return text == null ? "" : text.trim().replaceAll("\\s+", " ");
    }
}
