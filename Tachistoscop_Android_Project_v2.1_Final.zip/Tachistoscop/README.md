# Tachistoscop Pro 2.1 — Professional Intensive

Aplicație Android offline pentru antrenament tachistoscopic și citire rapidă, cu experiență inspirată de mecanica InfoSpeed și motor intern măsurabil pe cadre de ecran.

## Ce este nou în 2.1

- Test de plasare obligatoriu înainte de programul intensiv.
- Test în două etape: span vizual + semantic la 220 ms, apoi viteză stabilă la spanul demonstrat.
- Reproducere tastată + întrebare semantică pentru fiecare probă de plasare.
- Bancă semantică offline extinsă: peste 600 de stimuli; cel puțin 32 de itemi standardizați pentru fiecare lungime 4–12 cuvinte.
- Profil baseline și retest: span vizual, span semantic, expunere stabilă, recall, sens, timp de răspuns și lățime funcțională.
- Plasarea stabilește nivelul de start, dar nu consumă una dintre cele 30 de sesiuni de antrenament.
- 30 de sesiuni de antrenament și 30 de niveluri de dificultate separate. Dacă testul te plasează sus, cele 30 de sesiuni rămân disponibile pentru consolidarea nivelului relevant.
- Mastery Gate: nivelul nu avansează după simpla finalizare. Sunt necesare acuratețe globală și două ferestre consecutive stabile; la nivelurile semantice, sensul este criteriu obligatoriu.
- Text de carte: serif normal, preseturi 22 / 26 / 30 sp, casetă adaptivă și limită minimă 18 sp.
- Caseta se lărgește înainte ca fontul să fie redus.
- Pentru rândurile care nu încap integral la fontul minim, expunerea este blocată și aplicația cere orientare landscape; textul nu este expus tăiat.
- Rând complet: progresie până la 12 cuvinte și aproximativ 94% din lățimea utilă.
- Calendar exact: dată de start, 5–60 min/sesiune, zile din săptămână, volum estimat, următoarea dată și final minim proiectat.
- Benchmark/retest recomandat după sesiunile 1, 7, 14, 21 și 30.
- Ecran Progres: comparație baseline vs. ultimul test, sesiuni promovate, nivel curent, lățime funcțională și export CSV.
- Timing pe cadre cu `Choreographer`, refresh-rate detectat și durată măsurată raportată după flash.
- Complet offline, fără permisiune INTERNET; backup Android dezactivat.

## Flux recomandat

1. Intră în **PLAN** și setează data de start, minutele/sesiune și zilele de antrenament.
2. Pornește **TESTUL INIȚIAL**. Programul intensiv nu poate începe fără test.
3. Aplicația stabilește nivelul de start pe baza spanului semantic stabil și a vitezei stabile.
4. Rulează sesiunea curentă. După fiecare flash, reproduce textul; la nivelurile semantice răspunde și la întrebarea de sens.
5. Dacă Mastery Gate nu este trecut, aceeași sesiune/nivel se repetă. Nu există avans automat doar pentru că timpul a expirat.
6. La checkpoint-uri, repetă testul de verificare pentru comparație cu baseline-ul.
7. La final folosește **PROGRES** și/sau exportul CSV pentru comparația lunară.

## Mastery Gate

Pentru o sesiune completă:

- recall global ≥ 93%;
- răspunsuri exacte ≥ 80%;
- două ferestre consecutive de câte 10 probe cu recall ≥ 95% și exact ≥ 85%;
- dacă nivelul are test semantic: semantic global ≥ 90%, iar fiecare fereastră stabilă trebuie să atingă pragul semantic.

Aceste praguri sunt criterii interne de antrenament, nu validare clinică și nu reprezintă diagnostic medical.

## Text de carte și rând complet

Modul PRO folosește întotdeauna serif normal pentru comparații consistente. Utilizatorul alege baza:

- Carte mică: 22 sp
- Carte normală: 26 sp (implicit)
- Carte mare: 30 sp

Motorul mărește mai întâi caseta până aproape de lățimea utilă, apoi reduce fin fontul până la minimum 18 sp. Dacă rândul tot nu încape, flash-ul nu pornește și se recomandă rotirea telefonului în landscape. Astfel nu se măsoară accidental un rând tăiat.

## Build

Proiectul folosește:

- Android compile/target SDK 36
- Java 17
- `versionCode = 30`
- `versionName = 2.1.0`

Kitul GitHub include un `main.yml` care instalează SDK 36, extrage `Tachistoscop_Android_Project_v2.0.zip`, compilează `:app:assembleDebug`, calculează SHA-256 și publică APK-ul ca artifact.

## Confidențialitate

Aplicația nu solicită permisiunea INTERNET. Istoricul, planul și profilul de plasare rămân local pe dispozitiv. Exportul CSV se face prin selectorul standard Android.
