# Changelog

## 2.1.0 — Professional Placement + Semantic Span

- Test de plasare obligatoriu înainte de programul intensiv.
- Test adaptiv în două etape: span semantic și apoi viteză stabilă.
- Baseline și retest comparabil: span vizual, span semantic, ms, recall, sens, răspuns și lățime funcțională.
- Programul separă 30 de sesiuni de nivelul de dificultate; plasarea nu consumă sesiuni.
- Bancă semantică offline extinsă la peste 600 de itemi.
- Itemi standardizați 4–12 cuvinte pentru ca nivelul declarat să corespundă lungimii reale.
- Mastery Gate extins cu prag semantic.
- Text de carte standardizat: 22/26/30 sp, minimum adaptiv 18 sp.
- Casetă adaptivă la lungimea textului, până la ~94% din lățimea utilă.
- Protecție împotriva clipping-ului: rândul care nu încape integral nu este expus; se recomandă landscape.
- Rotația nu întrerupe sesiunea/testul principal (`configChanges`).
- Progres baseline vs. ultimul test și noi coloane CSV: sesiune, nivel, semantic, lățime.
- `versionCode 30`, `versionName 2.1.0`.

## 2.0.1 — Professional Intensive

- Program intensiv 30 niveluri, calendar, Mastery Gate, font/casetă adaptivă, istoric și export CSV.

## 2.0.0 — Pro Core

- Mod PRO, răspuns tastat, scorer, adaptare, timing pe cadre, sesiuni și istoric.
