package ro.tachistoscop.app;

import java.text.Normalizer;
import java.util.Locale;

public final class ResponseScorer {
    public static final class Score {
        public final String expectedNormalized;
        public final String actualNormalized;
        public final float wordAccuracy;
        public final boolean exact;

        Score(String expectedNormalized, String actualNormalized, float wordAccuracy, boolean exact) {
            this.expectedNormalized = expectedNormalized;
            this.actualNormalized = actualNormalized;
            this.wordAccuracy = wordAccuracy;
            this.exact = exact;
        }
    }

    private ResponseScorer() { }

    public static Score score(String expected, String actual) {
        String expectedNormalized = normalize(expected);
        String actualNormalized = normalize(actual);
        boolean exact = expectedNormalized.equals(actualNormalized) && !expectedNormalized.isEmpty();

        String[] expectedWords = tokenize(expectedNormalized);
        String[] actualWords = tokenize(actualNormalized);
        int denominator = Math.max(expectedWords.length, actualWords.length);
        float accuracy;
        if (denominator == 0) {
            accuracy = 0f;
        } else {
            int distance = levenshtein(expectedWords, actualWords);
            accuracy = Math.max(0f, 1f - (distance / (float) denominator));
        }

        return new Score(expectedNormalized, actualNormalized, accuracy, exact);
    }

    public static String normalize(String value) {
        if (value == null) return "";
        String decomposed = Normalizer.normalize(value, Normalizer.Form.NFD);
        StringBuilder builder = new StringBuilder(decomposed.length());
        boolean lastWasSpace = true;

        for (int i = 0; i < decomposed.length(); i++) {
            char c = decomposed.charAt(i);
            int type = Character.getType(c);
            if (type == Character.NON_SPACING_MARK ||
                    type == Character.COMBINING_SPACING_MARK ||
                    type == Character.ENCLOSING_MARK) {
                continue;
            }

            if (Character.isLetterOrDigit(c)) {
                builder.append(Character.toLowerCase(c));
                lastWasSpace = false;
            } else if (Character.isWhitespace(c) || Character.isSpaceChar(c) || isPunctuation(c)) {
                if (!lastWasSpace && builder.length() > 0) {
                    builder.append(' ');
                    lastWasSpace = true;
                }
            }
        }

        String normalized = builder.toString().trim().replaceAll("\\s+", " ");
        return normalized.toLowerCase(Locale.ROOT);
    }

    private static boolean isPunctuation(char c) {
        int type = Character.getType(c);
        return type == Character.CONNECTOR_PUNCTUATION ||
                type == Character.DASH_PUNCTUATION ||
                type == Character.START_PUNCTUATION ||
                type == Character.END_PUNCTUATION ||
                type == Character.INITIAL_QUOTE_PUNCTUATION ||
                type == Character.FINAL_QUOTE_PUNCTUATION ||
                type == Character.OTHER_PUNCTUATION;
    }

    private static String[] tokenize(String value) {
        if (value == null || value.isEmpty()) return new String[0];
        return value.split(" ");
    }

    private static int levenshtein(String[] left, String[] right) {
        int[] previous = new int[right.length + 1];
        int[] current = new int[right.length + 1];

        for (int j = 0; j <= right.length; j++) previous[j] = j;

        for (int i = 1; i <= left.length; i++) {
            current[0] = i;
            for (int j = 1; j <= right.length; j++) {
                int substitutionCost = left[i - 1].equals(right[j - 1]) ? 0 : 1;
                current[j] = Math.min(
                        Math.min(current[j - 1] + 1, previous[j] + 1),
                        previous[j - 1] + substitutionCost
                );
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }

        return previous[right.length];
    }
}
