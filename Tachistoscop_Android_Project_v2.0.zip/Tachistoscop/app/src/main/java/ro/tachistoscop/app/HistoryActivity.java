package ro.tachistoscop.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryActivity extends Activity {
    private static final int REQUEST_EXPORT_CSV = 2001;
    private LinearLayout contentRoot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(45, 31, 24));
        getWindow().setNavigationBarColor(Color.rgb(31, 24, 20));
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderHistory();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(240, 230, 210));
        SystemBarInsets.apply(scroll);

        contentRoot = new LinearLayout(this);
        contentRoot.setOrientation(LinearLayout.VERTICAL);
        contentRoot.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(contentRoot, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(scroll);
    }

    private void renderHistory() {
        contentRoot.removeAllViews();

        TextView title = new TextView(this);
        title.setText("PROGRES • TACHISTOSCOP PRO 2.0");
        title.setTextColor(Color.rgb(56, 39, 29));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 23);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setPadding(0, 0, 0, dp(12));
        contentRoot.addView(title);

        List<SessionStore.SessionRecord> records = SessionStore.load(this);
        if (records.isEmpty()) {
            TextView empty = makeBodyText("Nu există încă sesiuni salvate. Finalizează sau oprește o sesiune după cel puțin o expunere.");
            empty.setPadding(0, dp(12), 0, dp(20));
            contentRoot.addView(empty);
            addBackButton();
            return;
        }

        int totalTrials = 0;
        float weightedAccuracy = 0f;
        int totalProExact = 0;
        int totalClassicSeen = 0;
        int bestExposure = Integer.MAX_VALUE;
        long responseWeightedSum = 0L;
        int responseTrials = 0;

        for (SessionStore.SessionRecord record : records) {
            totalTrials += record.trials;
            weightedAccuracy += record.averageAccuracy * record.trials;
            if (record.trainingMode == AppPrefs.TRAINING_PRO) totalProExact += record.exactCorrect;
            else totalClassicSeen += record.exactCorrect;
            bestExposure = Math.min(bestExposure, record.endExposureMs);
            if (record.averageResponseMs > 0 && record.trials > 0) {
                responseWeightedSum += record.averageResponseMs * record.trials;
                responseTrials += record.trials;
            }
        }

        float overallAccuracy = totalTrials == 0 ? 0f : weightedAccuracy / totalTrials;
        long averageResponse = responseTrials == 0 ? 0L : responseWeightedSum / responseTrials;

        TextView summary = makeCardText(String.format(Locale.getDefault(),
                "SESIUNI: %d\nEXPUNERI: %d\nACURATEȚE GLOBALĂ: %.0f%%\nEXACTE PRO: %d\nPERCEPUTE CLASSIC: %d\nCEA MAI RAPIDĂ EXPUNERE FINALĂ: %d ms%s",
                records.size(),
                totalTrials,
                overallAccuracy * 100f,
                totalProExact,
                totalClassicSeen,
                bestExposure == Integer.MAX_VALUE ? 0 : bestExposure,
                averageResponse > 0 ? "\nRĂSPUNS MEDIU PRO: " + averageResponse + " ms" : ""));
        contentRoot.addView(summary, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView recentLabel = makeSectionLabel("Sesiuni recente");
        contentRoot.addView(recentLabel);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy • HH:mm", Locale.getDefault());
        int limit = Math.min(records.size(), 30);
        for (int i = 0; i < limit; i++) {
            SessionStore.SessionRecord record = records.get(i);
            String mode = record.trainingMode == AppPrefs.TRAINING_PRO ? "PRO" : "CLASSIC";
            String successLabel = record.trainingMode == AppPrefs.TRAINING_PRO ? "exact" : "percepute";
            String response = record.averageResponseMs > 0 ? " • răsp. " + record.averageResponseMs + " ms" : "";
            String adaptive = record.adaptive ? " • adaptiv" : "";
            String line = String.format(Locale.getDefault(),
                    "%s\n%s • %d exp. • %.0f%% • %s %d%s%s\n%d → %d ms • %d → %d cuv./bloc • %.1f Hz",
                    dateFormat.format(new Date(record.timestamp)),
                    mode,
                    record.trials,
                    record.averageAccuracy * 100f,
                    successLabel,
                    record.exactCorrect,
                    response,
                    adaptive,
                    record.startExposureMs,
                    record.endExposureMs,
                    record.startChunkWords,
                    record.endChunkWords,
                    record.refreshRateHz);
            TextView card = makeCardText(line);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(8);
            contentRoot.addView(card, lp);
        }

        Button export = new Button(this);
        export.setText("EXPORTĂ CSV");
        export.setTextColor(Color.WHITE);
        export.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(91, 57, 36)));
        export.setOnClickListener(v -> exportCsv());
        LinearLayout.LayoutParams exportLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        exportLp.topMargin = dp(16);
        contentRoot.addView(export, exportLp);

        Button clear = new Button(this);
        clear.setText("ȘTERGE ISTORICUL");
        clear.setTextColor(Color.WHITE);
        clear.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(118, 70, 49)));
        clear.setOnClickListener(v -> confirmClear());
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        clearLp.topMargin = dp(8);
        contentRoot.addView(clear, clearLp);

        addBackButton();
    }

    private void addBackButton() {
        Button back = new Button(this);
        back.setText("ÎNAPOI");
        back.setTextColor(Color.rgb(70, 48, 34));
        back.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(224, 210, 183)));
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(8);
        contentRoot.addView(back, lp);
    }

    private void exportCsv() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "tachistoscop_progres.csv");
        startActivityForResult(intent, REQUEST_EXPORT_CSV);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_EXPORT_CSV || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;

        List<SessionStore.SessionRecord> records = SessionStore.load(this);
        try (OutputStream stream = getContentResolver().openOutputStream(uri);
             OutputStreamWriter writer = stream == null ? null : new OutputStreamWriter(stream, StandardCharsets.UTF_8)) {
            if (writer == null) throw new IOException("Nu se poate deschide fișierul.");
            writer.write("timestamp;mode;trials;accuracy_percent;exact_or_seen;avg_response_ms;start_exposure_ms;end_exposure_ms;start_chunk;end_chunk;adaptive;refresh_hz\n");
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT);
            for (SessionStore.SessionRecord record : records) {
                writer.write(csv(format.format(new Date(record.timestamp))));
                writer.write(';');
                writer.write(record.trainingMode == AppPrefs.TRAINING_PRO ? "PRO" : "CLASSIC");
                writer.write(';');
                writer.write(Integer.toString(record.trials));
                writer.write(';');
                writer.write(String.format(Locale.ROOT, "%.1f", record.averageAccuracy * 100f));
                writer.write(';');
                writer.write(Integer.toString(record.exactCorrect));
                writer.write(';');
                writer.write(Long.toString(record.averageResponseMs));
                writer.write(';');
                writer.write(Integer.toString(record.startExposureMs));
                writer.write(';');
                writer.write(Integer.toString(record.endExposureMs));
                writer.write(';');
                writer.write(Integer.toString(record.startChunkWords));
                writer.write(';');
                writer.write(Integer.toString(record.endChunkWords));
                writer.write(';');
                writer.write(record.adaptive ? "1" : "0");
                writer.write(';');
                writer.write(String.format(Locale.ROOT, "%.1f", record.refreshRateHz));
                writer.write('\n');
            }
            writer.flush();
            Toast.makeText(this, "CSV exportat", Toast.LENGTH_SHORT).show();
        } catch (IOException exception) {
            Toast.makeText(this, "Export eșuat: " + exception.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String csv(String value) {
        String safe = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + safe + "\"";
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Ștergi istoricul?")
                .setMessage("Această acțiune șterge local toate sesiunile salvate.")
                .setNegativeButton("ANULEAZĂ", null)
                .setPositiveButton("ȘTERGE", (dialog, which) -> {
                    SessionStore.clear(this);
                    renderHistory();
                })
                .show();
    }

    private TextView makeSectionLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.rgb(72, 47, 31));
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setPadding(0, dp(18), 0, dp(4));
        return label;
    }

    private TextView makeBodyText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.rgb(88, 70, 54));
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        view.setLineSpacing(0f, 1.15f);
        return view;
    }

    private TextView makeCardText(String text) {
        TextView view = makeBodyText(text);
        view.setTextColor(Color.rgb(52, 42, 34));
        view.setBackgroundColor(Color.rgb(250, 246, 235));
        view.setPadding(dp(14), dp(12), dp(14), dp(12));
        view.setGravity(Gravity.START);
        return view;
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
