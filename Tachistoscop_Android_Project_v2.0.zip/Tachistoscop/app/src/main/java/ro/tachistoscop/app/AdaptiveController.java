package ro.tachistoscop.app;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AdaptiveController {
    public static final int WINDOW_SIZE = 5;
    public static final float ADVANCE_THRESHOLD = 0.90f;
    public static final float EASE_THRESHOLD = 0.65f;

    public static final class Decision {
        public final boolean changed;
        public final int exposureMs;
        public final int chunkWords;
        public final float windowAccuracy;
        public final String message;

        Decision(boolean changed, int exposureMs, int chunkWords, float windowAccuracy, String message) {
            this.changed = changed;
            this.exposureMs = exposureMs;
            this.chunkWords = chunkWords;
            this.windowAccuracy = windowAccuracy;
            this.message = message;
        }
    }

    private final List<Float> window = new ArrayList<>();

    public void reset() {
        window.clear();
    }

    public Decision add(float score, int currentExposureMs, int currentChunkWords, boolean chunkCanAdapt) {
        window.add(Math.max(0f, Math.min(1f, score)));
        if (window.size() < WINDOW_SIZE) {
            return new Decision(false, currentExposureMs, currentChunkWords, average(window), "");
        }

        float average = average(window);
        window.clear();

        int exposureIndex = AppPrefs.exposureIndexFor(currentExposureMs);
        int newExposure = currentExposureMs;
        int newChunk = currentChunkWords;
        String message;

        if (average >= ADVANCE_THRESHOLD) {
            if (exposureIndex < AppPrefs.EXPOSURE_OPTIONS_MS.length - 1) {
                newExposure = AppPrefs.EXPOSURE_OPTIONS_MS[exposureIndex + 1];
                message = String.format(Locale.getDefault(),
                        "Adaptare: %.0f%% în ultimele %d → expunere %d ms.",
                        average * 100f, WINDOW_SIZE, newExposure);
                return new Decision(true, newExposure, newChunk, average, message);
            }

            if (chunkCanAdapt && currentChunkWords < 7) {
                newChunk = currentChunkWords + 1;
                message = String.format(Locale.getDefault(),
                        "Adaptare: %.0f%% la viteza minimă → %d cuvinte/bloc.",
                        average * 100f, newChunk);
                return new Decision(true, newExposure, newChunk, average, message);
            }

            message = String.format(Locale.getDefault(),
                    "Nivel stabil: %.0f%% în ultimele %d.", average * 100f, WINDOW_SIZE);
            return new Decision(false, newExposure, newChunk, average, message);
        }

        if (average < EASE_THRESHOLD) {
            if (exposureIndex > 0) {
                newExposure = AppPrefs.EXPOSURE_OPTIONS_MS[exposureIndex - 1];
                message = String.format(Locale.getDefault(),
                        "Adaptare: %.0f%% în ultimele %d → expunere %d ms.",
                        average * 100f, WINDOW_SIZE, newExposure);
                return new Decision(true, newExposure, newChunk, average, message);
            }

            if (chunkCanAdapt && currentChunkWords > 1) {
                newChunk = currentChunkWords - 1;
                message = String.format(Locale.getDefault(),
                        "Adaptare: %.0f%% → %d cuvinte/bloc.", average * 100f, newChunk);
                return new Decision(true, newExposure, newChunk, average, message);
            }
        }

        message = String.format(Locale.getDefault(),
                "Nivel păstrat: %.0f%% în ultimele %d.", average * 100f, WINDOW_SIZE);
        return new Decision(false, newExposure, newChunk, average, message);
    }

    private float average(List<Float> values) {
        if (values.isEmpty()) return 0f;
        float sum = 0f;
        for (float value : values) sum += value;
        return sum / values.size();
    }
}
