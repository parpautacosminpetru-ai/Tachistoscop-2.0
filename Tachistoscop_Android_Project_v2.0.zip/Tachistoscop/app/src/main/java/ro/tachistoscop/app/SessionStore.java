package ro.tachistoscop.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class SessionStore {
    private static final String PREFS = "tachistoscop_history";
    private static final String KEY_HISTORY = "sessions_json";
    private static final int MAX_SESSIONS = 60;

    public static final class SessionRecord {
        public long timestamp;
        public int trials;
        public int exactCorrect;
        public float averageAccuracy;
        public long averageResponseMs;
        public int startExposureMs;
        public int endExposureMs;
        public int startChunkWords;
        public int endChunkWords;
        public int trainingMode;
        public boolean adaptive;
        public float refreshRateHz;

        JSONObject toJson() throws JSONException {
            JSONObject object = new JSONObject();
            object.put("timestamp", timestamp);
            object.put("trials", trials);
            object.put("exactCorrect", exactCorrect);
            object.put("averageAccuracy", averageAccuracy);
            object.put("averageResponseMs", averageResponseMs);
            object.put("startExposureMs", startExposureMs);
            object.put("endExposureMs", endExposureMs);
            object.put("startChunkWords", startChunkWords);
            object.put("endChunkWords", endChunkWords);
            object.put("trainingMode", trainingMode);
            object.put("adaptive", adaptive);
            object.put("refreshRateHz", refreshRateHz);
            return object;
        }

        static SessionRecord fromJson(JSONObject object) {
            SessionRecord record = new SessionRecord();
            record.timestamp = object.optLong("timestamp", 0L);
            record.trials = object.optInt("trials", 0);
            record.exactCorrect = object.optInt("exactCorrect", 0);
            record.averageAccuracy = (float) object.optDouble("averageAccuracy", 0d);
            record.averageResponseMs = object.optLong("averageResponseMs", 0L);
            record.startExposureMs = object.optInt("startExposureMs", 100);
            record.endExposureMs = object.optInt("endExposureMs", record.startExposureMs);
            record.startChunkWords = object.optInt("startChunkWords", 1);
            record.endChunkWords = object.optInt("endChunkWords", record.startChunkWords);
            record.trainingMode = object.optInt("trainingMode", AppPrefs.TRAINING_PRO);
            record.adaptive = object.optBoolean("adaptive", false);
            record.refreshRateHz = (float) object.optDouble("refreshRateHz", 0d);
            return record;
        }
    }

    private SessionStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void add(Context context, SessionRecord record) {
        List<SessionRecord> records = load(context);
        records.add(0, record);
        if (records.size() > MAX_SESSIONS) {
            records = new ArrayList<>(records.subList(0, MAX_SESSIONS));
        }
        save(context, records);
    }

    public static List<SessionRecord> load(Context context) {
        String raw = prefs(context).getString(KEY_HISTORY, "[]");
        List<SessionRecord> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.optJSONObject(i);
                if (object != null) result.add(SessionRecord.fromJson(object));
            }
        } catch (JSONException ignored) {
            return new ArrayList<>();
        }
        return result;
    }

    public static void clear(Context context) {
        prefs(context).edit().putString(KEY_HISTORY, "[]").apply();
    }

    private static void save(Context context, List<SessionRecord> records) {
        JSONArray array = new JSONArray();
        for (SessionRecord record : records) {
            try {
                array.put(record.toJson());
            } catch (JSONException ignored) { }
        }
        prefs(context).edit().putString(KEY_HISTORY, array.toString()).apply();
    }
}
