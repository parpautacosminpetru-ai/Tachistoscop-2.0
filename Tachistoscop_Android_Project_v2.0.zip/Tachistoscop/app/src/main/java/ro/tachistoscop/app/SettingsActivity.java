package ro.tachistoscop.app;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private EditText contentInput;
    private Spinner trainingModeSpinner;
    private Spinner sessionLengthSpinner;
    private Spinner contentModeSpinner;
    private Spinner exposureSpinner;
    private Spinner fixationSpinner;
    private Spinner fontSpinner;
    private SeekBar chunkSeek;
    private TextView chunkLabel;
    private LinearLayout chunkSection;
    private SeekBar fontSizeSeek;
    private TextView fontSizeLabel;
    private TextView preview;
    private CheckBox adaptiveCheck;
    private CheckBox shuffleCheck;
    private CheckBox keepScreenOnCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(45, 31, 24));
        getWindow().setNavigationBarColor(Color.rgb(31, 24, 20));
        buildUi();
        loadValues();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(240, 230, 210));
        SystemBarInsets.apply(scroll);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("TACHISTOSCOP PRO 2.0 • SETĂRI");
        title.setTextColor(Color.rgb(56, 39, 29));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 23);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        addSectionLabel(root, "Protocol de antrenament");
        trainingModeSpinner = new Spinner(this);
        trainingModeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{
                        "PRO — răspuns tastat + scor automat",
                        "CLASSIC — autoevaluare InfoSpeed"
                }));
        root.addView(trainingModeSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        addHelp(root,
                "PRO măsoară acuratețea pe cuvinte și timpul de răspuns. CLASSIC păstrează fluxul simplu AM VĂZUT / NU AM VĂZUT.");

        addSectionLabel(root, "Lungime sesiune");
        sessionLengthSpinner = new Spinner(this);
        String[] sessionLabels = new String[AppPrefs.SESSION_LENGTH_OPTIONS.length];
        for (int i = 0; i < sessionLabels.length; i++) {
            sessionLabels[i] = AppPrefs.SESSION_LENGTH_OPTIONS[i] + " expuneri";
        }
        sessionLengthSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sessionLabels));
        root.addView(sessionLengthSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        adaptiveCheck = makeCheckBox("Adaptare automată a dificultății");
        root.addView(adaptiveCheck);
        addHelp(root,
                "La fiecare 5 răspunsuri, aplicația schimbă o singură variabilă: întâi timpul de expunere; la limita de viteză poate schimba numărul de cuvinte/bloc.");

        shuffleCheck = makeCheckBox("Amestecă stimulii în fiecare rundă");
        root.addView(shuffleCheck);

        keepScreenOnCheck = makeCheckBox("Ține ecranul aprins în timpul utilizării");
        root.addView(keepScreenOnCheck);

        addSectionLabel(root, "Fixație înainte de expunere");
        fixationSpinner = new Spinner(this);
        String[] fixationLabels = new String[AppPrefs.FIXATION_OPTIONS_MS.length];
        for (int i = 0; i < fixationLabels.length; i++) {
            int value = AppPrefs.FIXATION_OPTIONS_MS[i];
            fixationLabels[i] = value == 0 ? "Fără întârziere" : value + " ms";
        }
        fixationSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, fixationLabels));
        root.addView(fixationSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        addHelp(root, "În intervalul de fixație este afișat doar punctul central, apoi începe expunerea sincronizată pe cadre.");

        addSectionLabel(root, "Conținut");
        addHelp(root,
                "Listă: un stimul pe linie. Text: aplicația îl împarte automat în blocuri de 1–7 cuvinte.");

        contentInput = new EditText(this);
        contentInput.setGravity(Gravity.TOP | Gravity.START);
        contentInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        contentInput.setTextColor(Color.rgb(35, 31, 27));
        contentInput.setHint("Exemplu:\ncitirea rapidă cere precizie\ncâmpul vizual se antrenează\nmemorie vizuală");
        contentInput.setHintTextColor(Color.rgb(130, 115, 95));
        contentInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        contentInput.setMinLines(8);
        contentInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        contentInput.setBackgroundColor(Color.rgb(251, 247, 238));
        root.addView(contentInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)));

        addSectionLabel(root, "Mod conținut");
        contentModeSpinner = new Spinner(this);
        contentModeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Un stimul pe linie", "Împarte textul în blocuri"}));
        root.addView(contentModeSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        chunkSection = new LinearLayout(this);
        chunkSection.setOrientation(LinearLayout.VERTICAL);
        chunkSection.setPadding(0, dp(6), 0, dp(4));
        chunkLabel = addHelp(chunkSection, "Cuvinte pe bloc: 3");
        chunkSeek = new SeekBar(this);
        chunkSeek.setMax(6);
        chunkSection.addView(chunkSeek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(chunkSection);

        addSectionLabel(root, "Expunere inițială");
        exposureSpinner = new Spinner(this);
        String[] exposureLabels = new String[AppPrefs.EXPOSURE_OPTIONS_MS.length];
        for (int i = 0; i < exposureLabels.length; i++) {
            exposureLabels[i] = AppPrefs.EXPOSURE_OPTIONS_MS[i] + " ms";
        }
        exposureSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, exposureLabels));
        root.addView(exposureSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        addHelp(root,
                "Durata cerută este convertită în număr de cadre pentru refresh-rate-ul curent al ecranului; aplicația raportează separat valoarea măsurată la fiecare flash.");

        addSectionLabel(root, "Font și lizibilitate");
        fontSpinner = new Spinner(this);
        fontSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Serif — stil de carte", "Sans — simplu", "Monospace — cifre/cod", "Serif cursiv"}));
        root.addView(fontSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        fontSizeLabel = addHelp(root, "Mărime font: 42 sp");
        fontSizeSeek = new SeekBar(this);
        fontSizeSeek.setMax(50);
        root.addView(fontSizeSeek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addSectionLabel(root, "Previzualizare");
        preview = new TextView(this);
        preview.setText("CITIRE RAPIDĂ");
        preview.setTextColor(Color.rgb(31, 27, 23));
        preview.setGravity(Gravity.CENTER);
        preview.setBackgroundColor(Color.rgb(250, 246, 235));
        preview.setPadding(dp(10), dp(18), dp(10), dp(18));
        root.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(116)));

        TextView note = addHelp(root,
                "Motor 2.0: mânerul și butonul EXPUNE sunt doar declanșatoare. Durata flash-ului nu depinde de gest. Istoricul rămâne local pe telefon.");
        note.setPadding(0, dp(12), 0, dp(12));

        Button save = new Button(this);
        save.setText("SALVEAZĂ ȘI REVINO");
        save.setTextColor(Color.WHITE);
        save.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        save.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(91, 57, 36)));
        save.setOnClickListener(v -> saveAndFinish());
        root.addView(save, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        Button cancel = new Button(this);
        cancel.setText("ÎNAPOI FĂRĂ SALVARE");
        cancel.setTextColor(Color.rgb(72, 47, 31));
        cancel.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(224, 210, 183)));
        cancel.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        cancelLp.topMargin = dp(8);
        root.addView(cancel, cancelLp);

        contentModeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position ->
                chunkSection.setVisibility(position == AppPrefs.CONTENT_CHUNKS ? View.VISIBLE : View.GONE)));

        chunkSeek.setOnSeekBarChangeListener(new SimpleSeekBarListener(progress ->
                chunkLabel.setText("Cuvinte pe bloc: " + (progress + 1))));

        fontSizeSeek.setOnSeekBarChangeListener(new SimpleSeekBarListener(progress -> {
            fontSizeLabel.setText("Mărime font: " + (progress + 22) + " sp");
            updatePreview();
        }));
        fontSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> updatePreview()));

        setContentView(scroll);
    }

    private void loadValues() {
        contentInput.setText(AppPrefs.getRawText(this));
        trainingModeSpinner.setSelection(AppPrefs.getTrainingMode(this));
        sessionLengthSpinner.setSelection(AppPrefs.getSessionLengthOptionIndex(this));
        adaptiveCheck.setChecked(AppPrefs.isAdaptive(this));
        shuffleCheck.setChecked(AppPrefs.isShuffleEnabled(this));
        keepScreenOnCheck.setChecked(AppPrefs.isKeepScreenOn(this));
        fixationSpinner.setSelection(AppPrefs.getFixationOptionIndex(this));
        contentModeSpinner.setSelection(AppPrefs.getMode(this));
        chunkSeek.setProgress(AppPrefs.getChunkWords(this) - 1);
        chunkLabel.setText("Cuvinte pe bloc: " + AppPrefs.getChunkWords(this));
        chunkSection.setVisibility(AppPrefs.getMode(this) == AppPrefs.CONTENT_CHUNKS ? View.VISIBLE : View.GONE);
        exposureSpinner.setSelection(AppPrefs.getExposureOptionIndex(this));
        fontSpinner.setSelection(AppPrefs.getFontIndex(this));
        int size = Math.round(AppPrefs.getFontSizeSp(this));
        fontSizeSeek.setProgress(Math.max(0, Math.min(50, size - 22)));
        fontSizeLabel.setText("Mărime font: " + size + " sp");
        updatePreview();
    }

    private void updatePreview() {
        if (preview == null || fontSpinner == null || fontSizeSeek == null) return;
        Typeface typeface;
        switch (fontSpinner.getSelectedItemPosition()) {
            case 1:
                typeface = Typeface.SANS_SERIF;
                break;
            case 2:
                typeface = Typeface.MONOSPACE;
                break;
            case 3:
                typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC);
                break;
            default:
                typeface = Typeface.SERIF;
                break;
        }
        preview.setTypeface(typeface);
        preview.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSeek.getProgress() + 22);
    }

    private void saveAndFinish() {
        AppPrefs.setRawText(this, contentInput.getText().toString());
        AppPrefs.setTrainingMode(this, trainingModeSpinner.getSelectedItemPosition());
        AppPrefs.setSessionLength(this,
                AppPrefs.SESSION_LENGTH_OPTIONS[Math.max(0, sessionLengthSpinner.getSelectedItemPosition())]);
        AppPrefs.setAdaptive(this, adaptiveCheck.isChecked());
        AppPrefs.setShuffleEnabled(this, shuffleCheck.isChecked());
        AppPrefs.setKeepScreenOn(this, keepScreenOnCheck.isChecked());
        AppPrefs.setFixationMs(this,
                AppPrefs.FIXATION_OPTIONS_MS[Math.max(0, fixationSpinner.getSelectedItemPosition())]);
        AppPrefs.setMode(this, contentModeSpinner.getSelectedItemPosition());
        AppPrefs.setChunkWords(this, chunkSeek.getProgress() + 1);
        AppPrefs.setExposureMs(this,
                AppPrefs.EXPOSURE_OPTIONS_MS[Math.max(0, exposureSpinner.getSelectedItemPosition())]);
        AppPrefs.setFontIndex(this, fontSpinner.getSelectedItemPosition());
        AppPrefs.setFontSizeSp(this, fontSizeSeek.getProgress() + 22);
        AppPrefs.setCurrentIndex(this, 0);
        Toast.makeText(this, "Setări 2.0 salvate", Toast.LENGTH_SHORT).show();
        finish();
    }

    private CheckBox makeCheckBox(String text) {
        CheckBox checkBox = new CheckBox(this);
        checkBox.setText(text);
        checkBox.setTextColor(Color.rgb(65, 49, 37));
        checkBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        checkBox.setPadding(0, dp(5), 0, dp(2));
        return checkBox;
    }

    private void addSectionLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.rgb(72, 47, 31));
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setPadding(0, dp(16), 0, dp(6));
        root.addView(label);
    }

    private TextView addHelp(LinearLayout root, String text) {
        TextView help = new TextView(this);
        help.setText(text);
        help.setTextColor(Color.rgb(96, 80, 64));
        help.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        help.setLineSpacing(0f, 1.14f);
        root.addView(help);
        return help;
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    private interface PositionCallback {
        void onPosition(int position);
    }

    private static class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        private final PositionCallback callback;

        SimpleItemSelectedListener(PositionCallback callback) {
            this.callback = callback;
        }

        @Override
        public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            callback.onPosition(position);
        }

        @Override
        public void onNothingSelected(android.widget.AdapterView<?> parent) { }
    }

    private interface ProgressCallback {
        void onProgress(int progress);
    }

    private static class SimpleSeekBarListener implements SeekBar.OnSeekBarChangeListener {
        private final ProgressCallback callback;

        SimpleSeekBarListener(ProgressCallback callback) {
            this.callback = callback;
        }

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            callback.onProgress(progress);
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) { }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) { }
    }
}
