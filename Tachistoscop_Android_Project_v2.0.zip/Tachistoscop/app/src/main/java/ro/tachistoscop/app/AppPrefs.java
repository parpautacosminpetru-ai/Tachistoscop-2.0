package ro.tachistoscop.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;

public final class AppPrefs {
    public static final int CONTENT_LINES = 0;
    public static final int CONTENT_CHUNKS = 1;

    public static final int TRAINING_PRO = 0;
    public static final int TRAINING_CLASSIC = 1;

    private static final String PREFS = "tachistoscop_prefs";
    private static final String KEY_TEXT = "content_text";
    private static final String KEY_MODE = "content_mode";
    private static final String KEY_CHUNK = "chunk_words";
    private static final String KEY_FONT = "font_family";
    private static final String KEY_FONT_SIZE = "font_size_sp";
    private static final String KEY_INDEX = "current_index";
    private static final String KEY_EXPOSURE_MS = "exposure_ms";
    private static final String KEY_TRAINING_MODE = "training_mode";
    private static final String KEY_SESSION_LENGTH = "session_length";
    private static final String KEY_ADAPTIVE = "adaptive_training";
    private static final String KEY_SHUFFLE = "shuffle_stimuli";
    private static final String KEY_FIXATION_MS = "fixation_ms";
    private static final String KEY_KEEP_SCREEN_ON = "keep_screen_on";

    public static final int[] EXPOSURE_OPTIONS_MS = {
            500, 400, 300, 250, 200, 150, 120, 100, 80, 60, 50
    };

    public static final int[] SESSION_LENGTH_OPTIONS = {10, 20, 50, 100};
    public static final int[] FIXATION_OPTIONS_MS = {0, 250, 350, 500, 750, 1000};

    private static final String DEFAULT_TEXT =
            "TACHISTOSCOP\n" +
            "LECTURĂ RAPIDĂ\n" +
            "MEMORIE VIZUALĂ\n" +
            "CÂMP VIZUAL\n" +
            "VITEZĂ ȘI PRECIZIE\n" +
            "ANTRENAMENT CONCENTRAT\n" +
            "PERCEPȚIE RAPIDĂ";

    private AppPrefs() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String getRawText(Context context) {
        return prefs(context).getString(KEY_TEXT, DEFAULT_TEXT);
    }

    public static void setRawText(Context context, String value) {
        prefs(context).edit().putString(KEY_TEXT, value == null ? "" : value).apply();
    }

    public static int getMode(Context context) {
        return clampInt(prefs(context).getInt(KEY_MODE, CONTENT_CHUNKS), CONTENT_LINES, CONTENT_CHUNKS);
    }

    public static void setMode(Context context, int mode) {
        prefs(context).edit().putInt(KEY_MODE, clampInt(mode, CONTENT_LINES, CONTENT_CHUNKS)).apply();
    }

    public static int getChunkWords(Context context) {
        return clampInt(prefs(context).getInt(KEY_CHUNK, 3), 1, 7);
    }

    public static void setChunkWords(Context context, int words) {
        prefs(context).edit().putInt(KEY_CHUNK, clampInt(words, 1, 7)).apply();
    }

    public static int getTrainingMode(Context context) {
        return clampInt(prefs(context).getInt(KEY_TRAINING_MODE, TRAINING_PRO), TRAINING_PRO, TRAINING_CLASSIC);
    }

    public static void setTrainingMode(Context context, int mode) {
        prefs(context).edit().putInt(KEY_TRAINING_MODE, clampInt(mode, TRAINING_PRO, TRAINING_CLASSIC)).apply();
    }

    public static int getSessionLength(Context context) {
        int saved = prefs(context).getInt(KEY_SESSION_LENGTH, 20);
        return closestOption(saved, SESSION_LENGTH_OPTIONS);
    }

    public static void setSessionLength(Context context, int length) {
        prefs(context).edit().putInt(KEY_SESSION_LENGTH, closestOption(length, SESSION_LENGTH_OPTIONS)).apply();
    }

    public static int getSessionLengthOptionIndex(Context context) {
        return indexOf(getSessionLength(context), SESSION_LENGTH_OPTIONS, 1);
    }

    public static boolean isAdaptive(Context context) {
        return prefs(context).getBoolean(KEY_ADAPTIVE, true);
    }

    public static void setAdaptive(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ADAPTIVE, enabled).apply();
    }

    public static boolean isShuffleEnabled(Context context) {
        return prefs(context).getBoolean(KEY_SHUFFLE, true);
    }

    public static void setShuffleEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_SHUFFLE, enabled).apply();
    }

    public static int getFixationMs(Context context) {
        int saved = prefs(context).getInt(KEY_FIXATION_MS, 350);
        return closestOption(saved, FIXATION_OPTIONS_MS);
    }

    public static void setFixationMs(Context context, int milliseconds) {
        prefs(context).edit().putInt(KEY_FIXATION_MS, closestOption(milliseconds, FIXATION_OPTIONS_MS)).apply();
    }

    public static int getFixationOptionIndex(Context context) {
        return indexOf(getFixationMs(context), FIXATION_OPTIONS_MS, 2);
    }

    public static boolean isKeepScreenOn(Context context) {
        return prefs(context).getBoolean(KEY_KEEP_SCREEN_ON, true);
    }

    public static void setKeepScreenOn(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_KEEP_SCREEN_ON, enabled).apply();
    }

    public static int getExposureMs(Context context) {
        int saved = prefs(context).getInt(KEY_EXPOSURE_MS, 100);
        return closestOption(saved, EXPOSURE_OPTIONS_MS);
    }

    public static void setExposureMs(Context context, int exposureMs) {
        prefs(context).edit().putInt(KEY_EXPOSURE_MS, closestOption(exposureMs, EXPOSURE_OPTIONS_MS)).apply();
    }

    public static int getExposureOptionIndex(Context context) {
        return indexOf(getExposureMs(context), EXPOSURE_OPTIONS_MS, 7);
    }

    public static int getFontIndex(Context context) {
        return clampInt(prefs(context).getInt(KEY_FONT, 0), 0, 3);
    }

    public static void setFontIndex(Context context, int index) {
        prefs(context).edit().putInt(KEY_FONT, clampInt(index, 0, 3)).apply();
    }

    public static float getFontSizeSp(Context context) {
        return Math.max(22f, Math.min(72f, prefs(context).getFloat(KEY_FONT_SIZE, 42f)));
    }

    public static void setFontSizeSp(Context context, float size) {
        prefs(context).edit().putFloat(KEY_FONT_SIZE, Math.max(22f, Math.min(72f, size))).apply();
    }

    public static int getCurrentIndex(Context context) {
        return Math.max(0, prefs(context).getInt(KEY_INDEX, 0));
    }

    public static void setCurrentIndex(Context context, int index) {
        prefs(context).edit().putInt(KEY_INDEX, Math.max(0, index)).apply();
    }

    public static Typeface getTypeface(Context context) {
        switch (getFontIndex(context)) {
            case 1:
                return Typeface.SANS_SERIF;
            case 2:
                return Typeface.MONOSPACE;
            case 3:
                return Typeface.create(Typeface.SERIF, Typeface.ITALIC);
            case 0:
            default:
                return Typeface.SERIF;
        }
    }

    public static List<String> getStimuli(Context context) {
        return getStimuli(context, getChunkWords(context));
    }

    public static List<String> getStimuli(Context context, int chunkWords) {
        String raw = getRawText(context).trim();
        List<String> result = new ArrayList<>();
        if (raw.isEmpty()) return result;

        if (getMode(context) == CONTENT_LINES) {
            String[] lines = raw.split("\\r?\\n");
            for (String line : lines) {
                String clean = line.trim().replaceAll("\\s+", " ");
                if (!clean.isEmpty()) result.add(clean);
            }
            return result;
        }

        String compact = raw.replaceAll("\\s+", " ").trim();
        if (compact.isEmpty()) return result;

        String[] words = compact.split(" ");
        int chunk = clampInt(chunkWords, 1, 7);
        for (int i = 0; i < words.length; i += chunk) {
            StringBuilder builder = new StringBuilder();
            for (int j = i; j < Math.min(words.length, i + chunk); j++) {
                if (builder.length() > 0) builder.append(' ');
                builder.append(words[j]);
            }
            if (builder.length() > 0) result.add(builder.toString());
        }
        return result;
    }

    public static int exposureIndexFor(int exposureMs) {
        return indexOf(closestOption(exposureMs, EXPOSURE_OPTIONS_MS), EXPOSURE_OPTIONS_MS, 7);
    }

    private static int indexOf(int value, int[] options, int fallback) {
        for (int i = 0; i < options.length; i++) {
            if (options[i] == value) return i;
        }
        return Math.max(0, Math.min(options.length - 1, fallback));
    }

    private static int closestOption(int requested, int[] options) {
        int closest = options[0];
        int smallestDistance = Math.abs(requested - closest);
        for (int value : options) {
            int distance = Math.abs(requested - value);
            if (distance < smallestDistance) {
                closest = value;
                smallestDistance = distance;
            }
        }
        return closest;
    }

    private static int clampInt(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
