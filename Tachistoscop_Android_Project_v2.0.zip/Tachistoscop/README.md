# Tachistoscop Pro 2.0 — InfoSpeed Training Engine

Aplicație Android offline pentru antrenament tachistoscopic și citire rapidă, inspirată de interacțiunea mecanică InfoSpeed, dar cu motor digital măsurabil.

## Ce aduce versiunea 2.0

### Motor de expunere
- expuneri selectabile: 500, 400, 300, 250, 200, 150, 120, 100, 80, 60 și 50 ms;
- durata este convertită în număr de cadre în funcție de refresh-rate-ul curent;
- expunerea este declanșată prin `Choreographer`;
- aplicația raportează separat durata cerută, durata nominală pe cadre și durata măsurată între callback-urile de frame;
- fixație configurabilă înainte de flash: 0–1000 ms;
- mânerul și butonul EXPUNE sunt doar declanșatoare, nu controlează durata;
- punct central de fixație și fantă vizuală dedicată.

### Mod PRO
- utilizatorul tastează ceea ce a perceput;
- răspunsul este normalizat pentru majuscule/minuscule, diacritice și punctuație;
- scorul este calculat la nivel de cuvinte, păstrând ordinea;
- sunt măsurate acuratețea, răspunsurile exacte și timpul de răspuns;
- există buton separat „NU AM PERCEPUT”.

### Mod CLASSIC
- păstrează fluxul rapid „AM VĂZUT / NU AM VĂZUT”;
- util pentru exerciții de percepție fără tastare;
- rezultatul este marcat explicit ca autoevaluare/percepție, nu ca verificare automată.

### Sesiuni
- 10 / 20 / 50 / 100 expuneri;
- ordine secvențială sau amestecată;
- progresul sesiunii este afișat permanent;
- o sesiune poate fi oprită și salvată parțial;
- ecranul poate fi menținut aprins pe durata utilizării.

### Adaptare automată
- evaluare în ferestre de 5 răspunsuri;
- la >= 90%: scade timpul cu un singur nivel;
- la < 65%: crește timpul cu un singur nivel;
- când este atinsă limita de viteză și conținutul este în modul text, poate crește numărul de cuvinte/bloc;
- la fiecare decizie se modifică o singură variabilă;
- noul nivel este memorat pentru sesiunea următoare.

### Progres local
- ultimele 60 de sesiuni sunt păstrate local în `SharedPreferences` ca JSON;
- sunt salvate: dată, număr de probe, acuratețe, răspunsuri exacte/percepute, timp mediu de răspuns, nivel inițial/final, bloc inițial/final, modul adaptiv și refresh-rate;
- ecranul PROGRES afișează sumar global și sesiunile recente;
- istoricul poate fi exportat în CSV prin selectorul standard Android;
- istoricul poate fi șters din aplicație.

## Arhitectură

- `TachistoscopeView.java` — randare, mâner, fixație și motorul de timing pe frame-uri.
- `MainActivity.java` — protocolul sesiunii și fluxul utilizatorului.
- `SettingsActivity.java` — configurarea protocolului.
- `HistoryActivity.java` — progres și istoric.
- `ResponseScorer.java` — normalizare și scor word-level.
- `AdaptiveController.java` — logică adaptivă independentă de UI.
- `SessionStore.java` — persistența sesiunilor.
- `SystemBarInsets.java` — protecție UI pentru zonele sistemului pe Android modern.
- `AppPrefs.java` — preferințe și generarea stimulilor.

## Cerințe Android

- minSdk 23
- targetSdk 36
- compileSdk 36
- Java 17
- Android Gradle Plugin 8.13.2
- fără AndroidX și fără biblioteci externe runtime

## Limitare importantă

Un telefon nu este un instrument de laborator certificat. Durata vizuală reală este limitată de refresh-rate, pipeline-ul de randare și comportamentul panoului. Aplicația raportează timing-ul pe cadre și variațiile observate pentru transparență, dar nu trebuie prezentată ca echipament medical sau metrologic certificat.
