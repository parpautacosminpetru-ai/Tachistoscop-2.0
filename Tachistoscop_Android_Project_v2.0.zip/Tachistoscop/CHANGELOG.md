# Changelog

## 2.0.0

- Mod PRO cu răspuns tastat și verificare automată.
- Normalizare răspuns: case-insensitive, fără penalizare pentru diacritice/punctuație.
- Scor de acuratețe word-level și răspuns exact.
- Măsurare timp de răspuns.
- Sesiuni de 10 / 20 / 50 / 100 expuneri.
- Adaptare automată în ferestre de 5 probe.
- Ordine aleatorie opțională.
- Fixație configurabilă 0–1000 ms.
- Timing cu Choreographer și raportare cerut / nominal / măsurat.
- Mod Classic păstrat separat.
- Ecran Progres cu istoric local pentru până la 60 de sesiuni.
- Export CSV al istoricului prin Storage Access Framework.
- Persistență nivel adaptiv între sesiuni.
- Opțiune keep-screen-on.
- Protecție pentru system-bar insets pe Android modern.
- versionCode 20 / versionName 2.0.0.

## 0.2.0

- Nucleu InfoSpeed: expunere fixă pe cadre, 1–7 cuvinte, fantă centrală și autoevaluare.
