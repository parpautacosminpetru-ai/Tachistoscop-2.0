# Changelog

## 2.0.1 — Professional Intensive

- Program intensiv cu 30 de niveluri recomandate.
- Bibliotecă offline: silabe, cuvinte, grupuri 2–7, cifre și câmp vizual.
- Evaluări programate în zilele 1, 7, 14, 21 și 30.
- Ecran PLAN cu dată de start, 5–60 minute/zi și selectarea zilelor săptămânii.
- Calcul automat al expunerilor, volumului total, următoarei sesiuni și datei finale proiectate.
- Replanificare automată când o zi este ratată.
- Mastery Gate: nivelul următor rămâne blocat până la îndeplinirea criteriilor de precizie și stabilitate.
- Mastery Gate verifică sesiunea integrală, performanța globală și ultimele două ferestre de 10 probe.
- Programul intensiv folosește modul PRO și nu permite adaptarea automată spre un nivel mai greu înainte de promovare.
- Font adaptabil activ implicit.
- Casetă de text adaptabilă la lungimea stimulului.
- Casetă neutră înainte de flash pentru a nu oferi indicii despre lungimea textului.
- Randare laterală pentru exerciții de câmp vizual.
- Progres 30 zile cu baseline, nivel curent și indice intern comparativ.
- Istoric extins cu zi de program, exercițiu, rezultat Mastery Gate și volum planificat.
- Export CSV extins.
- `versionCode 21` / `versionName 2.0.1`.

## 2.0.0

- Mod PRO cu răspuns tastat și verificare automată.
- Scor word-level și timp de răspuns.
- Sesiuni 10 / 20 / 50 / 100.
- Adaptare automată pentru modul manual.
- Timing cu Choreographer.
- Mod Classic.
- Istoric local și export CSV.
