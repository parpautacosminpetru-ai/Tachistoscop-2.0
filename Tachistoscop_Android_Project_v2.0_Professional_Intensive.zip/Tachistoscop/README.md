# Tachistoscop Pro 2.0 Professional Intensive

Aplicație Android offline pentru antrenament tachistoscopic și citire rapidă, cu motor de timing pe cadre, răspuns verificat automat și program intensiv progresiv.

Versiune internă: **2.0.1** (`versionCode 21`). Este o revizie profesională a liniei 2.0.

## Program intensiv de 30 zile

- bibliotecă offline cu 30 de niveluri recomandate;
- progresie: baseline → silabe → cuvinte → 2–7 cuvinte → exerciții de câmp vizual → cifre → evaluări;
- evaluări în zilele 1, 7, 14, 21 și 30;
- fiecare zi are timp de expunere, fixație, număr de cuvinte și stimuli proprii;
- programul folosește obligatoriu modul PRO cu răspuns verificat;
- nivelurile viitoare sunt afișate ca BLOCATE.

## Mastery Gate — nu avansează dacă percepția nu este stabilă

Promovarea unei zile cere simultan:

- sesiune terminată integral;
- acuratețe globală ≥ 90%;
- răspunsuri exacte global ≥ 75%;
- ultimele 2 ferestre consecutive de câte 10 probe cu ≥ 92% acuratețe;
- aceleași ferestre cu ≥ 80% răspunsuri exacte.

Dacă pragul nu este atins, ziua rămâne activă și trebuie repetată. Programul nu mărește automat dificultatea în interiorul unei zile.

## Calendar și volum automat

În ecranul `PLAN` se pot seta:

- data de start;
- 5–60 minute pe zi, în pași de 5 minute;
- zilele săptămânii în care se face antrenamentul;
- activarea/dezactivarea programului intensiv.

Aplicația calculează:

- numărul recomandat de expuneri pe sesiune (aprox. 3/minut, rotunjit la ferestre de 10);
- volumul total planificat;
- următoarea zi eligibilă;
- data finală proiectată;
- numărul de încercări la nivelul curent.

Dacă o zi este ratată, următoarea sesiune și finalul proiectat sunt mutate automat înainte pe calendar. După promovarea unei zile nu se poate face ziua următoare în aceeași dată dacă planul o programează ulterior.

## Font și casetă adaptabile

- font adaptabil activ implicit;
- casetă de expunere adaptabilă activ implicit;
- caseta se mărește mai întâi în limitele ecranului;
- doar dacă textul nu încape, fontul se reduce gradual;
- dimensiunea stimulului nu este indicată înainte de flash: în starea ascunsă se folosește o casetă neutră;
- stimuli periferici sunt redați stânga/dreapta față de punctul central de fixație.

## Progres într-o lună

Ecranul `PROGRES` afișează:

- zile promovate / 30;
- ziua curentă și exercițiul;
- următoarea dată și finalul proiectat;
- volumul planificat;
- baseline versus cea mai recentă sesiune din program;
- acuratețe, mărimea grupului, timpul de expunere și un indice intern de performanță;
- sesiuni recente cu marcaj `PROMOVAT` / `REPETĂ`;
- export CSV cu câmpurile programului și Mastery Gate.

Indicele intern combină acuratețea, numărul de cuvinte și timpul de expunere. Este doar un indicator comparativ în aplicație; nu este WPM și nu este o măsură clinică.

## Modurile manuale rămân disponibile

### PRO
- răspuns tastat;
- normalizare majuscule/minuscule, diacritice și punctuație;
- scor pe cuvinte;
- timp de răspuns;
- adaptare automată opțională pentru sesiuni manuale.

### CLASSIC
- `AM VĂZUT / NU AM VĂZUT`;
- autoevaluare rapidă de tip InfoSpeed.

Când programul intensiv este activ, setările manuale nu pot ocoli Mastery Gate. Programul folosește propriile valori recomandate.

## Motor de expunere

- 500, 400, 300, 250, 200, 150, 120, 100, 80, 60 și 50 ms în modul manual;
- conversie a duratei cerute în număr de cadre pentru refresh-rate-ul curent;
- sincronizare prin `Choreographer`;
- raportare cerut / nominal / măsurat;
- fixație centrală configurabilă;
- mânerul și butonul EXPUNE sunt doar declanșatoare.

## Arhitectură principală

- `TachistoscopeView.java` — randare, timing, font/casetă adaptive și stimul periferic.
- `MainActivity.java` — protocol sesiune, integrare plan și blocare Mastery Gate.
- `PlannerActivity.java` — calendar, timp/zi, zile ale săptămânii și biblioteca de 30 niveluri.
- `ExerciseLibrary.java` — programul și stimulii recomandați.
- `TrainingPlanStore.java` — calendar dinamic și progresul deblocării.
- `MasteryGate.java` — criteriile de promovare.
- `HistoryActivity.java` — progres lunar și export CSV.
- `SessionStore.java` — persistență locală a sesiunilor.
- `ResponseScorer.java` — verificare automată word-level.
- `AdaptiveController.java` — adaptare pentru modul manual.
- `SettingsActivity.java` — setări manuale și afișare adaptivă.

## Cerințe

- minSdk 23
- targetSdk / compileSdk 36
- Java 17
- Android Gradle Plugin 8.13.2
- fără biblioteci runtime externe
- fără permisiune INTERNET

## Limitare

Telefonul nu este un instrument de laborator certificat. Refresh-rate-ul, pipeline-ul de randare și caracteristicile panoului limitează precizia fizică a expunerii. Aplicația raportează timing-ul pe cadre pentru transparență și nu trebuie prezentată ca dispozitiv medical sau metrologic certificat.
