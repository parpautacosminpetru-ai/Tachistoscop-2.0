plugins {
    id("com.android.application")
}

android {
    namespace = "ro.tachistoscop.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "ro.tachistoscop.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 21
        versionName = "2.0.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
