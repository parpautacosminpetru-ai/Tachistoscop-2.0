package ro.tachistoscop.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private TachistoscopeView tachistoscopeView;
    private TextView stateText;
    private TextView timingText;
    private TextView scoreText;
    private TextView feedbackText;
    private Button settingsButton;
    private Button historyButton;
    private Button planButton;
    private Button startStopButton;
    private Button exposeButton;
    private LinearLayout proResponsePanel;
    private LinearLayout classicResponsePanel;
    private EditText answerInput;
    private Button verifyButton;
    private Button dontKnowButton;
    private Button seenButton;
    private Button missedButton;

    private final AdaptiveController adaptiveController = new AdaptiveController();
    private final MasteryGate masteryGate = new MasteryGate();
    private final List<String> deck = new ArrayList<>();

    private boolean sessionActive = false;
    private boolean awaitingResponse = false;
    private int sessionTarget = 20;
    private int sessionTrials = 0;
    private int exactCorrect = 0;
    private float accuracySum = 0f;
    private long responseTimeSumMs = 0L;
    private int responseTimeCount = 0;
    private long responseStartElapsedMs = 0L;
    private long sessionStartTimestamp = 0L;
    private int deckIndex = 0;

    private int trainingMode = AppPrefs.TRAINING_PRO;
    private int currentExposureMs = 100;
    private int currentChunkWords = 3;
    private int startExposureMs = 100;
    private int startChunkWords = 3;
    private boolean adaptiveEnabled = true;
    private boolean shuffleEnabled = true;
    private float lastRefreshRateHz = 60f;
    private float lastMeasuredExposureMs = 0f;
    private String currentStimulus = "";
    private String lastAdaptationMessage = "";
    private boolean intensiveProgramActive = false;
    private int intensiveProgramDay = 0;
    private ExerciseLibrary.DayPlan intensiveDayPlan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(45, 31, 24));
        getWindow().setNavigationBarColor(Color.rgb(31, 24, 20));
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyScreenPolicy();
        if (!sessionActive) reloadIdleConfiguration();
    }

    @Override
    protected void onPause() {
        hideKeyboard();
        super.onPause();
    }

    private void applyScreenPolicy() {
        if (AppPrefs.isKeepScreenOn(this)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(237, 226, 205));
        SystemBarInsets.apply(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(8), dp(8), dp(7));
        header.setBackgroundColor(Color.rgb(45, 31, 24));

        TextView title = new TextView(this);
        title.setText("TACHISTOSCOP PRO 2.0");
        title.setTextColor(Color.rgb(246, 232, 206));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(true);
        title.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1f));

        planButton = makeHeaderButton("PLAN", 60);
        planButton.setOnClickListener(v -> openPlanner());
        header.addView(planButton, new LinearLayout.LayoutParams(dp(60), dp(40)));

        historyButton = makeHeaderButton("PROGRES", 76);
        historyButton.setOnClickListener(v -> openHistory());
        LinearLayout.LayoutParams historyLp = new LinearLayout.LayoutParams(dp(76), dp(40));
        historyLp.leftMargin = dp(4);
        header.addView(historyButton, historyLp);

        settingsButton = makeHeaderButton("SETĂRI", 70);
        settingsButton.setOnClickListener(v -> openSettings());
        LinearLayout.LayoutParams settingsLp = new LinearLayout.LayoutParams(dp(70), dp(40));
        settingsLp.leftMargin = dp(4);
        header.addView(settingsButton, settingsLp);

        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tachistoscopeView = new TachistoscopeView(this);
        tachistoscopeView.setExposureListener(new TachistoscopeView.ExposureListener() {
            @Override
            public void onFixationStarted(int fixationMs) {
                if (!sessionActive) return;
                setExposureEnabled(false);
                setResponseEnabled(false);
                stateText.setText(fixationMs > 0
                        ? "FIXAȚIE • păstrează privirea pe punctul central"
                        : "PREGĂTIRE EXPUNERE");
            }

            @Override
            public void onExposureStarted(int requestedMs, float nominalMs, int frameCount, float refreshRateHz) {
                if (!sessionActive) return;
                awaitingResponse = false;
                lastRefreshRateHz = refreshRateHz;
                tachistoscopeView.setInteractionEnabled(false);
                setExposureEnabled(false);
                setResponseEnabled(false);
                stateText.setText("EXPUNERE");
                timingText.setText(String.format(Locale.getDefault(),
                        "Cerut %d ms • nominal %.1f ms • %.1f Hz • %d cadre",
                        requestedMs, nominalMs, refreshRateHz, frameCount));
            }

            @Override
            public void onExposureFinished(int requestedMs, float measuredMs, int frameCount, float refreshRateHz) {
                if (!sessionActive) return;
                awaitingResponse = true;
                lastRefreshRateHz = refreshRateHz;
                lastMeasuredExposureMs = measuredMs;
                responseStartElapsedMs = SystemClock.elapsedRealtime();
                tachistoscopeView.setInteractionEnabled(false);
                setExposureEnabled(false);
                setResponseEnabled(true);
                stateText.setText(trainingMode == AppPrefs.TRAINING_PRO
                        ? "RĂSPUNS • scrie exact ce ai perceput"
                        : "RĂSPUNS • autoevaluare Classic");
                updateTimingQuality(requestedMs, measuredMs, frameCount, refreshRateHz);
                if (trainingMode == AppPrefs.TRAINING_PRO) {
                    answerInput.setText("");
                    answerInput.requestFocus();
                }
            }
        });
        root.addView(tachistoscopeView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(7), dp(12), dp(10));
        panel.setBackgroundColor(Color.rgb(225, 210, 180));

        stateText = new TextView(this);
        stateText.setTextColor(Color.rgb(62, 44, 32));
        stateText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        stateText.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        stateText.setGravity(Gravity.CENTER);
        panel.addView(stateText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        timingText = new TextView(this);
        timingText.setTextColor(Color.rgb(91, 71, 53));
        timingText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        timingText.setGravity(Gravity.CENTER);
        timingText.setPadding(0, dp(2), 0, dp(3));
        panel.addView(timingText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        scoreText = new TextView(this);
        scoreText.setTextColor(Color.rgb(72, 51, 37));
        scoreText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        scoreText.setGravity(Gravity.CENTER);
        scoreText.setPadding(0, 0, 0, dp(4));
        panel.addView(scoreText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        feedbackText = new TextView(this);
        feedbackText.setTextColor(Color.rgb(80, 59, 43));
        feedbackText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        feedbackText.setGravity(Gravity.CENTER);
        feedbackText.setMinLines(2);
        feedbackText.setPadding(dp(4), 0, dp(4), dp(5));
        panel.addView(feedbackText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        buildProResponsePanel(panel);
        buildClassicResponsePanel(panel);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setGravity(Gravity.CENTER);

        startStopButton = makeActionButton("ÎNCEPE SESIUNEA", Color.rgb(91, 57, 36));
        startStopButton.setOnClickListener(v -> {
            if (sessionActive) finishSession(true);
            else startSession();
        });
        actionRow.addView(startStopButton, new LinearLayout.LayoutParams(0, dp(48), 1f));

        exposeButton = makeActionButton("EXPUNE", Color.rgb(121, 76, 45));
        exposeButton.setOnClickListener(v -> triggerExposureFromButton());
        LinearLayout.LayoutParams exposeLp = new LinearLayout.LayoutParams(0, dp(48), 0.7f);
        exposeLp.leftMargin = dp(8);
        actionRow.addView(exposeButton, exposeLp);

        panel.addView(actionRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(panel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        setResponseEnabled(false);
        setExposureEnabled(false);
    }

    private void buildProResponsePanel(LinearLayout parent) {
        proResponsePanel = new LinearLayout(this);
        proResponsePanel.setOrientation(LinearLayout.VERTICAL);

        answerInput = new EditText(this);
        answerInput.setSingleLine(true);
        answerInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        answerInput.setTextColor(Color.rgb(36, 31, 27));
        answerInput.setHint("Răspunsul tău");
        answerInput.setHintTextColor(Color.rgb(130, 115, 95));
        answerInput.setBackgroundColor(Color.rgb(250, 246, 235));
        answerInput.setPadding(dp(10), 0, dp(10), 0);
        answerInput.setOnEditorActionListener((v, actionId, event) -> {
            if (awaitingResponse && verifyButton.isEnabled()) {
                submitTypedResponse(answerInput.getText().toString());
                return true;
            }
            return false;
        });
        proResponsePanel.addView(answerInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(5), 0, dp(5));

        verifyButton = makeSmallButton("VERIFICĂ");
        verifyButton.setOnClickListener(v -> submitTypedResponse(answerInput.getText().toString()));
        row.addView(verifyButton, new LinearLayout.LayoutParams(0, dp(42), 1f));

        dontKnowButton = makeSmallButton("NU AM PERCEPUT");
        dontKnowButton.setOnClickListener(v -> submitTypedResponse(""));
        LinearLayout.LayoutParams dontLp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        dontLp.leftMargin = dp(7);
        row.addView(dontKnowButton, dontLp);
        proResponsePanel.addView(row);

        parent.addView(proResponsePanel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void buildClassicResponsePanel(LinearLayout parent) {
        classicResponsePanel = new LinearLayout(this);
        classicResponsePanel.setOrientation(LinearLayout.HORIZONTAL);
        classicResponsePanel.setGravity(Gravity.CENTER);
        classicResponsePanel.setPadding(0, 0, 0, dp(5));

        seenButton = makeSmallButton("AM VĂZUT");
        seenButton.setOnClickListener(v -> submitClassicResponse(true));
        classicResponsePanel.addView(seenButton, new LinearLayout.LayoutParams(0, dp(44), 1f));

        missedButton = makeSmallButton("NU AM VĂZUT");
        missedButton.setOnClickListener(v -> submitClassicResponse(false));
        LinearLayout.LayoutParams missedLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        missedLp.leftMargin = dp(7);
        classicResponsePanel.addView(missedButton, missedLp);

        parent.addView(classicResponsePanel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private Button makeHeaderButton(String text, int widthDp) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        button.setTextColor(Color.WHITE);
        button.setPadding(0, 0, 0, 0);
        button.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(105, 70, 49)));
        button.setMinWidth(dp(widthDp));
        return button;
    }

    private Button makeActionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        button.setBackgroundTintList(ColorStateList.valueOf(color));
        return button;
    }

    private Button makeSmallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        button.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(116, 76, 48)));
        return button;
    }

    private void reloadIdleConfiguration() {
        intensiveProgramActive = TrainingPlanStore.isEnabled(this);
        intensiveProgramDay = intensiveProgramActive ? TrainingPlanStore.getCurrentDay(this) : 0;
        intensiveDayPlan = intensiveProgramActive ? ExerciseLibrary.getDayPlan(intensiveProgramDay) : null;

        if (intensiveProgramActive && !TrainingPlanStore.isFinished(this)) {
            trainingMode = AppPrefs.TRAINING_PRO;
            sessionTarget = TrainingPlanStore.getRecommendedTrials(this, intensiveProgramDay);
            currentExposureMs = intensiveDayPlan.exposureMs;
            currentChunkWords = intensiveDayPlan.chunkWords;
            adaptiveEnabled = false; // programul avansează numai prin Mastery Gate
            shuffleEnabled = true;
        } else {
            trainingMode = AppPrefs.getTrainingMode(this);
            sessionTarget = AppPrefs.getSessionLength(this);
            currentExposureMs = AppPrefs.getExposureMs(this);
            currentChunkWords = AppPrefs.getChunkWords(this);
            adaptiveEnabled = AppPrefs.isAdaptive(this);
            shuffleEnabled = AppPrefs.isShuffleEnabled(this);
        }

        tachistoscopeView.setStimulusStyle(AppPrefs.getTypeface(this), AppPrefs.getFontSizeSp(this));
        tachistoscopeView.setAdaptiveDisplay(AppPrefs.isAdaptiveFontEnabled(this), AppPrefs.isAdaptiveBoxEnabled(this));
        tachistoscopeView.setExposureDurationMs(currentExposureMs);
        tachistoscopeView.setFixationDelayMs(intensiveProgramActive && intensiveDayPlan != null
                ? intensiveDayPlan.fixationMs : AppPrefs.getFixationMs(this));
        tachistoscopeView.setStimulus("");
        tachistoscopeView.setInteractionEnabled(false);

        proResponsePanel.setVisibility(trainingMode == AppPrefs.TRAINING_PRO ? View.VISIBLE : View.GONE);
        classicResponsePanel.setVisibility(trainingMode == AppPrefs.TRAINING_CLASSIC ? View.VISIBLE : View.GONE);
        setResponseEnabled(false);
        setExposureEnabled(false);
        settingsButton.setEnabled(true);
        historyButton.setEnabled(true);
        planButton.setEnabled(true);
        startStopButton.setText("ÎNCEPE SESIUNEA");

        if (intensiveProgramActive) {
            if (TrainingPlanStore.isFinished(this)) {
                stateText.setText("PROGRAM 30 ZILE • FINALIZAT");
                timingText.setText("Deschide PROGRES pentru comparația lunară sau PLAN pentru resetare.");
                scoreText.setText("30 / 30 niveluri promovate prin Mastery Gate.");
                feedbackText.setText("Planul rămâne activ, dar nu mai deblochează niveluri noi.");
                return;
            }
            stateText.setText("PROGRAM • ZIUA " + intensiveProgramDay + "/30 • " + intensiveDayPlan.title);
            timingText.setText(String.format(Locale.getDefault(),
                    "%s • %d ms • %d cuv./grup • %d expuneri • %d min/zi",
                    intensiveDayPlan.phase,
                    currentExposureMs,
                    currentChunkWords,
                    sessionTarget,
                    TrainingPlanStore.getMinutesPerDay(this)));
            scoreText.setText("Mastery Gate: global ≥90%/75% + 2 ferestre finale ≥92%/80%.");
            feedbackText.setText(intensiveDayPlan.description + "\nUrmătoarea zi eligibilă: "
                    + TrainingPlanStore.formatDate(TrainingPlanStore.getNextTrainingDate(this)));
        } else {
            String modeName = trainingMode == AppPrefs.TRAINING_PRO ? "PRO" : "CLASSIC";
            String contentMode = AppPrefs.getMode(this) == AppPrefs.CONTENT_CHUNKS
                    ? currentChunkWords + " cuvinte/bloc"
                    : "listă manuală";
            stateText.setText("GATA • " + modeName + " • " + sessionTarget + " expuneri");
            timingText.setText(String.format(Locale.getDefault(),
                    "%s • %d ms • fixație %d ms • adaptiv %s",
                    contentMode,
                    currentExposureMs,
                    AppPrefs.getFixationMs(this),
                    adaptiveEnabled ? "ON" : "OFF"));
            scoreText.setText("Pornește o sesiune pentru măsurare și progres.");
            feedbackText.setText(trainingMode == AppPrefs.TRAINING_PRO
                    ? "În modul Pro răspunsul este verificat automat pe cuvinte."
                    : "Classic păstrează autoevaluarea de tip InfoSpeed.");
        }
    }

    private void startSession() {
        intensiveProgramActive = TrainingPlanStore.isEnabled(this);
        if (intensiveProgramActive && TrainingPlanStore.isFinished(this)) {
            Toast.makeText(this, "Programul intensiv este deja finalizat. Vezi Progres sau resetează planul.", Toast.LENGTH_LONG).show();
            return;
        }
        if (intensiveProgramActive && !TrainingPlanStore.isTrainingAllowedToday(this)) {
            Toast.makeText(this,
                    "Următoarea zi de antrenament: " + TrainingPlanStore.formatDate(TrainingPlanStore.getNextTrainingDate(this)),
                    Toast.LENGTH_LONG).show();
            return;
        }

        List<String> available;
        if (intensiveProgramActive) {
            intensiveProgramDay = TrainingPlanStore.getCurrentDay(this);
            intensiveDayPlan = ExerciseLibrary.getDayPlan(intensiveProgramDay);
            available = ExerciseLibrary.getStimuliForDay(intensiveProgramDay);
        } else {
            available = AppPrefs.getStimuli(this, AppPrefs.getChunkWords(this));
        }
        if (available.isEmpty()) {
            Toast.makeText(this, "Nu există stimuli disponibili pentru sesiune.", Toast.LENGTH_LONG).show();
            return;
        }

        if (intensiveProgramActive) {
            trainingMode = AppPrefs.TRAINING_PRO;
            sessionTarget = TrainingPlanStore.getRecommendedTrials(this, intensiveProgramDay);
            currentExposureMs = intensiveDayPlan.exposureMs;
            currentChunkWords = intensiveDayPlan.chunkWords;
            adaptiveEnabled = false;
            shuffleEnabled = true;
        } else {
            trainingMode = AppPrefs.getTrainingMode(this);
            sessionTarget = AppPrefs.getSessionLength(this);
            currentExposureMs = AppPrefs.getExposureMs(this);
            currentChunkWords = AppPrefs.getChunkWords(this);
            adaptiveEnabled = AppPrefs.isAdaptive(this);
            shuffleEnabled = AppPrefs.isShuffleEnabled(this);
        }
        startExposureMs = currentExposureMs;
        startChunkWords = currentChunkWords;

        sessionActive = true;
        awaitingResponse = false;
        sessionTrials = 0;
        exactCorrect = 0;
        accuracySum = 0f;
        responseTimeSumMs = 0L;
        responseTimeCount = 0;
        responseStartElapsedMs = 0L;
        sessionStartTimestamp = System.currentTimeMillis();
        lastMeasuredExposureMs = 0f;
        lastAdaptationMessage = "";
        adaptiveController.reset();
        masteryGate.reset();

        tachistoscopeView.setStimulusStyle(AppPrefs.getTypeface(this), AppPrefs.getFontSizeSp(this));
        tachistoscopeView.setAdaptiveDisplay(AppPrefs.isAdaptiveFontEnabled(this), AppPrefs.isAdaptiveBoxEnabled(this));
        tachistoscopeView.setExposureDurationMs(currentExposureMs);
        tachistoscopeView.setFixationDelayMs(intensiveProgramActive ? intensiveDayPlan.fixationMs : AppPrefs.getFixationMs(this));

        proResponsePanel.setVisibility(trainingMode == AppPrefs.TRAINING_PRO ? View.VISIBLE : View.GONE);
        classicResponsePanel.setVisibility(trainingMode == AppPrefs.TRAINING_CLASSIC ? View.VISIBLE : View.GONE);
        settingsButton.setEnabled(false);
        historyButton.setEnabled(false);
        planButton.setEnabled(false);
        startStopButton.setText("OPREȘTE");
        setResponseEnabled(false);

        rebuildDeck();
        prepareNextTrial();
        updateSessionMetrics();
        feedbackText.setText(intensiveProgramActive
                ? "Ziua " + intensiveProgramDay + ": " + intensiveDayPlan.description
                : "Sesiune pornită. Fixează centrul și declanșează prima expunere.");
    }

    private void rebuildDeck() {
        deck.clear();
        if (intensiveProgramActive) deck.addAll(ExerciseLibrary.getStimuliForDay(intensiveProgramDay));
        else deck.addAll(AppPrefs.getStimuli(this, currentChunkWords));
        if (shuffleEnabled) Collections.shuffle(deck);
        deckIndex = 0;
    }

    private void prepareNextTrial() {
        if (!sessionActive) return;
        if (deck.isEmpty() || deckIndex >= deck.size()) rebuildDeck();
        if (deck.isEmpty()) {
            finishSession(true);
            return;
        }

        currentStimulus = deck.get(deckIndex++);
        tachistoscopeView.setStimulus(currentStimulus);
        tachistoscopeView.setExposureDurationMs(currentExposureMs);
        tachistoscopeView.setInteractionEnabled(true);
        awaitingResponse = false;
        setResponseEnabled(false);
        setExposureEnabled(true);
        answerInput.setText("");
        stateText.setText(String.format(Locale.getDefault(),
                "GATA • expunerea %d / %d", sessionTrials + 1, sessionTarget));
    }

    private void triggerExposureFromButton() {
        if (!sessionActive || awaitingResponse || tachistoscopeView.isBusy()) return;
        if (!tachistoscopeView.triggerExposureProgrammatically()) {
            Toast.makeText(this, "Expunerea nu este pregătită.", Toast.LENGTH_SHORT).show();
        }
    }

    private void submitTypedResponse(String response) {
        if (!sessionActive || !awaitingResponse || trainingMode != AppPrefs.TRAINING_PRO) return;
        long responseMs = Math.max(0L, SystemClock.elapsedRealtime() - responseStartElapsedMs);
        ResponseScorer.Score score = ResponseScorer.score(currentStimulus, response);
        String responseLabel = response == null || response.trim().isEmpty() ? "—" : response.trim();

        String feedback = String.format(Locale.getDefault(),
                "%s • scor %.0f%% • răspuns %d ms\nCorect: „%s” • Tu: „%s”",
                score.exact ? "EXACT" : "PARȚIAL",
                score.wordAccuracy * 100f,
                responseMs,
                currentStimulus,
                responseLabel);
        completeTrial(score.wordAccuracy, score.exact, responseMs, feedback);
    }

    private void submitClassicResponse(boolean seen) {
        if (!sessionActive || !awaitingResponse || trainingMode != AppPrefs.TRAINING_CLASSIC) return;
        String feedback = (seen ? "Marcat: AM VĂZUT." : "Marcat: NU AM VĂZUT.") +
                " Stimul: „" + currentStimulus + "”";
        completeTrial(seen ? 1f : 0f, seen, 0L, feedback);
    }

    private void completeTrial(float accuracy, boolean exact, long responseMs, String feedback) {
        awaitingResponse = false;
        hideKeyboard();
        setResponseEnabled(false);
        setExposureEnabled(false);

        sessionTrials++;
        accuracySum += Math.max(0f, Math.min(1f, accuracy));
        if (exact) exactCorrect++;
        if (trainingMode == AppPrefs.TRAINING_PRO) {
            responseTimeSumMs += responseMs;
            responseTimeCount++;
        }
        if (intensiveProgramActive) masteryGate.add(accuracy, exact);

        lastAdaptationMessage = "";
        if (adaptiveEnabled && !intensiveProgramActive) {
            boolean chunkCanAdapt = AppPrefs.getMode(this) == AppPrefs.CONTENT_CHUNKS;
            AdaptiveController.Decision decision = adaptiveController.add(
                    accuracy,
                    currentExposureMs,
                    currentChunkWords,
                    chunkCanAdapt
            );
            lastAdaptationMessage = decision.message;
            if (decision.changed) {
                boolean chunkChanged = decision.chunkWords != currentChunkWords;
                currentExposureMs = decision.exposureMs;
                currentChunkWords = decision.chunkWords;
                AppPrefs.setExposureMs(this, currentExposureMs);
                if (chunkCanAdapt) AppPrefs.setChunkWords(this, currentChunkWords);
                tachistoscopeView.setExposureDurationMs(currentExposureMs);
                if (chunkChanged) rebuildDeck();
            }
        }

        feedbackText.setText(lastAdaptationMessage.isEmpty()
                ? feedback
                : feedback + "\n" + lastAdaptationMessage);
        updateSessionMetrics();

        if (sessionTrials >= sessionTarget) {
            finishSession(false);
        } else {
            prepareNextTrial();
        }
    }

    private void updateSessionMetrics() {
        if (!sessionActive) return;
        float averageAccuracy = sessionTrials == 0 ? 0f : accuracySum / sessionTrials;
        long averageResponse = responseTimeCount == 0 ? 0L : responseTimeSumMs / responseTimeCount;
        String chunkText = intensiveProgramActive
                ? currentChunkWords + " unit./grup"
                : (AppPrefs.getMode(this) == AppPrefs.CONTENT_CHUNKS
                    ? currentChunkWords + " cuv./bloc"
                    : "listă");

        String successLabel = trainingMode == AppPrefs.TRAINING_PRO ? "exact" : "percepute";
        String baseScore = String.format(Locale.getDefault(),
                "%d / %d • acuratețe %.0f%% • %s %d • %s%s",
                sessionTrials,
                sessionTarget,
                averageAccuracy * 100f,
                successLabel,
                exactCorrect,
                chunkText,
                trainingMode == AppPrefs.TRAINING_PRO && responseTimeCount > 0
                        ? " • răspuns mediu " + averageResponse + " ms"
                        : "");
        scoreText.setText(intensiveProgramActive
                ? baseScore + "\n" + masteryGate.liveStatus()
                : baseScore);

        if (lastMeasuredExposureMs <= 0f) {
            timingText.setText(String.format(Locale.getDefault(),
                    "%d ms • %.1f Hz • %d cadre nominale • adaptiv %s",
                    currentExposureMs,
                    tachistoscopeView.getRefreshRateHz(),
                    tachistoscopeView.getTargetFrameCount(),
                    adaptiveEnabled ? "ON" : "OFF"));
        }
    }

    private void updateTimingQuality(int requestedMs, float measuredMs, int frameCount, float refreshRateHz) {
        float frameMs = 1000f / Math.max(1f, refreshRateHz);
        float nominalMs = frameCount * frameMs;
        float delta = Math.abs(measuredMs - nominalMs);
        String quality = delta <= frameMs * 1.25f ? "timing stabil" : "variație de cadre";
        timingText.setText(String.format(Locale.getDefault(),
                "Cerut %d ms • măsurat %.1f ms • %.1f Hz • %d cadre • %s",
                requestedMs, measuredMs, refreshRateHz, frameCount, quality));
    }

    private void finishSession(boolean manualStop) {
        if (!sessionActive) return;

        float averageAccuracy = sessionTrials == 0 ? 0f : accuracySum / sessionTrials;
        long averageResponse = responseTimeCount == 0 ? 0L : responseTimeSumMs / responseTimeCount;
        int completedTrials = sessionTrials;
        int completedExact = exactCorrect;
        int endExposure = currentExposureMs;
        int endChunk = currentChunkWords;
        MasteryGate.Result masteryResult = intensiveProgramActive
                ? masteryGate.evaluate(completedTrials, sessionTarget, manualStop)
                : null;

        if (sessionTrials > 0) saveSessionRecord(masteryResult != null && masteryResult.mastered);
        if (intensiveProgramActive && sessionTrials > 0) {
            TrainingPlanStore.recordAttempt(this, intensiveProgramDay, masteryResult != null && masteryResult.mastered);
        }

        sessionActive = false;
        awaitingResponse = false;
        tachistoscopeView.setInteractionEnabled(false);
        tachistoscopeView.setStimulus("");
        setExposureEnabled(false);
        setResponseEnabled(false);
        settingsButton.setEnabled(true);
        historyButton.setEnabled(true);
        planButton.setEnabled(true);
        startStopButton.setText("ÎNCEPE SESIUNEA");
        hideKeyboard();

        if (intensiveProgramActive && masteryResult != null) {
            stateText.setText(masteryResult.mastered ? "NIVEL PROMOVAT" : "NIVEL BLOCAT • REPETĂ");
            timingText.setText(String.format(Locale.getDefault(),
                    "Ziua %d • %d ms • %d cuv./grup", intensiveProgramDay, endExposure, endChunk));
            scoreText.setText(String.format(Locale.getDefault(),
                    "%d expuneri • acuratețe %.0f%% • exacte %d • Mastery %d/%d",
                    completedTrials,
                    averageAccuracy * 100f,
                    completedExact,
                    Math.min(masteryResult.consecutiveComfortWindows, MasteryGate.REQUIRED_CONSECUTIVE_WINDOWS),
                    MasteryGate.REQUIRED_CONSECUTIVE_WINDOWS));
            feedbackText.setText(masteryResult.message);

            String nextLine;
            if (masteryResult.mastered && TrainingPlanStore.isFinished(this)) {
                nextLine = "Programul de 30 zile este finalizat. Deschide PROGRES pentru comparația lunară.";
            } else if (masteryResult.mastered) {
                int nextDay = TrainingPlanStore.getCurrentDay(this);
                nextLine = "Deblocat: Ziua " + nextDay + " • " + ExerciseLibrary.getDayPlan(nextDay).title
                        + "\nUrmătoarea dată: " + TrainingPlanStore.formatDate(TrainingPlanStore.getNextTrainingDate(this));
            } else {
                nextLine = "Ziua " + intensiveProgramDay + " rămâne activă. Nivelul următor nu poate fi accesat.";
            }

            String message = String.format(Locale.getDefault(),
                    "%s\n\nExpuneri: %d/%d\nAcuratețe: %.0f%%\nExacte: %d\nRăspuns mediu: %d ms\n\n%s",
                    masteryResult.message,
                    completedTrials,
                    sessionTarget,
                    averageAccuracy * 100f,
                    completedExact,
                    averageResponse,
                    nextLine);
            new AlertDialog.Builder(this)
                    .setTitle(masteryResult.mastered ? "Mastery Gate trecut" : "Mastery Gate neîndeplinit")
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .setNeutralButton("VEZI PROGRES", (dialog, which) -> startActivity(new Intent(this, HistoryActivity.class)))
                    .show();
            return;
        }

        stateText.setText(manualStop ? "SESIUNE OPRITĂ" : "SESIUNE FINALIZATĂ");
        timingText.setText(String.format(Locale.getDefault(),
                "Nivel final: %d ms • %d cuv./bloc", endExposure, endChunk));
        String completedSuccessLabel = trainingMode == AppPrefs.TRAINING_PRO ? "exact" : "percepute";
        scoreText.setText(String.format(Locale.getDefault(),
                "%d expuneri • acuratețe %.0f%% • %s %d%s",
                completedTrials,
                averageAccuracy * 100f,
                completedSuccessLabel,
                completedExact,
                trainingMode == AppPrefs.TRAINING_PRO && averageResponse > 0
                        ? " • răspuns mediu " + averageResponse + " ms"
                        : ""));
        feedbackText.setText("Rezultatul a fost salvat în Progres.");

        if (completedTrials > 0) {
            String successLine = trainingMode == AppPrefs.TRAINING_PRO ? "Exacte" : "Percepute";
            String message = String.format(Locale.getDefault(),
                    "Expuneri: %d\nAcuratețe: %.0f%%\n%s: %d\nNivel: %d → %d ms\nBloc: %d → %d cuvinte%s",
                    completedTrials,
                    averageAccuracy * 100f,
                    successLine,
                    completedExact,
                    startExposureMs,
                    endExposure,
                    startChunkWords,
                    endChunk,
                    trainingMode == AppPrefs.TRAINING_PRO && averageResponse > 0
                            ? "\nRăspuns mediu: " + averageResponse + " ms"
                            : "");
            new AlertDialog.Builder(this)
                    .setTitle(manualStop ? "Sesiune oprită" : "Sesiune completă")
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .setNeutralButton("VEZI PROGRES", (dialog, which) -> startActivity(new Intent(this, HistoryActivity.class)))
                    .show();
        }
    }

    private void saveSessionRecord(boolean masteryPassed) {
        SessionStore.SessionRecord record = new SessionStore.SessionRecord();
        record.timestamp = sessionStartTimestamp > 0L ? sessionStartTimestamp : System.currentTimeMillis();
        record.trials = sessionTrials;
        record.exactCorrect = exactCorrect;
        record.averageAccuracy = sessionTrials == 0 ? 0f : accuracySum / sessionTrials;
        record.averageResponseMs = responseTimeCount == 0 ? 0L : responseTimeSumMs / responseTimeCount;
        record.startExposureMs = startExposureMs;
        record.endExposureMs = currentExposureMs;
        record.startChunkWords = startChunkWords;
        record.endChunkWords = currentChunkWords;
        record.trainingMode = trainingMode;
        record.adaptive = adaptiveEnabled;
        record.refreshRateHz = lastRefreshRateHz;
        record.programMode = intensiveProgramActive;
        record.programDay = intensiveProgramActive ? intensiveProgramDay : 0;
        record.exerciseTitle = intensiveProgramActive && intensiveDayPlan != null ? intensiveDayPlan.title : "Manual";
        record.masteryPassed = masteryPassed;
        record.plannedMinutes = intensiveProgramActive ? TrainingPlanStore.getMinutesPerDay(this) : 0;
        record.performanceIndex = calculatePerformanceIndex(record.averageAccuracy, record.endChunkWords, record.endExposureMs);
        SessionStore.add(this, record);
    }

    private float calculatePerformanceIndex(float accuracy, int words, int exposureMs) {
        if (exposureMs <= 0) return 0f;
        return Math.max(0f, accuracy) * Math.max(1, words) * (1000f / exposureMs);
    }

    private void setExposureEnabled(boolean enabled) {
        if (exposeButton != null) exposeButton.setEnabled(enabled && sessionActive && !awaitingResponse);
    }

    private void setResponseEnabled(boolean enabled) {
        boolean pro = enabled && trainingMode == AppPrefs.TRAINING_PRO;
        boolean classic = enabled && trainingMode == AppPrefs.TRAINING_CLASSIC;
        if (answerInput != null) answerInput.setEnabled(pro);
        if (verifyButton != null) verifyButton.setEnabled(pro);
        if (dontKnowButton != null) dontKnowButton.setEnabled(pro);
        if (seenButton != null) seenButton.setEnabled(classic);
        if (missedButton != null) missedButton.setEnabled(classic);
    }

    private void openPlanner() {
        if (sessionActive) {
            Toast.makeText(this, "Oprește sesiunea înainte de a modifica planul.", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new Intent(this, PlannerActivity.class));
    }

    private void openSettings() {
        if (sessionActive) {
            Toast.makeText(this, "Oprește sesiunea înainte de a modifica setările.", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new Intent(this, SettingsActivity.class));
    }

    private void openHistory() {
        if (sessionActive) {
            Toast.makeText(this, "Oprește sesiunea înainte de a deschide progresul.", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new Intent(this, HistoryActivity.class));
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus == null) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        focus.clearFocus();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
