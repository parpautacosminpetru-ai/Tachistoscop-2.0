package ro.tachistoscop.app;

import java.util.Locale;

/**
 * Poartă de promovare pentru programul intensiv.
 * „Ușurința” este operaționalizată prin două ferestre consecutive cu
 * acuratețe ridicată și rată mare de răspunsuri exacte.
 */
public final class MasteryGate {
    public static final int WINDOW_SIZE = 10;
    public static final int REQUIRED_CONSECUTIVE_WINDOWS = 2;
    public static final float ACCURACY_THRESHOLD = 0.92f;
    public static final float EXACT_THRESHOLD = 0.80f;
    public static final float SESSION_ACCURACY_THRESHOLD = 0.90f;
    public static final float SESSION_EXACT_THRESHOLD = 0.75f;

    public static final class Result {
        public final boolean mastered;
        public final int consecutiveComfortWindows;
        public final float lastWindowAccuracy;
        public final float lastWindowExactRate;
        public final String message;

        Result(boolean mastered, int consecutiveComfortWindows,
               float lastWindowAccuracy, float lastWindowExactRate, String message) {
            this.mastered = mastered;
            this.consecutiveComfortWindows = consecutiveComfortWindows;
            this.lastWindowAccuracy = lastWindowAccuracy;
            this.lastWindowExactRate = lastWindowExactRate;
            this.message = message;
        }
    }

    private int windowCount;
    private float windowAccuracySum;
    private int windowExact;
    private int consecutiveComfortWindows;
    private float lastWindowAccuracy;
    private float lastWindowExactRate;
    private int sessionCount;
    private float sessionAccuracySum;
    private int sessionExact;

    public void reset() {
        windowCount = 0;
        windowAccuracySum = 0f;
        windowExact = 0;
        consecutiveComfortWindows = 0;
        lastWindowAccuracy = 0f;
        lastWindowExactRate = 0f;
        sessionCount = 0;
        sessionAccuracySum = 0f;
        sessionExact = 0;
    }

    public void add(float accuracy, boolean exact) {
        float safeAccuracy = clamp(accuracy);
        sessionCount++;
        sessionAccuracySum += safeAccuracy;
        if (exact) sessionExact++;
        windowCount++;
        windowAccuracySum += safeAccuracy;
        if (exact) windowExact++;

        if (windowCount >= WINDOW_SIZE) {
            lastWindowAccuracy = windowAccuracySum / WINDOW_SIZE;
            lastWindowExactRate = windowExact / (float) WINDOW_SIZE;
            boolean comfortable = lastWindowAccuracy >= ACCURACY_THRESHOLD
                    && lastWindowExactRate >= EXACT_THRESHOLD;
            consecutiveComfortWindows = comfortable ? consecutiveComfortWindows + 1 : 0;
            windowCount = 0;
            windowAccuracySum = 0f;
            windowExact = 0;
        }
    }

    public int getConsecutiveComfortWindows() {
        return consecutiveComfortWindows;
    }

    public String liveStatus() {
        return String.format(Locale.getDefault(),
                "Mastery %d/%d ferestre • prag %.0f%% acuratețe + %.0f%% exact",
                Math.min(consecutiveComfortWindows, REQUIRED_CONSECUTIVE_WINDOWS),
                REQUIRED_CONSECUTIVE_WINDOWS,
                ACCURACY_THRESHOLD * 100f,
                EXACT_THRESHOLD * 100f);
    }

    public Result evaluate(int completedTrials, int targetTrials, boolean manualStop) {
        boolean fullSession = !manualStop && completedTrials >= targetTrials;
        float sessionAccuracy = sessionCount == 0 ? 0f : sessionAccuracySum / sessionCount;
        float sessionExactRate = sessionCount == 0 ? 0f : sessionExact / (float) sessionCount;
        boolean overallComfort = sessionAccuracy >= SESSION_ACCURACY_THRESHOLD
                && sessionExactRate >= SESSION_EXACT_THRESHOLD;
        boolean mastered = fullSession
                && overallComfort
                && consecutiveComfortWindows >= REQUIRED_CONSECUTIVE_WINDOWS;
        String message;
        if (mastered) {
            message = String.format(Locale.getDefault(),
                    "PROMOVAT: %.0f%% acuratețe globală, %.0f%% exact și două ferestre finale stabile.",
                    sessionAccuracy * 100f, sessionExactRate * 100f);
        } else if (!fullSession) {
            message = "NEPROMOVAT: sesiunea trebuie finalizată integral pentru deblocarea nivelului următor.";
        } else {
            message = String.format(Locale.getDefault(),
                    "REPETĂ NIVELUL: global %.0f%% acuratețe / %.0f%% exact; ferestre stabile %d/%d. Praguri: global ≥%.0f%%/%.0f%% și ultimele ferestre ≥%.0f%%/%.0f%%.",
                    sessionAccuracy * 100f,
                    sessionExactRate * 100f,
                    Math.min(consecutiveComfortWindows, REQUIRED_CONSECUTIVE_WINDOWS),
                    REQUIRED_CONSECUTIVE_WINDOWS,
                    SESSION_ACCURACY_THRESHOLD * 100f,
                    SESSION_EXACT_THRESHOLD * 100f,
                    ACCURACY_THRESHOLD * 100f,
                    EXACT_THRESHOLD * 100f);
        }
        return new Result(mastered, consecutiveComfortWindows,
                lastWindowAccuracy, lastWindowExactRate, message);
    }

    private float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
