package ro.tachistoscop.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.Locale;

public class TachistoscopeView extends View {
    public interface ExposureListener {
        default void onFixationStarted(int fixationMs) { }
        void onExposureStarted(int requestedMs, float nominalMs, int frameCount, float refreshRateHz);
        void onExposureFinished(int requestedMs, float measuredMs, int frameCount, float refreshRateHz);
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bodyRect = new RectF();
    private final RectF windowRect = new RectF();
    private final RectF slitRect = new RectF();
    private final RectF leverTrackRect = new RectF();
    private final RectF leverKnobRect = new RectF();
    private final RectF hitRect = new RectF();

    private String stimulus = "";
    private Typeface stimulusTypeface = Typeface.SERIF;
    private float stimulusSizeSp = 42f;
    private boolean adaptiveFontEnabled = true;
    private boolean adaptiveBoxEnabled = true;

    private float pull = 0f;
    private float dragStartY;
    private float dragStartPull;
    private boolean dragging = false;
    private boolean preparing = false;
    private boolean exposing = false;
    private boolean stimulusVisible = false;
    private boolean interactionEnabled = true;

    private int requestedExposureMs = 100;
    private int fixationDelayMs = 350;
    private int targetFrames = 6;
    private int remainingFrames = 0;
    private float refreshRateHz = 60f;
    private float nominalExposureMs = 100f;
    private long visibleStartFrameNanos = 0L;

    private ExposureListener exposureListener;
    private LinearGradient bodyGradient;
    private LinearGradient shutterGradient;
    private LinearGradient leverGradient;

    private final Runnable beginExposureRunnable = new Runnable() {
        @Override
        public void run() {
            if (!preparing || exposing) return;
            preparing = false;
            updateTimingProfile();
            exposing = true;
            stimulusVisible = false;
            remainingFrames = targetFrames;
            visibleStartFrameNanos = 0L;
            Choreographer.getInstance().removeFrameCallback(exposureFrameCallback);
            Choreographer.getInstance().postFrameCallback(exposureFrameCallback);
            invalidate();
        }
    };

    private final Choreographer.FrameCallback exposureFrameCallback = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long frameTimeNanos) {
            if (!exposing) return;

            if (!stimulusVisible) {
                stimulusVisible = true;
                visibleStartFrameNanos = frameTimeNanos;
                remainingFrames = targetFrames;
                invalidate();

                if (exposureListener != null) {
                    exposureListener.onExposureStarted(
                            requestedExposureMs,
                            nominalExposureMs,
                            targetFrames,
                            refreshRateHz
                    );
                }
                Choreographer.getInstance().postFrameCallback(this);
                return;
            }

            remainingFrames--;
            if (remainingFrames <= 0) {
                stimulusVisible = false;
                exposing = false;
                float measuredMs = visibleStartFrameNanos > 0L
                        ? (frameTimeNanos - visibleStartFrameNanos) / 1_000_000f
                        : nominalExposureMs;
                invalidate();

                if (exposureListener != null) {
                    exposureListener.onExposureFinished(
                            requestedExposureMs,
                            measuredMs,
                            targetFrames,
                            refreshRateHz
                    );
                }
            } else {
                Choreographer.getInstance().postFrameCallback(this);
            }
        }
    };

    public TachistoscopeView(Context context) {
        super(context);
        init();
    }

    public TachistoscopeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setFocusable(true);
        setClickable(true);
        setBackgroundColor(Color.rgb(231, 215, 183));
        textPaint.setColor(Color.rgb(31, 26, 22));
        textPaint.setTextAlign(Paint.Align.CENTER);
        updateTimingProfile();
    }

    public void setStimulus(String value) {
        stimulus = value == null ? "" : value;
        invalidate();
    }

    public void setStimulusStyle(Typeface typeface, float sizeSp) {
        stimulusTypeface = typeface == null ? Typeface.SERIF : typeface;
        stimulusSizeSp = Math.max(22f, Math.min(72f, sizeSp));
        invalidate();
    }

    public void setAdaptiveDisplay(boolean adaptiveFont, boolean adaptiveBox) {
        adaptiveFontEnabled = adaptiveFont;
        adaptiveBoxEnabled = adaptiveBox;
        invalidate();
    }

    public void setExposureDurationMs(int exposureMs) {
        requestedExposureMs = Math.max(16, Math.min(2000, exposureMs));
        updateTimingProfile();
        invalidate();
    }

    public void setFixationDelayMs(int fixationMs) {
        fixationDelayMs = Math.max(0, Math.min(3000, fixationMs));
        invalidate();
    }

    public int getRequestedExposureMs() {
        return requestedExposureMs;
    }

    public int getTargetFrameCount() {
        updateTimingProfile();
        return targetFrames;
    }

    public float getRefreshRateHz() {
        updateTimingProfile();
        return refreshRateHz;
    }

    public float getNominalExposureMs() {
        updateTimingProfile();
        return nominalExposureMs;
    }

    public boolean isExposing() {
        return exposing;
    }

    public boolean isBusy() {
        return preparing || exposing;
    }

    public void setInteractionEnabled(boolean enabled) {
        interactionEnabled = enabled;
        if (!enabled && dragging) {
            dragging = false;
            springLeverBack();
        }
        invalidate();
    }

    public void setExposureListener(ExposureListener listener) {
        exposureListener = listener;
    }

    public boolean triggerExposureProgrammatically() {
        return triggerExposure();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        bodyGradient = new LinearGradient(0, 0, w, h,
                new int[]{Color.rgb(104, 61, 34), Color.rgb(128, 79, 43), Color.rgb(82, 47, 28)},
                null, Shader.TileMode.CLAMP);
        shutterGradient = new LinearGradient(0, 0, 0, h,
                new int[]{Color.rgb(118, 71, 40), Color.rgb(88, 50, 29), Color.rgb(125, 76, 42)},
                null, Shader.TileMode.CLAMP);
        leverGradient = new LinearGradient(0, 0, w, 0,
                new int[]{Color.rgb(67, 39, 23), Color.rgb(145, 92, 54), Color.rgb(80, 46, 26)},
                null, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        float pad = dp(18);
        float top = dp(22);
        float bottom = h - dp(34);
        bodyRect.set(pad, top, w - pad, bottom);

        paint.setShader(bodyGradient);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(bodyRect, dp(22), dp(22), paint);
        paint.setShader(null);
        drawWoodGrain(canvas, bodyRect, 0.10f);

        float innerLeft = bodyRect.left + dp(28);
        float innerRight = bodyRect.right - dp(82);
        float innerTop = bodyRect.top + dp(66);
        float innerBottom = bodyRect.bottom - dp(76);
        windowRect.set(innerLeft, innerTop, innerRight, innerBottom);

        paint.setColor(Color.rgb(52, 31, 20));
        canvas.drawRoundRect(expand(windowRect, dp(8)), dp(10), dp(10), paint);

        paint.setColor(Color.rgb(68, 44, 30));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        paint.setTextSize(sp(17));
        canvas.drawText("TACHISTOSCOP • PRO 2.0", bodyRect.centerX() - dp(26), bodyRect.top + dp(42), paint);

        drawInfoSpeedWindow(canvas);
        drawLever(canvas);
        drawInstructions(canvas);
    }

    private void drawInfoSpeedWindow(Canvas canvas) {
        updateSlitRectForCurrentState();

        paint.setShader(shutterGradient);
        canvas.drawRoundRect(windowRect, dp(5), dp(5), paint);
        paint.setShader(null);
        drawWoodGrain(canvas, windowRect, 0.14f);

        paint.setColor(Color.rgb(250, 244, 226));
        canvas.drawRoundRect(slitRect, dp(4), dp(4), paint);

        paint.setColor(Color.rgb(73, 43, 25));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2));
        canvas.drawRoundRect(slitRect, dp(4), dp(4), paint);
        paint.setStyle(Paint.Style.FILL);

        if (stimulusVisible) drawStimulus(canvas);
        else drawHiddenState(canvas);
    }

    private void updateSlitRectForCurrentState() {
        float maxWidth = Math.max(dp(120), windowRect.width() - dp(16));
        float minWidth = Math.min(maxWidth, dp(128));
        float width;
        float height;

        if (!stimulusVisible) {
            // Dimensiunea reală a stimulului nu este divulgată înainte de flash.
            width = adaptiveBoxEnabled
                    ? Math.max(minWidth, Math.min(maxWidth, windowRect.width() * 0.58f))
                    : maxWidth;
            height = Math.min(dp(92), Math.max(dp(76), windowRect.height() * 0.29f));
        } else {
            String value = normalizedStimulus();
            textPaint.setTypeface(stimulusTypeface);
            textPaint.setTextSize(sp(stimulusSizeSp));
            float desiredTextWidth = measureStimulusAtCurrentSize(value);
            float desiredWidth = desiredTextWidth + dp(36);
            width = adaptiveBoxEnabled ? clamp(desiredWidth, minWidth, maxWidth) : maxWidth;

            float fontPx = chooseTextSizePx(value, width * 0.88f);
            textPaint.setTextSize(fontPx);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            float desiredHeight = (fm.descent - fm.ascent) + dp(28);
            height = adaptiveBoxEnabled
                    ? clamp(desiredHeight, dp(72), Math.min(dp(118), windowRect.height() * 0.45f))
                    : Math.min(dp(108), Math.max(dp(76), windowRect.height() * 0.31f));
        }

        slitRect.set(
                windowRect.centerX() - width / 2f,
                windowRect.centerY() - height / 2f,
                windowRect.centerX() + width / 2f,
                windowRect.centerY() + height / 2f
        );
    }

    private String normalizedStimulus() {
        return stimulus == null ? "" : stimulus.trim().replaceAll("\\s+", " ");
    }

    private float measureStimulusAtCurrentSize(String value) {
        if (value == null || value.isEmpty()) return 0f;
        if (value.contains("¦")) {
            String[] parts = value.split("\\s*¦\\s*", 2);
            float left = parts.length > 0 ? textPaint.measureText(parts[0]) : 0f;
            float right = parts.length > 1 ? textPaint.measureText(parts[1]) : 0f;
            return left + right + dp(72);
        }
        return textPaint.measureText(value);
    }

    private float chooseTextSizePx(String value, float usableWidth) {
        float requestedPx = sp(stimulusSizeSp);
        if (!adaptiveFontEnabled || value == null || value.isEmpty()) return requestedPx;
        float minPx = sp(18f);
        textPaint.setTextSize(requestedPx);

        float measured;
        if (value.contains("¦")) {
            String[] parts = value.split("\\s*¦\\s*", 2);
            float left = parts.length > 0 ? textPaint.measureText(parts[0]) : 0f;
            float right = parts.length > 1 ? textPaint.measureText(parts[1]) : 0f;
            measured = Math.max(left, right);
            usableWidth = usableWidth * 0.39f;
        } else {
            measured = textPaint.measureText(value);
        }

        if (measured <= 0f || measured <= usableWidth) return requestedPx;
        return Math.max(minPx, requestedPx * usableWidth / measured);
    }

    private void drawHiddenState(Canvas canvas) {
        String value = normalizedStimulus();
        if (value.isEmpty()) {
            paint.setColor(Color.rgb(112, 94, 72));
            paint.setTypeface(Typeface.SANS_SERIF);
            paint.setTextSize(sp(12));
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Încarcă stimuli sau activează Plan 30 zile", slitRect.centerX(), slitRect.centerY() + dp(4), paint);
            return;
        }

        paint.setColor(preparing ? Color.rgb(90, 62, 43) : Color.rgb(126, 108, 86));
        paint.setStrokeWidth(dp(preparing ? 2.2f : 1.5f));
        float r = dp(preparing ? 7 : 5);
        canvas.drawLine(slitRect.centerX() - r, slitRect.centerY(), slitRect.centerX() + r, slitRect.centerY(), paint);
        canvas.drawLine(slitRect.centerX(), slitRect.centerY() - r, slitRect.centerX(), slitRect.centerY() + r, paint);
    }

    private void drawStimulus(Canvas canvas) {
        String value = normalizedStimulus();
        if (value.isEmpty()) return;

        canvas.save();
        canvas.clipRect(slitRect);

        textPaint.setColor(Color.rgb(29, 27, 23));
        textPaint.setTypeface(stimulusTypeface);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(chooseTextSizePx(value, slitRect.width() * 0.88f));

        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float baseline = slitRect.centerY() - (fm.ascent + fm.descent) / 2f;

        if (value.contains("¦")) {
            String[] parts = value.split("\\s*¦\\s*", 2);
            String left = parts.length > 0 ? parts[0] : "";
            String right = parts.length > 1 ? parts[1] : "";
            float offset = slitRect.width() * 0.27f;
            canvas.drawText(left, slitRect.centerX() - offset, baseline, textPaint);
            canvas.drawText(right, slitRect.centerX() + offset, baseline, textPaint);

            paint.setColor(Color.rgb(86, 64, 47));
            canvas.drawCircle(slitRect.centerX(), slitRect.centerY(), dp(3.2f), paint);
        } else {
            canvas.drawText(value, slitRect.centerX(), baseline, textPaint);
        }
        canvas.restore();
    }

    private void drawLever(Canvas canvas) {
        float trackLeft = bodyRect.right - dp(56);
        float trackRight = bodyRect.right - dp(28);
        float trackTop = bodyRect.top + dp(82);
        float trackBottom = bodyRect.bottom - dp(82);
        leverTrackRect.set(trackLeft, trackTop, trackRight, trackBottom);

        paint.setColor(Color.rgb(47, 29, 18));
        canvas.drawRoundRect(leverTrackRect, dp(12), dp(12), paint);

        float knobHeight = dp(70);
        float knobTravel = Math.max(0f, leverTrackRect.height() - knobHeight - dp(8));
        float knobTop = leverTrackRect.top + dp(4) + pull * knobTravel;
        leverKnobRect.set(
                leverTrackRect.left - dp(9),
                knobTop,
                leverTrackRect.right + dp(9),
                knobTop + knobHeight
        );

        paint.setShader(leverGradient);
        canvas.drawRoundRect(leverKnobRect, dp(12), dp(12), paint);
        paint.setShader(null);
        drawWoodGrain(canvas, leverKnobRect, 0.20f);

        paint.setColor(Color.rgb(214, 176, 114));
        canvas.drawCircle(leverKnobRect.centerX(), leverKnobRect.centerY(), dp(5), paint);
        paint.setColor(Color.rgb(52, 31, 20));
        canvas.drawCircle(leverKnobRect.centerX(), leverKnobRect.centerY(), dp(2), paint);

        hitRect.set(
                leverTrackRect.left - dp(28),
                leverTrackRect.top - dp(26),
                leverTrackRect.right + dp(28),
                leverTrackRect.bottom + dp(26)
        );

        paint.setColor(Color.argb(190, 244, 225, 191));
        paint.setTextSize(sp(10));
        paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("TRAGE", leverTrackRect.centerX(), leverTrackRect.bottom + dp(26), paint);
    }

    private void drawInstructions(Canvas canvas) {
        String message;
        if (exposing) {
            message = String.format(Locale.getDefault(), "EXPUNERE • %d ms • %d cadre", requestedExposureMs, targetFrames);
        } else if (preparing) {
            message = fixationDelayMs > 0 ? "FIXEAZĂ PUNCTUL CENTRAL" : "PREGĂTIRE EXPUNERE";
        } else if (dragging) {
            int percent = Math.round(pull * 100f);
            message = "Armat " + percent + "% • eliberează";
        } else if (!interactionEnabled) {
            message = "Răspunde înainte de următoarea expunere";
        } else {
            message = "Trage mânerul sau folosește EXPUNE";
        }

        paint.setColor(Color.rgb(63, 42, 29));
        paint.setTypeface(Typeface.SANS_SERIF);
        paint.setTextSize(sp(11));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(message, bodyRect.centerX() - dp(18), bodyRect.bottom - dp(24), paint);
    }

    private void drawWoodGrain(Canvas canvas, RectF rect, float opacity) {
        int alpha = Math.max(10, Math.min(80, (int) (255 * opacity)));
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.argb(alpha, 44, 24, 13));

        int lines = 17;
        for (int i = 0; i < lines; i++) {
            float y = rect.top + (i + 1) * rect.height() / (lines + 1f);
            float wobble = (float) Math.sin(i * 1.7) * dp(3);
            canvas.drawLine(rect.left + dp(5), y, rect.right - dp(5), y + wobble, paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!interactionEnabled || isBusy()) return true;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (hitRect.contains(event.getX(), event.getY())) {
                    dragging = true;
                    dragStartY = event.getY();
                    dragStartPull = pull;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (dragging) {
                    float usable = Math.max(dp(120), leverTrackRect.height() - dp(80));
                    float delta = (event.getY() - dragStartY) / usable;
                    pull = clamp(dragStartPull + delta, 0f, 1f);
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
                if (dragging) {
                    dragging = false;
                    float armedPull = pull;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    springLeverBack();
                    if (armedPull >= 0.22f) triggerExposure();
                    performClick();
                }
                return true;

            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                springLeverBack();
                return true;

            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private boolean triggerExposure() {
        if (!interactionEnabled || isBusy() || stimulus == null || stimulus.trim().isEmpty()) return false;

        preparing = true;
        stimulusVisible = false;
        removeCallbacks(beginExposureRunnable);
        Choreographer.getInstance().removeFrameCallback(exposureFrameCallback);
        if (exposureListener != null) exposureListener.onFixationStarted(fixationDelayMs);

        if (fixationDelayMs <= 0) post(beginExposureRunnable);
        else postDelayed(beginExposureRunnable, fixationDelayMs);
        invalidate();
        return true;
    }

    private void updateTimingProfile() {
        float rate = 60f;
        Display display = getDisplay();
        if (display != null && display.getRefreshRate() >= 30f) rate = display.getRefreshRate();

        refreshRateHz = rate;
        float frameMs = 1000f / refreshRateHz;
        targetFrames = Math.max(1, Math.round(requestedExposureMs / frameMs));
        nominalExposureMs = targetFrames * frameMs;
    }

    private void springLeverBack() {
        ValueAnimator reset = ValueAnimator.ofFloat(pull, 0f);
        reset.setDuration(140);
        reset.setInterpolator(new DecelerateInterpolator());
        reset.addUpdateListener(animation -> {
            pull = (float) animation.getAnimatedValue();
            invalidate();
        });
        reset.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(beginExposureRunnable);
        Choreographer.getInstance().removeFrameCallback(exposureFrameCallback);
        preparing = false;
        exposing = false;
        stimulusVisible = false;
        super.onDetachedFromWindow();
    }

    private RectF expand(RectF src, float amount) {
        return new RectF(src.left - amount, src.top - amount, src.right + amount, src.bottom + amount);
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private float dp(float value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    private float sp(float value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value, getResources().getDisplayMetrics());
    }
}
