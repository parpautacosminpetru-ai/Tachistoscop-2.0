package ro.tachistoscop.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Bibliotecă offline pentru programul intensiv. Nu pretinde validare clinică;
 * oferă stimuli controlați și progresie reproductibilă pentru antrenament.
 */
public final class ExerciseLibrary {
    public static final int PROGRAM_DAYS = 30;

    public static final int KIND_SYLLABLES = 0;
    public static final int KIND_WORDS = 1;
    public static final int KIND_DIGITS = 2;
    public static final int KIND_PHRASES = 3;
    public static final int KIND_PERIPHERAL = 4;

    public static final class DayPlan {
        public final int day;
        public final String phase;
        public final String title;
        public final String description;
        public final int kind;
        public final int chunkWords;
        public final int exposureMs;
        public final int fixationMs;
        public final boolean evaluation;

        DayPlan(int day, String phase, String title, String description, int kind,
                int chunkWords, int exposureMs, int fixationMs, boolean evaluation) {
            this.day = day;
            this.phase = phase;
            this.title = title;
            this.description = description;
            this.kind = kind;
            this.chunkWords = chunkWords;
            this.exposureMs = exposureMs;
            this.fixationMs = fixationMs;
            this.evaluation = evaluation;
        }

        public String shortLabel() {
            return "Ziua " + day + " • " + title;
        }
    }

    private static final String[] SYLLABLES = {
            "MA", "ME", "MI", "MO", "MU", "RA", "RE", "RI", "RO", "RU",
            "PA", "PE", "PI", "PO", "PU", "TA", "TE", "TI", "TO", "TU",
            "LA", "LE", "LI", "LO", "LU", "CA", "CE", "CI", "CO", "CU",
            "BRA", "BRE", "BRI", "BRO", "BRU", "CRA", "CRE", "CRI", "CRO", "CRU",
            "DRA", "DRE", "DRI", "DRO", "DRU", "FRA", "FRE", "FRI", "FRO", "FRU",
            "GRA", "GRE", "GRI", "GRO", "GRU", "PLA", "PLE", "PLI", "PLO", "PLU",
            "TRA", "TRE", "TRI", "TRO", "TRU", "STA", "STE", "STI", "STO", "STU"
    };

    private static final String[] WORDS = {
            "casă", "carte", "drum", "masă", "parc", "munte", "râu", "soare", "lună", "cer",
            "timp", "ritm", "sens", "text", "pagină", "linie", "semn", "punct", "cadru", "fereastră",
            "atenție", "memorie", "privire", "lectură", "viteză", "precizie", "focalizare", "percepție", "înțelegere", "concentrare",
            "rapid", "clar", "stabil", "simplu", "direct", "scurt", "larg", "central", "vizual", "corect",
            "citesc", "observ", "recunosc", "fixez", "compar", "rețin", "aleg", "urmez", "verific", "continui",
            "dimineață", "seară", "lumină", "umbră", "culoare", "formă", "spațiu", "mișcare", "direcție", "distanță",
            "idee", "fraza", "mesaj", "cuvânt", "silabă", "propoziție", "capitol", "autor", "subiect", "detaliu",
            "energie", "efort", "calm", "pauză", "progres", "nivel", "exercițiu", "răspuns", "rezultat", "antrenament",
            "cititor", "obiectiv", "metodă", "control", "măsurare", "repetare", "ușurință", "acuratețe", "fluență", "ritmicitate",
            "bibliotecă", "informație", "structură", "context", "conținut", "procesare", "orientare", "anticipare", "selectare", "integrare"
    };

    private static final String[] SENTENCES = {
            "citirea rapidă cere atenție stabilă și percepție vizuală clară",
            "privirea rămâne calmă în centrul zonei de expunere",
            "grupurile de cuvinte sunt recunoscute fără reveniri inutile",
            "ritmul crește numai după ce răspunsul devine sigur",
            "precizia are prioritate înaintea unei viteze mai mari",
            "memoria vizuală păstrează pentru scurt timp forma expresiei",
            "ochii urmăresc sensul fără să se oprească la fiecare literă",
            "un cititor atent observă simultan mai multe elemente apropiate",
            "antrenamentul consecvent face percepția mai stabilă și mai rapidă",
            "pauzele scurte mențin concentrarea bună în timpul sesiunii",
            "textul este perceput ca structură și nu ca litere izolate",
            "răspunsul corect confirmă că stimulul a fost recunoscut precis",
            "dificultatea crește treptat când nivelul actual este confortabil",
            "focalizarea centrală ajută la controlul mișcărilor inutile ale privirii",
            "câmpul vizual poate cuprinde elemente aflate în stânga și dreapta",
            "viteza utilă păstrează în același timp sensul și acuratețea",
            "fiecare sesiune oferă date pentru compararea progresului personal",
            "expunerea scurtă solicită recunoaștere imediată și atenție concentrată",
            "frazele familiare devin mai ușor de procesat în grupuri",
            "citirea eficientă combină percepția rapidă cu înțelegerea textului",
            "un ritm constant este mai valoros decât variațiile foarte mari",
            "progresul real se confirmă prin rezultate repetate la aceeași dificultate",
            "privirea nu urmărește mânerul ci rămâne pe punctul de fixație",
            "răspunsurile exacte arată că informația nu a fost doar ghicită",
            "o sesiune bună se oprește înainte ca oboseala să reducă precizia",
            "grupurile mai lungi necesită o zonă vizuală mai largă și stabilă",
            "cuvintele sunt afișate suficient de mari pentru recunoaștere confortabilă",
            "aplicația păstrează aceeași regulă de promovare pentru rezultate comparabile",
            "calendarul mută automat antrenamentul ratat la următoarea zi disponibilă",
            "nivelul următor rămâne blocat până când criteriul de stăpânire este atins"
    };

    private static final String[] DIGIT_GROUPS = {
            "381", "742", "596", "214", "865", "437", "920", "653", "178", "504",
            "3817", "7429", "5962", "2148", "8653", "4371", "9206", "6534", "1785", "5042",
            "38174", "74295", "59621", "21486", "86537", "43710", "92064", "65348", "17852", "50429",
            "381742", "742951", "596214", "214865", "865437", "437109", "920643", "653481", "178529", "504296"
    };

    private ExerciseLibrary() { }

    public static DayPlan getDayPlan(int requestedDay) {
        int day = Math.max(1, Math.min(PROGRAM_DAYS, requestedDay));
        switch (day) {
            case 1:  return p(day, "CALIBRARE", "Baseline: un cuvânt", "Măsoară punctul de pornire fără a forța viteza.", KIND_WORDS, 1, 300, 500, true);
            case 2:  return p(day, "FUNDAMENT", "Silabe clare", "Recunoaștere imediată a silabelor, cu fixație stabilă.", KIND_SYLLABLES, 1, 250, 500, false);
            case 3:  return p(day, "FUNDAMENT", "Cuvinte scurte", "Un singur cuvânt; urmărește exactitatea, nu anticiparea.", KIND_WORDS, 1, 250, 450, false);
            case 4:  return p(day, "FUNDAMENT", "Cuvinte uzuale", "Aceeași lățime perceptivă, expunere mai scurtă.", KIND_WORDS, 1, 200, 450, false);
            case 5:  return p(day, "FUNDAMENT", "Cuvinte complexe", "Cuvinte mai lungi cu font și casetă adaptabile.", KIND_WORDS, 1, 150, 450, false);
            case 6:  return p(day, "FUNDAMENT", "Cifre compacte", "Secvențe numerice pentru recunoaștere vizuală fără context semantic.", KIND_DIGITS, 1, 200, 500, false);
            case 7:  return p(day, "EVALUARE", "Test săptămâna 1", "Confirmă că un cuvânt este perceput precis la 150 ms.", KIND_WORDS, 1, 150, 500, true);

            case 8:  return p(day, "GRUPARE", "Două cuvinte", "Începe percepția simultană a unei perechi de cuvinte.", KIND_PHRASES, 2, 300, 500, false);
            case 9:  return p(day, "GRUPARE", "Perechi rapide", "Două cuvinte la timp redus, fără schimbarea lățimii grupului.", KIND_PHRASES, 2, 250, 450, false);
            case 10: return p(day, "GRUPARE", "Perechi la 200 ms", "Menține răspunsuri exacte pe grupuri de două cuvinte.", KIND_PHRASES, 2, 200, 450, false);
            case 11: return p(day, "CÂMP VIZUAL", "Stânga + dreapta", "Ține fixația centrală și recunoaște elementele din ambele părți.", KIND_PERIPHERAL, 2, 250, 600, false);
            case 12: return p(day, "GRUPARE", "Perechi la 150 ms", "Consolidează două cuvinte la expunere scurtă.", KIND_PHRASES, 2, 150, 450, false);
            case 13: return p(day, "CONTROL", "Două grupuri numerice", "Separă recunoașterea vizuală de familiaritatea semantică.", KIND_DIGITS, 2, 200, 500, false);
            case 14: return p(day, "EVALUARE", "Test săptămâna 2", "Promovarea cere stabilitate la două cuvinte și 150 ms.", KIND_PHRASES, 2, 150, 500, true);

            case 15: return p(day, "EXTINDERE", "Trei cuvinte", "Extinde grupul fără a scurta imediat timpul de expunere.", KIND_PHRASES, 3, 300, 500, false);
            case 16: return p(day, "EXTINDERE", "Trei cuvinte 250", "Păstrează aceeași lățime și crește viteza gradual.", KIND_PHRASES, 3, 250, 450, false);
            case 17: return p(day, "EXTINDERE", "Trei cuvinte 200", "Răspunsul trebuie să rămână complet și în ordine.", KIND_PHRASES, 3, 200, 450, false);
            case 18: return p(day, "CÂMP VIZUAL", "Periferie extinsă", "Recunoaște trei cuvinte distribuite în jurul fixației.", KIND_PERIPHERAL, 3, 250, 600, false);
            case 19: return p(day, "EXTINDERE", "Trei cuvinte 150", "Consolidare înaintea evaluării săptămânale.", KIND_PHRASES, 3, 150, 450, false);
            case 20: return p(day, "CONTROL", "Memorie numerică", "Trei grupuri numerice, fără suport semantic.", KIND_DIGITS, 3, 200, 500, false);
            case 21: return p(day, "EVALUARE", "Test săptămâna 3", "Confirmă percepția stabilă a trei cuvinte la 150 ms.", KIND_PHRASES, 3, 150, 500, true);

            case 22: return p(day, "CAPACITATE", "Patru cuvinte", "Mărește spanul vizual păstrând o expunere controlată.", KIND_PHRASES, 4, 250, 500, false);
            case 23: return p(day, "CAPACITATE", "Patru cuvinte 200", "Consolidează grupul de patru cuvinte.", KIND_PHRASES, 4, 200, 450, false);
            case 24: return p(day, "CAPACITATE", "Cinci cuvinte", "Caseta se lărgește înainte ca fontul să fie redus.", KIND_PHRASES, 5, 250, 500, false);
            case 25: return p(day, "CÂMP VIZUAL", "Patru cuvinte periferice", "Fixează centrul; percepe două grupuri distribuite lateral.", KIND_PERIPHERAL, 4, 200, 650, false);
            case 26: return p(day, "CAPACITATE", "Cinci cuvinte 200", "Păstrează precizia la grupuri mai lungi.", KIND_PHRASES, 5, 200, 450, false);
            case 27: return p(day, "CAPACITATE", "Șase cuvinte", "Extinde spanul la șase cuvinte fără a sacrifica claritatea.", KIND_PHRASES, 6, 250, 500, false);
            case 28: return p(day, "CAPACITATE", "Șase cuvinte 200", "Stabilizează percepția înainte de nivelul maxim.", KIND_PHRASES, 6, 200, 450, false);
            case 29: return p(day, "CAPACITATE", "Șapte cuvinte", "Nivel maxim al programului: grup lung, expunere controlată.", KIND_PHRASES, 7, 250, 500, false);
            case 30:
            default: return p(day, "EVALUARE FINALĂ", "Test final", "Evaluare finală a capacității de grupare și comparație cu baseline-ul.", KIND_PHRASES, 5, 150, 550, true);
        }
    }

    private static DayPlan p(int day, String phase, String title, String description, int kind,
                             int chunkWords, int exposureMs, int fixationMs, boolean evaluation) {
        return new DayPlan(day, phase, title, description, kind, chunkWords, exposureMs, fixationMs, evaluation);
    }

    public static List<String> getStimuliForDay(int day) {
        DayPlan plan = getDayPlan(day);
        switch (plan.kind) {
            case KIND_SYLLABLES:
                return rotated(Arrays.asList(SYLLABLES), day * 5);
            case KIND_DIGITS:
                return buildDigitStimuli(plan.chunkWords, day);
            case KIND_PERIPHERAL:
                return buildPeripheralStimuli(plan.chunkWords, day);
            case KIND_PHRASES:
                return buildPhraseChunks(plan.chunkWords, day);
            case KIND_WORDS:
            default:
                return rotated(Arrays.asList(WORDS), day * 7);
        }
    }

    private static List<String> buildPhraseChunks(int chunkWords, int day) {
        List<String> words = new ArrayList<>();
        for (String sentence : SENTENCES) {
            words.addAll(Arrays.asList(sentence.split("\\s+")));
        }
        if (words.isEmpty()) return Collections.emptyList();
        int shift = (day * 11) % words.size();
        List<String> shifted = new ArrayList<>(words.size());
        for (int i = 0; i < words.size(); i++) shifted.add(words.get((i + shift) % words.size()));

        int chunk = Math.max(1, Math.min(7, chunkWords));
        List<String> result = new ArrayList<>();
        for (int i = 0; i + chunk <= shifted.size(); i += chunk) {
            StringBuilder builder = new StringBuilder();
            for (int j = 0; j < chunk; j++) {
                if (builder.length() > 0) builder.append(' ');
                builder.append(shifted.get(i + j));
            }
            result.add(builder.toString());
        }
        return result;
    }

    private static List<String> buildPeripheralStimuli(int totalWords, int day) {
        List<String> words = rotated(Arrays.asList(WORDS), day * 13);
        int total = Math.max(2, Math.min(6, totalWords));
        int leftCount = total / 2;
        int rightCount = total - leftCount;
        List<String> result = new ArrayList<>();
        int cursor = 0;
        while (cursor + total <= words.size()) {
            StringBuilder left = new StringBuilder();
            StringBuilder right = new StringBuilder();
            for (int i = 0; i < leftCount; i++) {
                if (left.length() > 0) left.append(' ');
                left.append(words.get(cursor++));
            }
            for (int i = 0; i < rightCount; i++) {
                if (right.length() > 0) right.append(' ');
                right.append(words.get(cursor++));
            }
            result.add(left + " ¦ " + right);
        }
        return result;
    }

    private static List<String> buildDigitStimuli(int groups, int day) {
        List<String> source = rotated(Arrays.asList(DIGIT_GROUPS), day * 3);
        int count = Math.max(1, Math.min(3, groups));
        List<String> result = new ArrayList<>();
        for (int i = 0; i + count <= source.size(); i += count) {
            StringBuilder builder = new StringBuilder();
            for (int j = 0; j < count; j++) {
                if (builder.length() > 0) builder.append(' ');
                builder.append(source.get(i + j));
            }
            result.add(builder.toString());
        }
        return result;
    }

    private static List<String> rotated(List<String> source, int shift) {
        if (source.isEmpty()) return Collections.emptyList();
        int normalized = ((shift % source.size()) + source.size()) % source.size();
        List<String> result = new ArrayList<>(source.size());
        for (int i = 0; i < source.size(); i++) result.add(source.get((i + normalized) % source.size()));
        return result;
    }
}
